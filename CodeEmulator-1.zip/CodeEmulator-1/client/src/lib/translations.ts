// Система переводов для MassaganAI
// Поддерживаемые языки: русский, казахский, английский, испанский, кыргызский, узбекский, турецкий, арабский

export type Language = 
  | "ru" // Русский
  | "kz" // Казахский
  | "en" // Английский
  | "es" // Испанский
  | "kg" // Кыргызский
  | "uz" // Узбекский
  | "tr" // Турецкий
  | "ar"; // Арабский

export interface LanguageInfo {
  code: Language;
  name: string; // Название языка на самом языке
  flag: string; // Emoji флага страны
  direction: "ltr" | "rtl"; // Направление текста (left-to-right или right-to-left)
}

export const languages: LanguageInfo[] = [
  {
    code: "ru",
    name: "Русский",
    flag: "🇷🇺",
    direction: "ltr"
  },
  {
    code: "kz",
    name: "Қазақша",
    flag: "🇰🇿",
    direction: "ltr"
  },
  {
    code: "en",
    name: "English",
    flag: "🇬🇧",
    direction: "ltr"
  },
  {
    code: "es",
    name: "Español",
    flag: "🇪🇸",
    direction: "ltr"
  },
  {
    code: "kg",
    name: "Кыргызча",
    flag: "🇰🇬",
    direction: "ltr"
  },
  {
    code: "uz",
    name: "O'zbek",
    flag: "🇺🇿",
    direction: "ltr"
  },
  {
    code: "tr",
    name: "Türkçe",
    flag: "🇹🇷",
    direction: "ltr"
  },
  {
    code: "ar",
    name: "العربية",
    flag: "🇸🇦",
    direction: "rtl"
  }
];

interface Translations {
  [key: string]: {
    [lang in Language]?: string;
  };
}

// Все тексты приложения
export const translations: Translations = {
  // Общие фразы
  "app.name": {
    ru: "MassaganAI",
    kz: "MassaganAI",
    en: "MassaganAI",
    es: "MassaganAI",
    kg: "MassaganAI",
    uz: "MassaganAI",
    tr: "MassaganAI",
    ar: "ماساجان آي"
  },
  "app.slogan": {
    ru: "Smart AI, с корнями в Казахском восхищении",
    kz: "Smart AI, қазақтың таңданысында тамырланған",
    en: "Smart AI, rooted in Kazakh emotion",
    es: "IA Inteligente, arraigada en la emoción kazaja",
    kg: "Smart AI, казак элинин сезиминен пайда болгон",
    uz: "Smart AI, qozoq his-tuyg'ularida ildiz otgan",
    tr: "Kazak duygusunda kökleşmiş Akıllı AI",
    ar: "الذكاء الاصطناعي الذكي، متجذر في المشاعر الكازاخستانية"
  },
  "app.description": {
    ru: "Название происходит от казахского слова \"Мәссаған!\" — выражения удивления, как \"Вау!\". Это ИИ, который постоянно вас удивляет!",
    kz: "Атауы қазақ тіліндегі \"Мәссаған!\" сөзінен шыққан — таңданыс білдіретін, \"Вау!\" секілді. Бұл сізді үнемі таңқалдыратын ЖИ!",
    en: "The name comes from the Kazakh word \"Mässağan!\" — an expression of surprise, like \"Wow!\". It's an AI that constantly amazes you!",
    es: "El nombre proviene de la palabra kazaja \"Mässağan!\" — una expresión de sorpresa, como \"¡Guau!\". ¡Es una IA que te sorprende constantemente!",
    kg: "Аты казак тилиндеги \"Мәссаған!\" сөзүнөн келген — таң калуу сезими, \"Вау!\" сыяктуу. Бул сизди дайыма таң калтырган ЖИ!",
    uz: "Nomi qozoq tilidagi \"Mässağan!\" so'zidan kelib chiqqan — hayratlanish ifodasi, \"Vov!\" kabi. Bu sizni doimo hayratga soladigan AI!",
    tr: "İsim, Kazakça \"Mässağan!\" kelimesinden geliyor — \"Vay!\" gibi bir şaşkınlık ifadesi. Sizi sürekli şaşırtan bir AI!",
    ar: "الاسم يأتي من الكلمة الكازاخية \"ماساغان!\" - تعبير عن الدهشة، مثل \"واو!\". إنه ذكاء اصطناعي يدهشك باستمرار!"
  },
  
  // Кнопки аутентификации
  "auth.register": {
    ru: "Регистрация",
    kz: "Тіркелу",
    en: "Register",
    es: "Registrarse",
    kg: "Катталуу",
    uz: "Ro'yxatdan o'tish",
    tr: "Kayıt Ol",
    ar: "تسجيل"
  },
  "auth.login": {
    ru: "Войти",
    kz: "Кіру",
    en: "Log in",
    es: "Iniciar sesión",
    kg: "Кирүү",
    uz: "Kirish",
    tr: "Giriş Yap",
    ar: "تسجيل الدخول"
  },
  "auth.demo": {
    ru: "Демо доступ",
    kz: "Демо рұқсат",
    en: "Demo access",
    es: "Acceso demo",
    kg: "Демо кирүү",
    uz: "Demo kirish",
    tr: "Demo erişim",
    ar: "وصول تجريبي"
  },
  "auth.logout": {
    ru: "Выйти",
    kz: "Шығу",
    en: "Log out",
    es: "Cerrar sesión",
    kg: "Чыгуу",
    uz: "Chiqish",
    tr: "Çıkış Yap",
    ar: "تسجيل خروج"
  },
  
  // Приветственный экран
  "welcome.features": {
    ru: "Удивительные возможности",
    kz: "Таңғажайып мүмкіндіктер",
    en: "Amazing features",
    es: "Características asombrosas",
    kg: "Укмуштуу мүмкүнчүлүктөр",
    uz: "Ajoyib imkoniyatlar",
    tr: "Harika özellikler",
    ar: "ميزات مذهلة"
  },
  "welcome.multidevices.title": {
    ru: "Мультиустройства",
    kz: "Мульти құрылғылар",
    en: "Multi-devices",
    es: "Multi-dispositivos",
    kg: "Мульти-түзүлүштөр",
    uz: "Ko'p qurilmalar",
    tr: "Çoklu cihazlar",
    ar: "متعدد الأجهزة"
  },
  "welcome.multidevices.desc": {
    ru: "Тестируйте на различных устройствах: Android, iPhone, Windows и macOS",
    kz: "Әртүрлі құрылғыларда тексеріңіз: Android, iPhone, Windows және macOS",
    en: "Test on various devices: Android, iPhone, Windows and macOS",
    es: "Prueba en varios dispositivos: Android, iPhone, Windows y macOS",
    kg: "Ар түрдүү түзүлүштөрдө текшериңиз: Android, iPhone, Windows жана macOS",
    uz: "Turli qurilmalarda sinab ko'ring: Android, iPhone, Windows va macOS",
    tr: "Çeşitli cihazlarda test edin: Android, iPhone, Windows ve macOS",
    ar: "اختبر على أجهزة متنوعة: أندرويد، آيفون، ويندوز و ماك"
  },
  "welcome.editor.title": {
    ru: "Умный редактор",
    kz: "Ақылды редактор",
    en: "Smart editor",
    es: "Editor inteligente",
    kg: "Акылдуу редактор",
    uz: "Aqlli muharrir",
    tr: "Akıllı editör",
    ar: "محرر ذكي"
  },
  "welcome.editor.desc": {
    ru: "Мгновенное обновление и интеллектуальные подсказки от ИИ",
    kz: "Жедел жаңарту және ЖИ-дан интеллектуалды кеңестер",
    en: "Instant updates and smart AI tips",
    es: "Actualizaciones instantáneas y consejos inteligentes de IA",
    kg: "Тез жаңыртуу жана ЖИ-нин акылдуу кеңештери",
    uz: "Tezkor yangilanishlar va AI-dan aqlli maslahatlar",
    tr: "Anında güncellemeler ve akıllı AI ipuçları",
    ar: "تحديثات فورية ونصائح ذكية من الذكاء الاصطناعي"
  },
  "welcome.ai.title": {
    ru: "ИИ-эмулятор",
    kz: "ЖИ-эмулятор",
    en: "AI emulator",
    es: "Emulador de IA",
    kg: "ЖИ-эмулятор",
    uz: "AI-emulyator",
    tr: "AI emülatörü",
    ar: "محاكي الذكاء الاصطناعي"
  },
  "welcome.ai.desc": {
    ru: "Мощные алгоритмы для превращения кода в полноценный интерфейс",
    kz: "Кодты толыққанды интерфейске айналдыратын қуатты алгоритмдер",
    en: "Powerful algorithms to transform code into a full interface",
    es: "Potentes algoritmos para transformar código en una interfaz completa",
    kg: "Кодду толук интерфейске айландыруу үчүн күчтүү алгоритмдер",
    uz: "Kodni to'liq interfeysga aylantiradigan kuchli algoritmlar",
    tr: "Kodu tam bir arayüze dönüştürmek için güçlü algoritmalar",
    ar: "خوارزميات قوية لتحويل الكود إلى واجهة كاملة"
  },
  "welcome.projects.title": {
    ru: "Мгновенные проекты",
    kz: "Жедел жобалар",
    en: "Instant projects",
    es: "Proyectos instantáneos",
    kg: "Тез долбоорлор",
    uz: "Tezkor loyihalar",
    tr: "Anında projeler",
    ar: "مشاريع فورية"
  },
  "welcome.projects.desc": {
    ru: "Генерация полноценных веб-проектов одним кликом",
    kz: "Бір шертумен толыққанды веб-жобаларды құру",
    en: "Generate complete web projects with one click",
    es: "Genera proyectos web completos con un solo clic",
    kg: "Бир чыкылдатуу менен толук веб-долбоорлорду түзүү",
    uz: "Bir bosish bilan to'liq veb-loyihalarni yaratish",
    tr: "Tek tıklamayla tam web projeleri oluşturma",
    ar: "إنشاء مشاريع ويب كاملة بنقرة واحدة"
  },
  "welcome.upload.text": {
    ru: "Перетащите ваши файлы сюда",
    kz: "Файлдарыңызды осында сүйреңіз",
    en: "Drag your files here",
    es: "Arrastra tus archivos aquí",
    kg: "Файлдарыңызды бул жерге сүйрөңүз",
    uz: "Fayllaringizni bu yerga torting",
    tr: "Dosyalarınızı buraya sürükleyin",
    ar: "اسحب ملفاتك إلى هنا"
  },
  "welcome.upload.or": {
    ru: "или",
    kz: "немесе",
    en: "or",
    es: "o",
    kg: "же",
    uz: "yoki",
    tr: "veya",
    ar: "أو"
  },
  "welcome.upload.choose": {
    ru: "Выбрать файлы",
    kz: "Файлдарды таңдау",
    en: "Choose files",
    es: "Elegir archivos",
    kg: "Файлдарды тандоо",
    uz: "Fayllarni tanlash",
    tr: "Dosyaları seç",
    ar: "اختر الملفات"
  },
  "welcome.ready": {
    ru: "Готовы удивиться?",
    kz: "Таңқалуға дайынсыз ба?",
    en: "Ready to be amazed?",
    es: "¿Listo para sorprenderte?",
    kg: "Таң калууга даярсызбы?",
    uz: "Hayratlanishga tayyormisiz?",
    tr: "Şaşırmaya hazır mısınız?",
    ar: "هل أنت مستعد للإنبهار؟"
  },
  "welcome.ready.desc": {
    ru: "Загрузите свой код или создайте новый проект с помощью нашего ИИ. MassaganAI соединит все части воедино!",
    kz: "Кодыңызды жүктеңіз немесе біздің ЖИ көмегімен жаңа жоба жасаңыз. MassaganAI барлық бөліктерді біріктіреді!",
    en: "Upload your code or create a new project with our AI. MassaganAI will connect all parts together!",
    es: "Sube tu código o crea un nuevo proyecto con nuestra IA. ¡MassaganAI conectará todas las partes!",
    kg: "Кодуңузду жүктөңүз же биздин ЖИ менен жаңы долбоор түзүңүз. MassaganAI бардык бөлүктөрдү бириктирет!",
    uz: "Kodingizni yuklang yoki bizning AI bilan yangi loyiha yarating. MassaganAI barcha qismlarni birlashtiradi!",
    tr: "Kodunuzu yükleyin veya AI'ımızla yeni bir proje oluşturun. MassaganAI tüm parçaları bir araya getirecek!",
    ar: "قم بتحميل الكود الخاص بك أو إنشاء مشروع جديد باستخدام الذكاء الاصطناعي لدينا. سيقوم ماساجان آي بربط جميع الأجزاء معًا!"
  },
  "welcome.start": {
    ru: "Начать сейчас",
    kz: "Қазір бастау",
    en: "Start now",
    es: "Comenzar ahora",
    kg: "Азыр баштоо",
    uz: "Hozir boshlash",
    tr: "Şimdi başla",
    ar: "ابدأ الآن"
  },
  
  // Хедер
  "header.newProject": {
    ru: "Новый проект",
    kz: "Жаңа жоба",
    en: "New project",
    es: "Nuevo proyecto",
    kg: "Жаңы долбоор",
    uz: "Yangi loyiha",
    tr: "Yeni proje",
    ar: "مشروع جديد"
  },
  "header.uploadCode": {
    ru: "Загрузить код",
    kz: "Кодты жүктеу",
    en: "Upload code",
    es: "Subir código",
    kg: "Кодду жүктөө",
    uz: "Kodni yuklash",
    tr: "Kodu yükle",
    ar: "تحميل الكود"
  },
  "header.motto": {
    ru: "Мәссаған! = Wow!",
    kz: "Мәссаған! = Wow!",
    en: "Mässağan! = Wow!",
    es: "¡Mässağan! = ¡Wow!",
    kg: "Мәссаған! = Wow!",
    uz: "Mässağan! = Wow!",
    tr: "Mässağan! = Wow!",
    ar: "ماساغان! = واو!"
  },
  "header.subscribe": {
    ru: "Подписка",
    kz: "Жазылу",
    en: "Subscribe",
    es: "Suscríbete",
    kg: "Жазылуу",
    uz: "Obuna bo'lish",
    tr: "Abone ol",
    ar: "اشترك"
  },
  
  // Пользовательское меню
  "user.profile": {
    ru: "Профиль",
    kz: "Профиль",
    en: "Profile",
    es: "Perfil",
    kg: "Профиль",
    uz: "Profil",
    tr: "Profil",
    ar: "الملف الشخصي"
  },
  "user.settings": {
    ru: "Настройки",
    kz: "Параметрлер",
    en: "Settings",
    es: "Configuración",
    kg: "Орнотуулар",
    uz: "Sozlamalar",
    tr: "Ayarlar",
    ar: "الإعدادات"
  },
  "user.myProjects": {
    ru: "Мои проекты",
    kz: "Менің жобаларым",
    en: "My projects",
    es: "Mis proyectos",
    kg: "Менин долбоорлорум",
    uz: "Mening loyihalarim",
    tr: "Projelerim",
    ar: "مشاريعي"
  },
  "user.demo": {
    ru: "Демо",
    kz: "Демо",
    en: "Demo",
    es: "Demo",
    kg: "Демо",
    uz: "Demo",
    tr: "Demo",
    ar: "تجريبي"
  },

  // Новая главная страница
  "HeroDescription": {
    ru: "Универсальное казахстанское ИИ-решение для создания, генерации и управления цифровыми проектами",
    kz: "Сандық жобаларды жасау, генерациялау және басқаруға арналған әмбебап қазақстандық ЖИ шешімі",
    en: "Universal Kazakh AI solution for creating, generating and managing digital projects",
    es: "Solución universal de IA kazaja para crear, generar y administrar proyectos digitales",
    kg: "Санариптик долбоорлорду түзүү, генерациялоо жана башкаруу үчүн универсалдуу казак ЖИ чечими",
    uz: "Raqamli loyihalarni yaratish, generatsiya qilish va boshqarish uchun universal qozoq AI yechimi",
    tr: "Dijital projeleri oluşturmak, üretmek ve yönetmek için evrensel Kazak AI çözümü",
    ar: "حل الذكاء الاصطناعي الكازاخستاني الشامل لإنشاء وتوليد وإدارة المشاريع الرقمية"
  },
  "GetStarted": {
    ru: "Начать работу",
    kz: "Жұмысты бастау",
    en: "Get started",
    es: "Comenzar",
    kg: "Баштоо",
    uz: "Boshlash",
    tr: "Başla",
    ar: "ابدأ الآن"
  },
  "TryPresentations": {
    ru: "Попробовать презентации",
    kz: "Презентацияларды байқап көру",
    en: "Try presentations",
    es: "Probar presentaciones",
    kg: "Презентацияларды сынап көрүү",
    uz: "Taqdimotlarni sinab ko'rish",
    tr: "Sunumları deneyin",
    ar: "جرب العروض التقديمية"
  },
  "AvailableFeatures": {
    ru: "Доступные функции",
    kz: "Қолжетімді функциялар",
    en: "Available features",
    es: "Funciones disponibles",
    kg: "Жеткиликтүү функциялар",
    uz: "Mavjud funksiyalar",
    tr: "Mevcut özellikler",
    ar: "الميزات المتاحة"
  },
  "FeaturesDescription": {
    ru: "Исследуйте широкий спектр инструментов и возможностей MassaganAI",
    kz: "MassaganAI құралдары мен мүмкіндіктерінің кең спектрін зерттеңіз",
    en: "Explore the wide range of MassaganAI tools and capabilities",
    es: "Explore la amplia gama de herramientas y capacidades de MassaganAI",
    kg: "MassaganAI куралдарынын жана мүмкүнчүлүктөрүнүн кеңири спектрин изилдөө",
    uz: "MassaganAI vositalari va imkoniyatlarining keng doirasini o'rganing",
    tr: "MassaganAI araçlarının ve yeteneklerinin geniş yelpazesini keşfedin",
    ar: "استكشف مجموعة واسعة من أدوات وإمكانيات ماساجان آي"
  },
  "SearchFeatures": {
    ru: "Поиск функций...",
    kz: "Функцияларды іздеу...",
    en: "Search features...",
    es: "Buscar funciones...",
    kg: "Функцияларды издөө...",
    uz: "Funksiyalarni qidirish...",
    tr: "Özellikleri ara...",
    ar: "البحث عن الميزات..."
  },
  "NoFeaturesFound": {
    ru: "Функции не найдены. Попробуйте другой поисковый запрос.",
    kz: "Функциялар табылмады. Басқа іздеу сұрауын көріңіз.",
    en: "No features found. Try a different search query.",
    es: "No se encontraron funciones. Prueba con una búsqueda diferente.",
    kg: "Функциялар табылган жок. Башка издөө сөзүн колдонуп көрүңүз.",
    uz: "Funksiyalar topilmadi. Boshqa qidiruv so'rovini sinab ko'ring.",
    tr: "Özellik bulunamadı. Farklı bir arama sorgusu deneyin.",
    ar: "لم يتم العثور على ميزات. جرب استعلام بحث مختلف."
  },
  "ReadyToStart": {
    ru: "Готовы начать?",
    kz: "Бастауға дайынсыз ба?",
    en: "Ready to start?",
    es: "¿Listo para empezar?",
    kg: "Баштоого даярсызбы?",
    uz: "Boshlashga tayyormisiz?",
    tr: "Başlamaya hazır mısınız?",
    ar: "هل أنت مستعد للبدء؟"
  },
  "CTADescription": {
    ru: "Подпишитесь на премиум-план и разблокируйте все мощные функции MassaganAI",
    kz: "Премиум жоспарға жазылып, MassaganAI-дың барлық қуатты мүмкіндіктерін ашыңыз",
    en: "Subscribe to the premium plan and unlock all powerful MassaganAI features",
    es: "Suscríbete al plan premium y desbloquea todas las potentes funciones de MassaganAI",
    kg: "Премиум планга жазылып, MassaganAI'нин бардык күчтүү функцияларын ачыңыз",
    uz: "Premium rejaga obuna bo'lib, MassaganAI-ning barcha kuchli funksiyalarini ochib oling",
    tr: "Premium plana abone olun ve tüm güçlü MassaganAI özelliklerinin kilidini açın",
    ar: "اشترك في الخطة المميزة وافتح جميع ميزات ماساجان آي القوية"
  },
  "UpgradeNow": {
    ru: "Улучшить сейчас",
    kz: "Қазір жаңарту",
    en: "Upgrade now",
    es: "Actualizar ahora",
    kg: "Азыр жаңыртуу",
    uz: "Hozir yangilang",
    tr: "Şimdi yükselt",
    ar: "الترقية الآن"
  },
  "Open": {
    ru: "Открыть",
    kz: "Ашу",
    en: "Open",
    es: "Abrir",
    kg: "Ачуу",
    uz: "Ochish",
    tr: "Aç",
    ar: "فتح"
  },
  "WelcomeBack": {
    ru: "С возвращением!",
    kz: "Қайта келуіңізбен!",
    en: "Welcome back!",
    es: "¡Bienvenido de nuevo!",
    kg: "Кайра келгениңиз кут болсун!",
    uz: "Qaytib kelganingiz bilan!",
    tr: "Tekrar hoş geldiniz!",
    ar: "مرحبًا بعودتك!"
  },
  "LoggedInAs": {
    ru: "Вы вошли как",
    kz: "Сіз кірдіңіз",
    en: "You are logged in as",
    es: "Has iniciado sesión como",
    kg: "Сиз катталдыңыз",
    uz: "Siz tizimga kirdingiz",
    tr: "Şu şekilde giriş yaptınız",
    ar: "لقد قمت بتسجيل الدخول باسم"
  },
  
  // Названия функций
  "AICodeEmulator": {
    ru: "ИИ-эмулятор кода",
    kz: "ЖИ-код эмуляторы",
    en: "AI code emulator",
    es: "Emulador de código IA",
    kg: "ЖИ-код эмулятору",
    uz: "AI-kod emulyatori",
    tr: "AI kod emülatörü",
    ar: "محاكي الكود بالذكاء الاصطناعي"
  },
  "AICodeEmulatorDesc": {
    ru: "Эмулируйте и визуализируйте код на разных устройствах с помощью ИИ",
    kz: "ЖИ көмегімен әр түрлі құрылғыларда кодты эмуляциялау және визуализациялау",
    en: "Emulate and visualize code on different devices using AI",
    es: "Emula y visualiza código en diferentes dispositivos usando IA",
    kg: "ЖИ менен ар кандай түзүлүштөрдө кодду эмуляциялоо жана визуалдаштыруу",
    uz: "AI yordamida turli qurilmalarda kodni emulyatsiya qilish va vizualizatsiya qilish",
    tr: "AI kullanarak kodu farklı cihazlarda emüle edin ve görselleştirin",
    ar: "محاكاة وتصور الكود على أجهزة مختلفة باستخدام الذكاء الاصطناعي"
  },
  "FrontendGenerator": {
    ru: "Генератор фронтенда",
    kz: "Фронтенд генераторы",
    en: "Frontend generator",
    es: "Generador de frontend",
    kg: "Фронтенд генератору",
    uz: "Frontend generatori",
    tr: "Frontend üreteci",
    ar: "مولد الواجهة الأمامية"
  },
  "FrontendGeneratorDesc": {
    ru: "Автоматическое создание фронтенда на основе бэкенд кода и описания",
    kz: "Бэкенд коды мен сипаттамасына негізделген фронтендті автоматты түрде құру",
    en: "Automatic frontend creation based on backend code and description",
    es: "Creación automática de frontend basada en código backend y descripción",
    kg: "Бэкенд кодуна жана сүрөттөмөсүнө негизделген фронтендди автоматтык түрдө түзүү",
    uz: "Backend kodi va tavsifiga asoslangan frontend avtomatik yaratish",
    tr: "Backend kodu ve açıklamaya dayalı otomatik frontend oluşturma",
    ar: "إنشاء واجهة أمامية تلقائية بناءً على كود الخلفية والوصف"
  },
  "CodeImport": {
    ru: "Импорт кода",
    kz: "Кодты импорттау",
    en: "Code import",
    es: "Importar código",
    kg: "Кодду импорттоо",
    uz: "Kodni import qilish",
    tr: "Kod içe aktarma",
    ar: "استيراد الكود"
  },
  "CodeImportDesc": {
    ru: "Импортируйте код из GitHub, ZIP-архивов или загрузите файлы напрямую",
    kz: "GitHub, ZIP архивтерінен кодты импорттаңыз немесе файлдарды тікелей жүктеңіз",
    en: "Import code from GitHub, ZIP archives or upload files directly",
    es: "Importa código desde GitHub, archivos ZIP o carga archivos directamente",
    kg: "GitHub, ZIP архивдеринен кодду импорттоо же файлдарды түз жүктөө",
    uz: "GitHub, ZIP arxivlaridan kodni import qiling yoki fayllarni to'g'ridan-to'g'ri yuklang",
    tr: "GitHub'dan, ZIP arşivlerinden kod içe aktarın veya dosyaları doğrudan yükleyin",
    ar: "استيراد الكود من GitHub أو أرشيفات ZIP أو تحميل الملفات مباشرة"
  },
  "MediaGenerator": {
    ru: "Генератор медиа",
    kz: "Медиа генераторы",
    en: "Media generator",
    es: "Generador de medios",
    kg: "Медиа генератору",
    uz: "Media generatori",
    tr: "Medya üreteci",
    ar: "مولد الوسائط"
  },
  "MediaGeneratorDesc": {
    ru: "Создавайте изображения, логотипы и применяйте фильтры с помощью ИИ",
    kz: "ЖИ көмегімен суреттер, логотиптер жасаңыз және фильтрлерді қолданыңыз",
    en: "Create images, logos and apply filters using AI",
    es: "Crea imágenes, logotipos y aplica filtros usando IA",
    kg: "ЖИ менен сүрөттөрдү, логотипдерди жаратуу жана фильтрлерди колдонуу",
    uz: "AI yordamida rasmlar, logotiplar yarating va filtrlarni qo'llang",
    tr: "AI kullanarak resimler, logolar oluşturun ve filtreler uygulayın",
    ar: "إنشاء صور وشعارات وتطبيق مرشحات باستخدام الذكاء الاصطناعي"
  },
  "VideoCreator": {
    ru: "Создатель видео",
    kz: "Бейне жасаушы",
    en: "Video creator",
    es: "Creador de video",
    kg: "Видео жаратуучу",
    uz: "Video yaratuvchi",
    tr: "Video oluşturucu",
    ar: "منشئ الفيديو"
  },
  "VideoCreatorDesc": {
    ru: "Генерируйте видео с текстом и аудио на основе промпта",
    kz: "Промптқа негізделген мәтін мен аудиосы бар бейнелерді жасаңыз",
    en: "Generate videos with text and audio based on prompt",
    es: "Genera videos con texto y audio basados en prompt",
    kg: "Промптко негизделген текст жана аудиосу бар видеолорду жаратуу",
    uz: "Prompt asosida matn va audio bilan videolar yarating",
    tr: "Komuta dayalı metin ve ses içeren videolar oluşturun",
    ar: "توليد مقاطع فيديو بنص وصوت بناءً على السطر"
  },
  "PresentationCreator": {
    ru: "Создатель презентаций",
    kz: "Презентация жасаушы",
    en: "Presentation creator",
    es: "Creador de presentaciones",
    kg: "Презентация жаратуучу",
    uz: "Taqdimot yaratuvchi",
    tr: "Sunum oluşturucu",
    ar: "منشئ العروض التقديمية"
  },
  "PresentationCreatorDesc": {
    ru: "Создавайте профессиональные презентации с помощью ИИ",
    kz: "ЖИ көмегімен кәсіби презентациялар жасаңыз",
    en: "Create professional presentations with AI",
    es: "Crea presentaciones profesionales con IA",
    kg: "ЖИ менен кесиптик презентацияларды жаратуу",
    uz: "AI yordamida professional taqdimotlar yarating",
    tr: "AI ile profesyonel sunumlar oluşturun",
    ar: "إنشاء عروض تقديمية احترافية باستخدام الذكاء الاصطناعي"
  },
  "BlueprintCreator": {
    ru: "Создатель чертежей",
    kz: "Сызба жасаушы",
    en: "Blueprint creator",
    es: "Creador de planos",
    kg: "Чийме жасоочу",
    uz: "Chizma yaratuvchi",
    tr: "Blueprint oluşturucu",
    ar: "منشئ المخططات"
  },
  "BlueprintCreatorDesc": {
    ru: "Генерируйте технические чертежи и схемы для ваших проектов",
    kz: "Жобаларыңыз үшін техникалық сызбалар мен схемаларды жасаңыз",
    en: "Generate technical drawings and diagrams for your projects",
    es: "Genera dibujos técnicos y diagramas para tus proyectos",
    kg: "Долбоорлоруңуз үчүн техникалык чиймелерди жана схемаларды жаратыңыз",
    uz: "Loyihalaringiz uchun texnik chizmalar va sxemalar yarating",
    tr: "Projeleriniz için teknik çizimler ve şemalar oluşturun",
    ar: "توليد رسومات تقنية ومخططات لمشاريعك"
  },
  "3DModelCreator": {
    ru: "Создатель 3D моделей",
    kz: "3D модельдер жасаушысы",
    en: "3D model creator",
    es: "Creador de modelos 3D",
    kg: "3D моделдерди жаратуучу",
    uz: "3D model yaratuvchi",
    tr: "3D model oluşturucu",
    ar: "منشئ نماذج ثلاثية الأبعاد"
  },
  "3DModelCreatorDesc": {
    ru: "Создавайте и визуализируйте 3D модели на основе описаний",
    kz: "Сипаттамаларға негізделген 3D модельдерді жасаңыз және визуализациялаңыз",
    en: "Create and visualize 3D models based on descriptions",
    es: "Crea y visualiza modelos 3D basados en descripciones",
    kg: "Сүрөттөмөлөргө негизделген 3D моделдерди жаратуу жана визуализациялоо",
    uz: "Tavsiflar asosida 3D modellarni yarating va vizualizatsiya qiling",
    tr: "Açıklamalara dayalı 3D modeller oluşturun ve görselleştirin",
    ar: "إنشاء وتصور نماذج ثلاثية الأبعاد بناءً على الأوصاف"
  },
  "SocialMediaManager": {
    ru: "Менеджер соцсетей",
    kz: "Әлеуметтік желілер менеджері",
    en: "Social media manager",
    es: "Gestor de redes sociales",
    kg: "Социалдык тармактар менеджери",
    uz: "Ijtimoiy tarmoqlar menejeri",
    tr: "Sosyal medya yöneticisi",
    ar: "مدير وسائل التواصل الاجتماعي"
  },
  "SocialMediaManagerDesc": {
    ru: "Автоматизируйте публикации и управляйте контентом в социальных сетях",
    kz: "Әлеуметтік желілердегі жарияланымдарды автоматтандырыңыз және контентті басқарыңыз",
    en: "Automate posts and manage content on social networks",
    es: "Automatiza publicaciones y gestiona contenido en redes sociales",
    kg: "Социалдык тармактарда жарыялоолорду автоматташтырып, контентти башкаруу",
    uz: "Ijtimoiy tarmoqlarda postlarni avtomatlashtiring va kontentni boshqaring",
    tr: "Sosyal ağlarda yayınları otomatikleştirin ve içeriği yönetin",
    ar: "أتمتة المنشورات وإدارة المحتوى على الشبكات الاجتماعية"
  },
  "TelegramBot": {
    ru: "Telegram бот",
    kz: "Telegram бот",
    en: "Telegram bot",
    es: "Bot de Telegram",
    kg: "Telegram бот",
    uz: "Telegram bot",
    tr: "Telegram botu",
    ar: "بوت تيليجرام"
  },
  "TelegramBotDesc": {
    ru: "Создавайте и настраивайте ботов Telegram для различных задач",
    kz: "Әртүрлі тапсырмалар үшін Telegram боттарын жасаңыз және реттеңіз",
    en: "Create and configure Telegram bots for various tasks",
    es: "Crea y configura bots de Telegram para diversas tareas",
    kg: "Ар кандай тапшырмалар үчүн Telegram боттордн жаратуу жана орнотуу",
    uz: "Turli vazifalar uchun Telegram botlarini yarating va sozlang",
    tr: "Çeşitli görevler için Telegram botları oluşturun ve yapılandırın",
    ar: "إنشاء وتكوين بوتات تيليجرام لمختلف المهام"
  },
  "SpeechSynthesizer": {
    ru: "Синтезатор речи",
    kz: "Сөйлеу синтезаторы",
    en: "Speech synthesizer",
    es: "Sintetizador de voz",
    kg: "Сүйлөө синтезатору",
    uz: "Nutq sintezatori",
    tr: "Konuşma sentezleyici",
    ar: "مولد الكلام"
  },
  "SpeechSynthesizerDesc": {
    ru: "Преобразуйте текст в естественно звучащую речь на разных языках",
    kz: "Мәтінді әртүрлі тілдерде табиғи дыбысталатын сөйлеуге айналдырыңыз",
    en: "Convert text to naturally sounding speech in different languages",
    es: "Convierte texto a voz natural en diferentes idiomas",
    kg: "Текстти ар түрдүү тилдерде табигый дабыштуу сүйлөөгө айландыруу",
    uz: "Turli tillarda matnni tabiiy jarangli nutqqa aylantiring",
    tr: "Metni farklı dillerde doğal sesli konuşmaya dönüştürün",
    ar: "تحويل النص إلى كلام طبيعي بلغات مختلفة"
  },
  "MyProjects": {
    ru: "Мои проекты",
    kz: "Менің жобаларым",
    en: "My projects",
    es: "Mis proyectos",
    kg: "Менин долбоорлорум",
    uz: "Mening loyihalarim",
    tr: "Projelerim",
    ar: "مشاريعي"
  },
  "MyProjectsDesc": {
    ru: "Управляйте и редактируйте свои сохраненные проекты",
    kz: "Сақталған жобаларыңызды басқарыңыз және өңдеңіз",
    en: "Manage and edit your saved projects",
    es: "Administra y edita tus proyectos guardados",
    kg: "Сакталган долбоорлоруңузду башкаруу жана түзөтүү",
    uz: "Saqlangan loyihalaringizni boshqaring va tahrirlang",
    tr: "Kayıtlı projelerinizi yönetin ve düzenleyin",
    ar: "إدارة وتحرير المشاريع المحفوظة"
  },
  "AILab": {
    ru: "ИИ-лаборатория",
    kz: "ЖИ-зертханасы",
    en: "AI lab",
    es: "Laboratorio de IA",
    kg: "ЖИ-лабораториясы",
    uz: "AI laboratoriyasi",
    tr: "AI laboratuvarı",
    ar: "مختبر الذكاء الاصطناعي"
  },
  "AILabDesc": {
    ru: "Моделируйте сценарии по заданным промптам и техническим характеристикам",
    kz: "Берілген промпттар мен техникалық сипаттамалар бойынша сценарийлерді модельдеңіз",
    en: "Model scenarios based on given prompts and technical specifications",
    es: "Modela escenarios basados en prompts y especificaciones técnicas dadas",
    kg: "Берилген промпттор жана техникалык спецификациялар боюнча сценарийлерди моделдөө",
    uz: "Berilgan promptlar va texnik xususiyatlar asosida senariylarni modellash",
    tr: "Verilen komutlara ve teknik özelliklere göre senaryoları modelleyin",
    ar: "نمذجة السيناريوهات بناءً على السطور والمواصفات التقنية المعطاة"
  },
  "CryptoWallet": {
    ru: "Криптокошелек",
    kz: "Криптоәмиян",
    en: "Crypto wallet",
    es: "Monedero crypto",
    kg: "Крипто капчык",
    uz: "Kripto hamyon",
    tr: "Kripto cüzdan",
    ar: "محفظة العملات المشفرة"
  },
  "CryptoWalletDesc": {
    ru: "Управляйте криптовалютой для расходов на рекламу и нужды ИИ",
    kz: "Жарнама шығындары мен ЖИ қажеттіліктеріне арналған криптовалютаны басқарыңыз",
    en: "Manage cryptocurrency for advertising expenses and AI needs",
    es: "Administra criptomonedas para gastos publicitarios y necesidades de IA",
    kg: "Жарнама чыгымдары жана ЖИ муктаждыктары үчүн криптовалютаны башкаруу",
    uz: "Reklama xarajatlari va AI ehtiyojlari uchun kriptovalyutani boshqaring",
    tr: "Reklam giderleri ve AI ihtiyaçları için kripto para birimini yönetin",
    ar: "إدارة العملات المشفرة لنفقات الإعلان واحتياجات الذكاء الاصطناعي"
  }
};

// Получить перевод для конкретного языка и ключа
export function getTranslation(key: string, lang: Language): string {
  if (!translations[key]) {
    console.warn(`Translation key not found: ${key}`);
    return key;
  }
  
  if (!translations[key][lang]) {
    // Если перевод на данный язык отсутствует, возвращаем русский вариант
    console.warn(`Translation for key ${key} in language ${lang} not found, using Russian`);
    return translations[key]['ru'] || key;
  }
  
  return translations[key][lang]!;
}

// Получить перевод с поддержкой интерполяции параметров
export function t(key: string, lang: Language, params?: Record<string, string>): string {
  let translation = getTranslation(key, lang);
  
  if (params) {
    Object.keys(params).forEach(paramKey => {
      const regex = new RegExp(`{${paramKey}}`, 'g');
      translation = translation.replace(regex, params[paramKey]);
    });
  }
  
  return translation;
}

// Сохранение выбранного языка в localStorage
export function saveLanguage(lang: Language): void {
  localStorage.setItem('massaganai-language', lang);
}

// Получение выбранного языка из localStorage
export function getLanguage(): Language {
  const savedLang = localStorage.getItem('massaganai-language') as Language;
  return savedLang || 'ru'; // По умолчанию русский
}