import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Language, getLanguage, saveLanguage } from './translations';
import { t } from './all-translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, params?: Record<string, string>) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguageState] = useState<Language>(getLanguage());
  
  // Изменение языка с сохранением в localStorage
  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    saveLanguage(lang);
    
    // Обработка направления текста для арабского языка
    if (lang === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.classList.add('rtl');
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.classList.remove('rtl');
    }
  };
  
  // Получение перевода с текущим языком
  const translate = (key: string, params?: Record<string, string>) => {
    return t(key, language, params);
  };
  
  // При первом рендере устанавливаем язык из localStorage
  useEffect(() => {
    const savedLang = getLanguage();
    setLanguage(savedLang);
  }, []);
  
  const value = {
    language,
    setLanguage,
    t: translate
  };
  
  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

// Hook для использования языка в компонентах
export function useLanguage() {
  const context = useContext(LanguageContext);
  
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  
  return context;
}