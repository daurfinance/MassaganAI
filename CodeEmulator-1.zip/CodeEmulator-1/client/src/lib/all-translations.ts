// Объединенные переводы для всего приложения MassaganAI
import { Language } from './translations';
import { translations } from './translations';
import { emulatorTranslations } from './emulator-translations';

// Объединяем все переводы в один объект
export const allTranslations: Record<string, Record<Language, string>> = {
  ...translations as Record<string, Record<Language, string>>,
  ...emulatorTranslations as Record<string, Record<Language, string>>,
};

// Получить перевод для конкретного языка и ключа
export function getTranslation(key: string, lang: Language): string {
  if (!allTranslations[key]) {
    console.warn(`Translation key not found: ${key}`);
    return key;
  }
  
  if (!allTranslations[key][lang]) {
    // Если перевод на данный язык отсутствует, возвращаем русский вариант
    console.warn(`Translation for key ${key} in language ${lang} not found, using Russian`);
    return allTranslations[key]['ru'] || key;
  }
  
  return allTranslations[key][lang]!;
}

// Получить перевод с поддержкой интерполяции параметров
export function t(key: string, lang: Language, params?: Record<string, string>): string {
  let translation = getTranslation(key, lang);
  
  if (params) {
    Object.keys(params).forEach(paramKey => {
      const regex = new RegExp(`{${paramKey}}`, 'g');
      translation = translation.replace(regex, params[paramKey]);
    });
  }
  
  return translation;
}