// Переводы для компонента ИИ-эмулятора
import { Language } from './translations';

export const emulatorTranslations: Record<string, Record<Language, string>> = {
  "AICodeEmulator": {
    ru: "ИИ-эмулятор кода",
    kz: "Код ЖИ-эмуляторы",
    en: "AI Code Emulator",
    es: "Emulador de código IA",
    kg: "ЖИ-Код эмулятору",
    uz: "AI Kod emulyatori",
    tr: "AI Kod Emülatörü",
    ar: "محاكي الكود بالذكاء الاصطناعي"
  },
  "AICodeEmulatorDesc": {
    ru: "Анализ и эмуляция кода для различных устройств и систем",
    kz: "Әртүрлі құрылғылар мен жүйелер үшін кодты талдау және эмуляциялау",
    en: "Analyzing and emulating code for various devices and systems",
    es: "Analizando y emulando código para varios dispositivos y sistemas",
    kg: "Ар түрдүү түзүлүштөр жана системалар үчүн кодду талдоо жана эмуляциялоо",
    uz: "Turli qurilmalar va tizimlar uchun kodni tahlil qilish va emulatsiya qilish",
    tr: "Çeşitli cihazlar ve sistemler için kodu analiz etme ve emüle etme",
    ar: "تحليل ومحاكاة الكود لمختلف الأجهزة والأنظمة"
  },
  "AICodeAnalysis": {
    ru: "ИИ-анализ кода",
    kz: "ЖИ-код талдауы",
    en: "AI Code Analysis",
    es: "Análisis de código IA",
    kg: "ЖИ-код талдоосу",
    uz: "AI Kod tahlili",
    tr: "AI Kod Analizi",
    ar: "تحليل الكود بالذكاء الاصطناعي"
  },
  "AIAnalyzesCode": {
    ru: "ИИ анализирует ваш код",
    kz: "ЖИ сіздің кодыңызды талдайды",
    en: "AI analyzes your code",
    es: "IA analiza tu código",
    kg: "ЖИ сиздин кодуңузду талдайт",
    uz: "AI kodingizni tahlil qiladi",
    tr: "AI kodunuzu analiz eder",
    ar: "الذكاء الاصطناعي يحلل الكود الخاص بك"
  },
  "GitHubIntegration": {
    ru: "Интеграция с GitHub",
    kz: "GitHub-пен интеграция",
    en: "GitHub Integration",
    es: "Integración con GitHub",
    kg: "GitHub менен интеграция",
    uz: "GitHub bilan integratsiya",
    tr: "GitHub Entegrasyonu",
    ar: "تكامل مع GitHub"
  },
  "ImportFromGitHub": {
    ru: "Импорт из GitHub",
    kz: "GitHub-тан импорттау",
    en: "Import from GitHub",
    es: "Importar desde GitHub",
    kg: "GitHub-тан импорттоо",
    uz: "GitHub-dan import qilish",
    tr: "GitHub'dan İçe Aktar",
    ar: "استيراد من GitHub"
  },
  "MultiLanguageSupport": {
    ru: "Поддержка разных языков",
    kz: "Түрлі тілдерді қолдау",
    en: "Multi-language Support",
    es: "Soporte multilenguaje",
    kg: "Көп тилдүү колдоо",
    uz: "Ko'p tilli qo'llab-quvvatlash",
    tr: "Çoklu Dil Desteği",
    ar: "دعم متعدد اللغات"
  },
  "SupportForMultipleLanguages": {
    ru: "Поддержка разных языков программирования",
    kz: "Әр түрлі программалау тілдерін қолдау",
    en: "Support for multiple programming languages",
    es: "Soporte para múltiples lenguajes de programación",
    kg: "Бир нече программалоо тилдерин колдоо",
    uz: "Bir nechta dasturlash tillarini qo'llab-quvvatlash",
    tr: "Birden fazla programlama dili desteği",
    ar: "دعم لغات برمجة متعددة"
  },
  "MultiDeviceEmulation": {
    ru: "Эмуляция разных устройств",
    kz: "Әр түрлі құрылғылардың эмуляциясы",
    en: "Multi-device Emulation",
    es: "Emulación multidispositivo",
    kg: "Көп түзүлүш эмуляциясы",
    uz: "Ko'p qurilmali emulatsiya",
    tr: "Çoklu Cihaz Emülasyonu",
    ar: "محاكاة متعددة الأجهزة"
  },
  "EmulateOnDifferentDevices": {
    ru: "Эмуляция на разных устройствах и ОС",
    kz: "Әр түрлі құрылғылар мен ОЖ-да эмуляциялау",
    en: "Emulate on different devices and OS",
    es: "Emular en diferentes dispositivos y SO",
    kg: "Ар түрдүү түзүлүштөрдө жана ОСте эмуляциялоо",
    uz: "Turli qurilmalar va OSlarda emulatsiya qilish",
    tr: "Farklı cihazlarda ve işletim sistemlerinde emüle edin",
    ar: "محاكاة على أجهزة وأنظمة تشغيل مختلفة"
  },
  "Device": {
    ru: "Устройство",
    kz: "Құрылғы",
    en: "Device",
    es: "Dispositivo",
    kg: "Түзүлүш",
    uz: "Qurilma",
    tr: "Cihaz",
    ar: "جهاز"
  },
  "SelectDevice": {
    ru: "Выберите устройство",
    kz: "Құрылғыны таңдаңыз",
    en: "Select device",
    es: "Seleccionar dispositivo",
    kg: "Түзүлүштү тандаңыз",
    uz: "Qurilmani tanlang",
    tr: "Cihaz seçin",
    ar: "اختر جهازًا"
  },
  "Desktop": {
    ru: "Компьютер",
    kz: "Компьютер",
    en: "Desktop",
    es: "Escritorio",
    kg: "Компьютер",
    uz: "Kompyuter",
    tr: "Masaüstü",
    ar: "سطح المكتب"
  },
  "Mobile": {
    ru: "Смартфон",
    kz: "Смартфон",
    en: "Mobile",
    es: "Móvil",
    kg: "Смартфон",
    uz: "Smartfon",
    tr: "Mobil",
    ar: "الجوال"
  },
  "Tablet": {
    ru: "Планшет",
    kz: "Планшет",
    en: "Tablet",
    es: "Tableta",
    kg: "Планшет",
    uz: "Planshet",
    tr: "Tablet",
    ar: "الجهاز اللوحي"
  },
  "System": {
    ru: "Система",
    kz: "Жүйе",
    en: "System",
    es: "Sistema",
    kg: "Система",
    uz: "Tizim",
    tr: "Sistem",
    ar: "نظام"
  },
  "SelectSystem": {
    ru: "Выберите систему",
    kz: "Жүйені таңдаңыз",
    en: "Select system",
    es: "Seleccionar sistema",
    kg: "Системаны тандаңыз",
    uz: "Tizimni tanlang",
    tr: "Sistem seçin",
    ar: "اختر نظامًا"
  },
  "Language": {
    ru: "Язык",
    kz: "Тіл",
    en: "Language",
    es: "Lenguaje",
    kg: "Тил",
    uz: "Til",
    tr: "Dil",
    ar: "لغة"
  },
  "SelectLanguage": {
    ru: "Выберите язык",
    kz: "Тілді таңдаңыз",
    en: "Select language",
    es: "Seleccionar lenguaje",
    kg: "Тилди тандаңыз",
    uz: "Tilni tanlang",
    tr: "Dil seçin",
    ar: "اختر لغة"
  },
  "DirectInput": {
    ru: "Прямой ввод",
    kz: "Тікелей енгізу",
    en: "Direct input",
    es: "Entrada directa",
    kg: "Түз киргизүү",
    uz: "To'g'ridan kiritish",
    tr: "Doğrudan giriş",
    ar: "إدخال مباشر"
  },
  "Upload": {
    ru: "Загрузить",
    kz: "Жүктеу",
    en: "Upload",
    es: "Cargar",
    kg: "Жүктөө",
    uz: "Yuklash",
    tr: "Yükle",
    ar: "تحميل"
  },
  "BackendCode": {
    ru: "Бэкенд код",
    kz: "Бэкенд коды",
    en: "Backend code",
    es: "Código backend",
    kg: "Бэкенд коду",
    uz: "Backend kodi",
    tr: "Backend kodu",
    ar: "كود الخلفية"
  },
  "Optional": {
    ru: "Опционально",
    kz: "Қосымша",
    en: "Optional",
    es: "Opcional",
    kg: "Кошумча",
    uz: "Ixtiyoriy",
    tr: "İsteğe bağlı",
    ar: "اختياري"
  },
  "BackendCodePlaceholder": {
    ru: "Введите бэкенд код на выбранном языке программирования...",
    kz: "Таңдалған бағдарламалау тілінде бэкенд кодын енгізіңіз...",
    en: "Enter backend code in the selected programming language...",
    es: "Ingrese código backend en el lenguaje de programación seleccionado...",
    kg: "Тандалган программалоо тилинде бэкенд кодун киргизиңиз...",
    uz: "Tanlangan dasturlash tilida backend kodini kiriting...",
    tr: "Seçilen programlama dilinde backend kodunu girin...",
    ar: "أدخل كود الخلفية بلغة البرمجة المحددة..."
  },
  "Import": {
    ru: "Импортировать",
    kz: "Импорттау",
    en: "Import",
    es: "Importar",
    kg: "Импорттоо",
    uz: "Import qilish",
    tr: "İçe Aktar",
    ar: "استيراد"
  },
  "GitHubImportDescription": {
    ru: "Введите URL GitHub репозитория для импорта и анализа кода",
    kz: "Кодты импорттау және талдау үшін GitHub репозиторийінің URL мекенжайын енгізіңіз",
    en: "Enter GitHub repository URL to import and analyze code",
    es: "Ingrese la URL del repositorio de GitHub para importar y analizar el código",
    kg: "Кодду импорттоо жана талдоо үчүн GitHub репозиторийинин URL дарегин киргизиңиз",
    uz: "Kodni import qilish va tahlil qilish uchun GitHub repositoriyasi URL-manzilini kiriting",
    tr: "Kodu içe aktarmak ve analiz etmek için GitHub deposu URL'sini girin",
    ar: "أدخل عنوان URL لمستودع GitHub لاستيراد وتحليل الكود"
  },
  "UploadZipFile": {
    ru: "Загрузить ZIP файл",
    kz: "ZIP файлын жүктеу",
    en: "Upload ZIP file",
    es: "Cargar archivo ZIP",
    kg: "ZIP файлын жүктөө",
    uz: "ZIP faylini yuklash",
    tr: "ZIP dosyası yükle",
    ar: "تحميل ملف ZIP"
  },
  "FileUploadDescription": {
    ru: "Загрузите ZIP файл с проектом для анализа",
    kz: "Талдау үшін жобасы бар ZIP файлын жүктеңіз",
    en: "Upload a ZIP file with the project for analysis",
    es: "Cargue un archivo ZIP con el proyecto para su análisis",
    kg: "Талдоо үчүн долбоору бар ZIP файлын жүктөңүз",
    uz: "Tahlil qilish uchun loyihasi bor ZIP faylini yuklang",
    tr: "Analiz için projenin bulunduğu bir ZIP dosyası yükleyin",
    ar: "قم بتحميل ملف ZIP مع المشروع للتحليل"
  },
  "AnalyzingFile": {
    ru: "Анализируем файл...",
    kz: "Файлды талдау...",
    en: "Analyzing file...",
    es: "Analizando archivo...",
    kg: "Файлды талдоо...",
    uz: "Faylni tahlil qilish...",
    tr: "Dosya analiz ediliyor...",
    ar: "جاري تحليل الملف..."
  },
  "AnalyzingRepository": {
    ru: "Анализируем репозиторий...",
    kz: "Репозиторийді талдау...",
    en: "Analyzing repository...",
    es: "Analizando repositorio...",
    kg: "Репозиторийди талдоо...",
    uz: "Repositoriyani tahlil qilish...",
    tr: "Depo analiz ediliyor...",
    ar: "جاري تحليل المستودع..."
  },
  "AnalyzingCode": {
    ru: "Анализируем код...",
    kz: "Кодты талдау...",
    en: "Analyzing code...",
    es: "Analizando código...",
    kg: "Кодду талдоо...",
    uz: "Kodni tahlil qilish...",
    tr: "Kod analiz ediliyor...",
    ar: "جاري تحليل الكود..."
  },
  "Analyzing": {
    ru: "Анализируем",
    kz: "Талдау",
    en: "Analyzing",
    es: "Analizando",
    kg: "Талдоо",
    uz: "Tahlil qilinmoqda",
    tr: "Analiz ediliyor",
    ar: "جاري التحليل"
  },
  "ThisMayTakeAMoment": {
    ru: "Это может занять некоторое время...",
    kz: "Бұл біраз уақыт алуы мүмкін...",
    en: "This may take a moment...",
    es: "Esto puede tomar un momento...",
    kg: "Бул бираз убакыт алышы мүмкүн...",
    uz: "Bu biroz vaqt olishi mumkin...",
    tr: "Bu biraz zaman alabilir...",
    ar: "قد يستغرق هذا لحظة..."
  },
  "EmulateInterface": {
    ru: "Эмулировать интерфейс",
    kz: "Интерфейсті эмуляциялау",
    en: "Emulate interface",
    es: "Emular interfaz",
    kg: "Интерфейсти эмуляциялоо",
    uz: "Interfeysni emulatsiya qilish",
    tr: "Arayüzü emüle et",
    ar: "محاكاة الواجهة"
  },
  "EmulatorPreview": {
    ru: "Предпросмотр эмулятора",
    kz: "Эмулятор алдын-ала көрінісі",
    en: "Emulator preview",
    es: "Vista previa del emulador",
    kg: "Эмулятордун алдын ала көрүнүшү",
    uz: "Emulyator ko'rinishi",
    tr: "Emülatör önizleme",
    ar: "معاينة المحاكي"
  },
  "Refresh": {
    ru: "Обновить",
    kz: "Жаңарту",
    en: "Refresh",
    es: "Actualizar",
    kg: "Жаңыртуу",
    uz: "Yangilash",
    tr: "Yenile",
    ar: "تحديث"
  },
  "NoPreviewAvailable": {
    ru: "Нет доступного предпросмотра",
    kz: "Алдын-ала көрініс қол жетімді емес",
    en: "No preview available",
    es: "No hay vista previa disponible",
    kg: "Алдын ала көрүнүш жок",
    uz: "Oldindan ko'rish mavjud emas",
    tr: "Önizleme mevcut değil",
    ar: "المعاينة غير متوفرة"
  },
  "EnterCodeOrImport": {
    ru: "Введите код или импортируйте его для предпросмотра",
    kz: "Алдын-ала қарау үшін кодты енгізіңіз немесе импорттаңыз",
    en: "Enter code or import it for preview",
    es: "Ingrese código o impórtelo para la vista previa",
    kg: "Алдын ала көрүү үчүн кодду киргизиңиз же импорттоңуз",
    uz: "Oldindan ko'rish uchun kodni kiriting yoki import qiling",
    tr: "Önizleme için kodu girin veya içe aktarın",
    ar: "أدخل الكود أو استورده للمعاينة"
  },
  "EmulatorDisclaimer": {
    ru: "Эмулятор предоставляет приблизительное представление о работе кода на разных устройствах и системах",
    kz: "Эмулятор әртүрлі құрылғылар мен жүйелердегі кодтың жұмысы туралы шамамен түсінік береді",
    en: "The emulator provides an approximate representation of how the code works on different devices and systems",
    es: "El emulador proporciona una representación aproximada de cómo funciona el código en diferentes dispositivos y sistemas",
    kg: "Эмулятор ар кандай түзүлүштөрдө жана системаларда кодун кандай иштей тургандыгы жөнүндө болжолдуу көрүнүш берет",
    uz: "Emulyator turli qurilmalarda va tizimlarda kodning qanday ishlashini taxminiy ko'rsatib beradi",
    tr: "Emülatör, kodun farklı cihazlarda ve sistemlerde nasıl çalıştığına dair yaklaşık bir temsil sağlar",
    ar: "يوفر المحاكي تمثيلاً تقريبيًا لكيفية عمل الكود على أجهزة وأنظمة مختلفة"
  },
  "EmulationResult": {
    ru: "Результат эмуляции",
    kz: "Эмуляция нәтижесі",
    en: "Emulation result",
    es: "Resultado de la emulación",
    kg: "Эмуляция жыйынтыгы",
    uz: "Emulatsiya natijasi",
    tr: "Emülasyon sonucu",
    ar: "نتيجة المحاكاة"
  },
  "AIGeneratedDescription": {
    ru: "Описание, сгенерированное ИИ",
    kz: "ЖИ тарапынан жасалған сипаттама",
    en: "AI generated description",
    es: "Descripción generada por IA",
    kg: "ЖИ түзгөн сүрөттөмө",
    uz: "AI tomonidan yaratilgan tavsif",
    tr: "AI tarafından oluşturulan açıklama",
    ar: "وصف تم إنشاؤه بواسطة الذكاء الاصطناعي"
  },
  "Description": {
    ru: "Описание",
    kz: "Сипаттама",
    en: "Description",
    es: "Descripción",
    kg: "Сүрөттөмө",
    uz: "Tavsif",
    tr: "Açıklama",
    ar: "الوصف"
  },
  "DetectedFeatures": {
    ru: "Обнаруженные функции",
    kz: "Анықталған функциялар",
    en: "Detected features",
    es: "Características detectadas",
    kg: "Табылган функциялар",
    uz: "Aniqlangan funksiyalar",
    tr: "Tespit edilen özellikler",
    ar: "الميزات المكتشفة"
  },
  "CopyCode": {
    ru: "Копировать код",
    kz: "Кодты көшіру",
    en: "Copy code",
    es: "Copiar código",
    kg: "Кодду көчүрүү",
    uz: "Kodni nusxalash",
    tr: "Kodu kopyala",
    ar: "نسخ الكود"
  },
  "EditEmulation": {
    ru: "Редактировать эмуляцию",
    kz: "Эмуляцияны өңдеу",
    en: "Edit emulation",
    es: "Editar emulación",
    kg: "Эмуляцияны түзөтүү",
    uz: "Emulatsiyani tahrirlash",
    tr: "Emülasyonu düzenle",
    ar: "تحرير المحاكاة"
  },
  "SaveProject": {
    ru: "Сохранить проект",
    kz: "Жобаны сақтау",
    en: "Save project",
    es: "Guardar proyecto",
    kg: "Долбоорду сактоо",
    uz: "Loyihani saqlash",
    tr: "Projeyi kaydet",
    ar: "حفظ المشروع"
  },
  "Error": {
    ru: "Ошибка",
    kz: "Қате",
    en: "Error",
    es: "Error",
    kg: "Ката",
    uz: "Xato",
    tr: "Hata",
    ar: "خطأ"
  },
  "PleaseEnterGitHubURL": {
    ru: "Пожалуйста, введите URL GitHub репозитория",
    kz: "GitHub репозиторийінің URL мекенжайын енгізіңіз",
    en: "Please enter a GitHub repository URL",
    es: "Por favor, ingrese una URL de repositorio de GitHub",
    kg: "GitHub репозиторийинин URL дарегин киргизиңиз",
    uz: "Iltimos, GitHub repositoriyasi URL-manzilini kiriting",
    tr: "Lütfen bir GitHub deposu URL'si girin",
    ar: "الرجاء إدخال عنوان URL لمستودع GitHub"
  },
  "PleaseSelectFile": {
    ru: "Пожалуйста, выберите файл",
    kz: "Файлды таңдаңыз",
    en: "Please select a file",
    es: "Por favor, seleccione un archivo",
    kg: "Файлды тандаңыз",
    uz: "Iltimos, faylni tanlang",
    tr: "Lütfen bir dosya seçin",
    ar: "الرجاء تحديد ملف"
  },
  "AnalysisComplete": {
    ru: "Анализ завершен",
    kz: "Талдау аяқталды",
    en: "Analysis complete",
    es: "Análisis completo",
    kg: "Талдоо аяктады",
    uz: "Tahlil tugallandi",
    tr: "Analiz tamamlandı",
    ar: "اكتمل التحليل"
  },
  "CodeAnalyzedSuccessfully": {
    ru: "Код успешно проанализирован",
    kz: "Код сәтті талданды",
    en: "Code analyzed successfully",
    es: "Código analizado exitosamente",
    kg: "Код ийгиликтүү талданды",
    uz: "Kod muvaffaqiyatli tahlil qilindi",
    tr: "Kod başarıyla analiz edildi",
    ar: "تم تحليل الكود بنجاح"
  },
  "AnalysisFailed": {
    ru: "Анализ не удался",
    kz: "Талдау сәтсіз аяқталды",
    en: "Analysis failed",
    es: "El análisis falló",
    kg: "Талдоо ийгиликсиз болду",
    uz: "Tahlil muvaffaqiyatsiz",
    tr: "Analiz başarısız oldu",
    ar: "فشل التحليل"
  },
  "ErrorAnalyzingCode": {
    ru: "Ошибка при анализе кода",
    kz: "Кодты талдау кезінде қате",
    en: "Error analyzing code",
    es: "Error al analizar el código",
    kg: "Кодду талдоодо ката",
    uz: "Kodni tahlil qilishda xatolik",
    tr: "Kodu analiz ederken hata",
    ar: "خطأ في تحليل الكود"
  },
  "ImportComplete": {
    ru: "Импорт завершен",
    kz: "Импорт аяқталды",
    en: "Import complete",
    es: "Importación completa",
    kg: "Импорт аяктады",
    uz: "Import tugallandi",
    tr: "İçe aktarma tamamlandı",
    ar: "اكتمل الاستيراد"
  },
  "CodeImportedFromGitHub": {
    ru: "Код успешно импортирован из GitHub",
    kz: "Код GitHub-тан сәтті импортталды",
    en: "Code successfully imported from GitHub",
    es: "Código importado exitosamente desde GitHub",
    kg: "Код GitHub-тан ийгиликтүү импорттолду",
    uz: "Kod GitHub-dan muvaffaqiyatli import qilindi",
    tr: "Kod GitHub'dan başarıyla içe aktarıldı",
    ar: "تم استيراد الكود بنجاح من GitHub"
  },
  "ImportFailed": {
    ru: "Импорт не удался",
    kz: "Импорт сәтсіз аяқталды",
    en: "Import failed",
    es: "La importación falló",
    kg: "Импорт ийгиликсиз болду",
    uz: "Import muvaffaqiyatsiz",
    tr: "İçe aktarma başarısız oldu",
    ar: "فشل الاستيراد"
  },
  "ErrorImportingFromGitHub": {
    ru: "Ошибка при импорте из GitHub",
    kz: "GitHub-тан импорттау кезінде қате",
    en: "Error importing from GitHub",
    es: "Error al importar desde GitHub",
    kg: "GitHub-тан импорттоодо ката",
    uz: "GitHub-dan import qilishda xatolik",
    tr: "GitHub'dan içe aktarma hatası",
    ar: "خطأ في الاستيراد من GitHub"
  },
  "CodeImportedFromFile": {
    ru: "Код успешно импортирован из файла",
    kz: "Код файлдан сәтті импортталды",
    en: "Code successfully imported from file",
    es: "Código importado exitosamente desde archivo",
    kg: "Код файлдан ийгиликтүү импорттолду",
    uz: "Kod fayldan muvaffaqiyatli import qilindi",
    tr: "Kod dosyadan başarıyla içe aktarıldı",
    ar: "تم استيراد الكود بنجاح من الملف"
  },
  "ErrorImportingFromFile": {
    ru: "Ошибка при импорте из файла",
    kz: "Файлдан импорттау кезінде қате",
    en: "Error importing from file",
    es: "Error al importar desde archivo",
    kg: "Файлдан импорттоодо ката",
    uz: "Fayldan import qilishda xatolik",
    tr: "Dosyadan içe aktarma hatası",
    ar: "خطأ في الاستيراد من الملف"
  }
};