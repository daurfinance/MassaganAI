import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile
} from "firebase/auth";
import { 
  getStorage, 
  ref, 
  uploadBytes, 
  getDownloadURL, 
  listAll, 
  deleteObject 
} from "firebase/storage";

// Firebase конфигурация
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.appspot.com`,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// Инициализация Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

// Функция для входа через Google
export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error("Ошибка при входе через Google:", error);
    throw error;
  }
};

// Функция для выхода из аккаунта
export const logOut = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Ошибка при выходе из аккаунта:", error);
    throw error;
  }
};

// Функция для регистрации по email и паролю
export const registerWithEmail = async (email: string, password: string, displayName: string) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    // Обновление профиля пользователя после регистрации
    if (userCredential.user) {
      await updateProfile(userCredential.user, {
        displayName: displayName
      });
    }
    return userCredential.user;
  } catch (error) {
    console.error("Ошибка при регистрации:", error);
    throw error;
  }
};

// Функция для входа по email и паролю
export const signInWithEmail = async (email: string, password: string) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Ошибка при входе:", error);
    throw error;
  }
};

// Хук для отслеживания состояния аутентификации
export const onAuthChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// Функции для работы с Firebase Storage

/**
 * Загружает файл в Firebase Storage
 * @param file Файл для загрузки
 * @param path Путь в хранилище (например: 'code/html/file.html')
 * @returns URL для доступа к файлу
 */
export const uploadFile = async (file: File, path: string): Promise<string> => {
  try {
    const storageRef = ref(storage, path);
    const snapshot = await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch (error) {
    console.error("Ошибка при загрузке файла:", error);
    throw error;
  }
};

/**
 * Загружает строковый контент как файл в Firebase Storage
 * @param content Строковый контент для загрузки
 * @param path Путь в хранилище
 * @param contentType Тип содержимого (например: 'text/html')
 * @returns URL для доступа к файлу
 */
export const uploadTextContent = async (content: string, path: string, contentType: string = 'text/plain'): Promise<string> => {
  try {
    const blob = new Blob([content], { type: contentType });
    const storageRef = ref(storage, path);
    const snapshot = await uploadBytes(storageRef, blob);
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch (error) {
    console.error("Ошибка при загрузке контента:", error);
    throw error;
  }
};

/**
 * Получает список файлов из директории в Firebase Storage
 * @param directory Путь к директории в хранилище
 * @returns Массив с метаданными файлов
 */
export const listFilesInDirectory = async (directory: string) => {
  try {
    const storageRef = ref(storage, directory);
    const fileList = await listAll(storageRef);
    
    const fileDetails = await Promise.all(
      fileList.items.map(async (itemRef) => {
        const url = await getDownloadURL(itemRef);
        return {
          name: itemRef.name,
          fullPath: itemRef.fullPath,
          url
        };
      })
    );
    
    return fileDetails;
  } catch (error) {
    console.error("Ошибка при получении списка файлов:", error);
    throw error;
  }
};

/**
 * Удаляет файл из Firebase Storage
 * @param path Путь к файлу в хранилище
 */
export const deleteFile = async (path: string): Promise<void> => {
  try {
    const storageRef = ref(storage, path);
    await deleteObject(storageRef);
  } catch (error) {
    console.error("Ошибка при удалении файла:", error);
    throw error;
  }
};