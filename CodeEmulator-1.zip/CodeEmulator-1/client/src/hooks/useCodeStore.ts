import { useState } from "react";

// Sample default code for new projects
const DEFAULT_HTML = `<!DOCTYPE html>
<html>
<head>
  <title>My Web Page</title>
</head>
<body>
  <h1>Hello, World!</h1>
  <p>This is a sample page. Upload your own HTML to see it here.</p>
  <button id="myButton">Click Me</button>
</body>
</html>`;

const DEFAULT_CSS = `body {
  font-family: Arial, sans-serif;
  margin: 20px;
  background-color: #f5f5f5;
}

h1 {
  color: #333;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #45a049;
}`;

const DEFAULT_JS = `document.addEventListener('DOMContentLoaded', function() {
  const button = document.getElementById('myButton');
  
  button.addEventListener('click', function() {
    alert('Button clicked!');
  });
});`;

export function useCodeStore() {
  // Store code in state
  const [htmlCode, setHtmlCode] = useState(DEFAULT_HTML);
  const [cssCode, setCssCode] = useState(DEFAULT_CSS);
  const [jsCode, setJsCode] = useState(DEFAULT_JS);

  // Handle code changes
  const handleCodeChange = (type: "html" | "css" | "js", code: string) => {
    switch (type) {
      case "html":
        setHtmlCode(code);
        break;
      case "css":
        setCssCode(code);
        break;
      case "js":
        setJsCode(code);
        break;
    }
  };

  // Reset to default code
  const resetToDefault = () => {
    setHtmlCode(DEFAULT_HTML);
    setCssCode(DEFAULT_CSS);
    setJsCode(DEFAULT_JS);
  };

  // Process uploaded files
  const processFiles = async (files: FileList) => {
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const content = await readFileContent(file);
      
      if (file.name.endsWith(".html")) {
        setHtmlCode(content);
      } else if (file.name.endsWith(".css")) {
        setCssCode(content);
      } else if (file.name.endsWith(".js")) {
        setJsCode(content);
      }
    }
  };

  // Read file content
  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          resolve(e.target.result as string);
        } else {
          reject(new Error("Failed to read file"));
        }
      };
      reader.onerror = (e) => {
        reject(e);
      };
      reader.readAsText(file);
    });
  };

  return {
    htmlCode,
    cssCode,
    jsCode,
    handleCodeChange,
    resetToDefault,
    processFiles
  };
}
