/**
 * Провайдер авторизации для MassaganAI
 * Заглушка для правильной работы приложения
 */

import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';

// Типы для пользователя
export interface User {
  id: number;
  username: string;
  email?: string;
}

// Тип контекста авторизации
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

// Создаем контекст
const AuthContext = createContext<AuthContextType | null>(null);

// Провайдер контекста
export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  // Проверка авторизации при загрузке
  const checkAuth = async (): Promise<void> => {
    try {
      // Здесь должен быть запрос на сервер для проверки текущей сессии
      // Для демо просто имитируем проверку с задержкой
      setTimeout(() => {
        // Здесь можно использовать сохраненные данные из localStorage, если есть
        const savedUser = localStorage.getItem('massaganUser');
        if (savedUser) {
          setUser(JSON.parse(savedUser));
        }
        setIsLoading(false);
      }, 500);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Unknown error occurred'));
      setIsLoading(false);
    }
  };

  // Авторизация пользователя
  const login = async (username: string, password: string): Promise<void> => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Имитация API-запроса
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Проверка демо-аккаунта
      if (username === 'daurfinance@gmail.com' && password === 'Azamat1993@') {
        const demoUser = { id: 1, username: 'daurfinance', email: 'daurfinance@gmail.com' };
        setUser(demoUser);
        // Сохраняем в localStorage для поддержки сессии
        localStorage.setItem('massaganUser', JSON.stringify(demoUser));
      } else {
        // Для других пользователей - обычно здесь был бы API-запрос
        const newUser = { id: 1, username };
        setUser(newUser);
        localStorage.setItem('massaganUser', JSON.stringify(newUser));
      }
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Login failed'));
    } finally {
      setIsLoading(false);
    }
  };

  // Регистрация пользователя
  const register = async (username: string, email: string, password: string): Promise<void> => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Имитация API-запроса
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newUser = { id: Date.now(), username, email };
      setUser(newUser);
      localStorage.setItem('massaganUser', JSON.stringify(newUser));
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Registration failed'));
    } finally {
      setIsLoading(false);
    }
  };

  // Выход пользователя
  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      
      // Имитация API-запроса
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Удаляем пользователя из состояния и localStorage
      setUser(null);
      localStorage.removeItem('massaganUser');
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Logout failed'));
    } finally {
      setIsLoading(false);
    }
  };

  // Выполняем проверку авторизации при монтировании компонента
  useEffect(() => {
    checkAuth();
  }, []);

  // Значение контекста
  const contextValue: AuthContextType = {
    user,
    isLoading,
    error,
    login,
    register,
    logout,
    checkAuth
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// Хук для использования контекста авторизации
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === null) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};