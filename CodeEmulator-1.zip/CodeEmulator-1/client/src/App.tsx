import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import NewHomePage from "@/pages/NewHomePage";
import MyProjects from "@/pages/MyProjects";
import AuthPage from "@/pages/AuthPage";
import Subscribe from "@/pages/Subscribe";
import SubscriptionSuccess from "@/pages/SubscriptionSuccess";
import PresentationsPage from "@/pages/PresentationsPage";
import BlueprintsPage from "@/pages/BlueprintsPage";
import ModelsPage from "@/pages/ModelsPage";
import AILabPage from "@/pages/AILabPage";
import EmulatorPage from "@/pages/EmulatorPage";
import { LanguageProvider } from "@/lib/LanguageContext";
import { AuthProvider } from "@/hooks/AuthProvider";

/**
 * MassaganAI: Универсальное Казахстанское ИИ решение
 * Поддерживает создание презентаций, чертежей, 3D моделей, генерацию медиаконтента,
 * автоматизацию создания дизайна и интерфейсов, генерацию фронтенда.
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */
function Router() {
  return (
    <Switch>
      <Route path="/" component={NewHomePage} />
      <Route path="/editor" component={Home} />
      <Route path="/emulator" component={EmulatorPage} />
      <Route path="/projects" component={MyProjects} />
      <Route path="/my-projects" component={MyProjects} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/subscribe" component={Subscribe} />
      <Route path="/subscription-success" component={SubscriptionSuccess} />
      <Route path="/presentations" component={PresentationsPage} />
      <Route path="/blueprints" component={BlueprintsPage} />
      <Route path="/models" component={ModelsPage} />
      <Route path="/ai-lab" component={AILabPage} />
      <Route path="/import" component={Home} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
