/**
 * Обновленный интерфейс главной страницы MassaganAI
 * Показывает все функции системы с современным и дружественным дизайном
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 * Обновлено: Апрель 2025
 */

import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import MassaganAILogo from '../components/MassaganAILogo';
import DocumentationSection from '../components/DocumentationSection';
import { useAuth } from '@/hooks/AuthProvider';
import { useLanguage } from '../lib/LanguageContext';
import { useToast } from '../hooks/use-toast';

// Иконки
import { 
  Code, 
  Cpu, 
  Film, 
  Image, 
  FileCode, 
  PenTool, 
  FileText, 
  Layers, 
  Terminal, 
  MessageCircle, 
  Upload, 
  Download,
  Presentation,
  Speaker,
  LibraryBig,
  Users,
  Zap,
  Box,
  LucideProps,
  BrainCircuit,
  Wallet,
  Bot,
  Mail,
  Share2,
  SquareCode,
  FlaskConical,
  Maximize,
  LayoutTemplate,
  Building,
  Import,
  Globe
} from 'lucide-react';

// UI компоненты
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Separator } from '../components/ui/separator';
import { Badge } from '../components/ui/badge';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
  delay?: number;
  isPremium?: boolean;
  isNew?: boolean;
  category?: string;
}

// Красивый компонент для карточек функций
const FeatureCard: React.FC<FeatureCardProps> = ({ 
  title, 
  description, 
  icon, 
  link,
  delay = 0,
  isPremium = false,
  isNew = false,
  category
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const { t } = useLanguage();
  
  // Цвета для категорий
  const categoryColors: Record<string, string> = {
    ai: 'bg-violet-500/10 text-violet-500 border-violet-500/20',
    media: 'bg-pink-500/10 text-pink-500 border-pink-500/20',
    presentation: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    social: 'bg-green-500/10 text-green-500 border-green-500/20',
    dev: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
    user: 'bg-slate-500/10 text-slate-500 border-slate-500/20'
  };
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay);
    
    return () => clearTimeout(timer);
  }, [delay]);
  
  return (
    <Card 
      className={`transition-all duration-500 transform ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
      } hover:shadow-lg hover:border-primary/50 group cursor-pointer h-full`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link href={link} className="h-full flex flex-col">
        <CardHeader className="relative flex flex-row items-center space-x-4 pb-2">
          <div className={`w-14 h-14 rounded-xl ${isHovered ? 'bg-primary text-primary-foreground' : 'bg-primary/10 text-primary'} 
            flex items-center justify-center transition-all duration-300 shadow-sm`}
          >
            {icon}
          </div>
          <div className="flex-1">
            <CardTitle className="text-xl group-hover:text-primary transition-colors">
              {title}
            </CardTitle>
            {category && (
              <Badge variant="outline" className={`mt-1 ${categoryColors[category] || ''}`}>
                {category === 'ai' ? 'ИИ & Код' : 
                 category === 'media' ? 'Медиа' : 
                 category === 'presentation' ? 'Презентации' : 
                 category === 'social' ? 'Соцсети' : 
                 category === 'dev' ? 'Разработка' : category}
              </Badge>
            )}
          </div>
          {(isPremium || isNew) && (
            <div className="absolute top-3 right-3 flex flex-col gap-2">
              {isPremium && <Badge variant="secondary" className="bg-amber-500/90 hover:bg-amber-500 text-white">Premium</Badge>}
              {isNew && <Badge variant="default" className="bg-green-500 hover:bg-green-600">Новое</Badge>}
            </div>
          )}
        </CardHeader>
        <CardContent className="flex-grow">
          <CardDescription className="text-md leading-relaxed">{description}</CardDescription>
        </CardContent>
        <CardFooter className="pt-2">
          <Button 
            variant={isHovered ? "default" : "ghost"} 
            className="ml-auto transition-all duration-300 gap-2"
          >
            {t('Open')}
            <span className={`transform transition-transform duration-300 ${isHovered ? 'translate-x-1' : ''}`}>→</span>
          </Button>
        </CardFooter>
      </Link>
    </Card>
  );
};

const NewHomePage: React.FC = () => {
  const { user } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('all');
  const [searchText, setSearchText] = useState('');
  
  // Градиентный текст
  const gradientTextClass = "bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600";
  
  // Все функции системы
  const allFeatures = [
    { 
      id: 'code-emulation', 
      title: t('AICodeEmulator'), 
      description: t('AICodeEmulatorDesc'), 
      icon: <Code size={24} />, 
      link: '/emulator',
      category: 'ai'
    },
    { 
      id: 'frontend-generator', 
      title: t('FrontendGenerator'), 
      description: t('FrontendGeneratorDesc'), 
      icon: <FileCode size={24} />, 
      link: '/frontend-generator',
      category: 'ai'
    },
    { 
      id: 'code-import', 
      title: t('CodeImport'), 
      description: t('CodeImportDesc'), 
      icon: <Upload size={24} />, 
      link: '/import',
      category: 'dev'
    },
    { 
      id: 'media-generator', 
      title: t('MediaGenerator'), 
      description: t('MediaGeneratorDesc'), 
      icon: <Image size={24} />, 
      link: '/media',
      category: 'media'
    },
    { 
      id: 'video-creator', 
      title: t('VideoCreator'), 
      description: t('VideoCreatorDesc'), 
      icon: <Film size={24} />, 
      link: '/video',
      category: 'media'
    },
    { 
      id: 'presentation', 
      title: t('PresentationCreator'), 
      description: t('PresentationCreatorDesc'), 
      icon: <Presentation size={24} />, 
      link: '/presentations',
      category: 'presentation'
    },
    { 
      id: 'blueprint', 
      title: t('BlueprintCreator'), 
      description: t('BlueprintCreatorDesc'), 
      icon: <PenTool size={24} />, 
      link: '/blueprints',
      category: 'presentation'
    },
    { 
      id: '3d-model', 
      title: t('3DModelCreator'), 
      description: t('3DModelCreatorDesc'), 
      icon: <Box size={24} />, 
      link: '/models',
      category: 'presentation'
    },
    { 
      id: 'social-media', 
      title: t('SocialMediaManager'), 
      description: t('SocialMediaManagerDesc'), 
      icon: <Users size={24} />, 
      link: '/social-media',
      category: 'social'
    },
    { 
      id: 'telegram-bot', 
      title: t('TelegramBot'), 
      description: t('TelegramBotDesc'), 
      icon: <MessageCircle size={24} />, 
      link: '/telegram',
      category: 'social'
    },
    { 
      id: 'speech', 
      title: t('SpeechSynthesizer'), 
      description: t('SpeechSynthesizerDesc'), 
      icon: <Speaker size={24} />, 
      link: '/speech',
      category: 'media'
    },
    { 
      id: 'ai-lab', 
      title: t('AILab'), 
      description: t('AILabDesc'), 
      icon: <FlaskConical size={24} />, 
      link: '/ai-lab',
      category: 'ai'
    },
    { 
      id: 'crypto-wallet', 
      title: t('CryptoWallet'), 
      description: t('CryptoWalletDesc'), 
      icon: <Wallet size={24} />, 
      link: '/wallet',
      category: 'user'
    },
    { 
      id: 'my-projects', 
      title: t('MyProjects'), 
      description: t('MyProjectsDesc'), 
      icon: <LibraryBig size={24} />, 
      link: '/projects',
      category: 'user'
    },
  ];
  
  // Фильтрация и поиск
  const filteredFeatures = allFeatures.filter(feature => {
    const matchesTab = activeTab === 'all' || feature.category === activeTab;
    const matchesSearch = searchText === '' || 
      feature.title.toLowerCase().includes(searchText.toLowerCase()) || 
      feature.description.toLowerCase().includes(searchText.toLowerCase());
    
    return matchesTab && matchesSearch;
  });
  
  // Эффект приветствия
  useEffect(() => {
    if (user) {
      toast({
        title: t('WelcomeBack'),
        description: `${t('LoggedInAs')} ${user.username || ''}`,
      });
    }
  }, [user, t, toast]);
  
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-background to-background/90">
      {/* Hero Section */}
      <section className="w-full py-12 px-4 sm:px-6 lg:px-8 text-center">
        <div className="flex flex-col items-center justify-center space-y-6">
          <MassaganAILogo size={150} theme="gradient" />
          
          <h1 className="text-4xl font-extrabold tracking-tight lg:text-5xl mt-4">
            <span className={gradientTextClass}>MassaganAI</span>
          </h1>
          
          <p className="text-xl text-muted-foreground max-w-2xl">
            {t('HeroDescription')}
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center mt-6">
            <Button size="lg" asChild>
              <Link href={user ? '/projects' : '/auth'}>
                {user ? t('MyProjects') : t('GetStarted')}
              </Link>
            </Button>
            
            <Button size="lg" variant="outline" asChild>
              <Link href="/presentations">
                {t('TryPresentations')}
              </Link>
            </Button>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="w-full py-12 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto space-y-8">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-bold">
              {t('AvailableFeatures')}
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              {t('FeaturesDescription')}
            </p>
          </div>
          
          <div className="flex flex-col space-y-4">
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row gap-4 justify-between">
              <Tabs 
                value={activeTab} 
                onValueChange={setActiveTab}
                className="w-full sm:w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">Все</TabsTrigger>
                  <TabsTrigger value="ai">ИИ & Код</TabsTrigger>
                  <TabsTrigger value="media">Медиа</TabsTrigger>
                  <TabsTrigger value="presentation">Презентации</TabsTrigger>
                  <TabsTrigger value="social">Соцсети</TabsTrigger>
                  <TabsTrigger value="user">Личное</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <div className="w-full sm:w-64">
                <Input 
                  placeholder={t('SearchFeatures')}
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                  className="w-full"
                />
              </div>
            </div>
            
            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
              {filteredFeatures.length > 0 ? (
                filteredFeatures.map((feature, index) => (
                  <FeatureCard
                    key={feature.id}
                    title={feature.title}
                    description={feature.description}
                    icon={feature.icon}
                    link={feature.link}
                    delay={100 * index}
                    category={feature.category}
                    isPremium={feature.id === 'ai-lab' || feature.id === 'crypto-wallet'}
                    isNew={feature.id === 'ai-lab' || feature.id === '3d-model'}
                  />
                ))
              ) : (
                <div className="col-span-3 text-center py-8">
                  <p className="text-muted-foreground">{t('NoFeaturesFound')}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
      
      {/* Документация проекта */}
      <DocumentationSection />
      
      {/* CTA Section */}
      <section className="w-full py-16 px-4 sm:px-6 lg:px-8 bg-primary/5 mt-12">
        <div className="container mx-auto flex flex-col items-center text-center space-y-6">
          <Zap size={48} className="text-primary" />
          
          <h2 className="text-3xl font-bold">
            {t('ReadyToStart')}
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-2xl">
            {t('CTADescription')}
          </p>
          
          <Button size="lg" asChild className="mt-4">
            <Link href="/subscribe">
              {t('UpgradeNow')}
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
};

export default NewHomePage;