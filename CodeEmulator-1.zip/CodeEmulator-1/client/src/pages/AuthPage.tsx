import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LogIn, Mail, Lock, Github, User, UserCircle2, CheckCircle, Shield, KeyRound, Rocket } from "lucide-react";
import { auth, signInWithGoogle, signInWithEmail, registerWithEmail } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import MassaganAILogo from "@/components/MassaganAILogo";
import { useLanguage } from "@/lib/LanguageContext";

export default function AuthPage() {
  const [_, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { t } = useLanguage();
  
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [registerName, setRegisterName] = useState("");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");

  useEffect(() => {
    // Проверка авторизации - если пользователь уже авторизован, редирект на главную
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (user) {
        setLocation("/");
      }
    });

    return () => unsubscribe();
  }, [setLocation]);

  const handleGoogleSignIn = async () => {
    try {
      setIsLoading(true);
      await signInWithGoogle();
      toast({
        title: "Успешный вход",
        description: "Вы успешно вошли в систему",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Ошибка входа",
        description: "Не удалось войти через Google",
        variant: "destructive",
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailSignIn = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!loginEmail || !loginPassword) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните все поля",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      // Проверка демо-аккаунта
      if (loginEmail === "daurfinance@gmail.com" && loginPassword === "Azamat1993@") {
        // Имитируем успешный вход через демо-аккаунт
        setTimeout(() => {
          // Создаем фиктивного пользователя в локальном хранилище
          localStorage.setItem("demoUser", JSON.stringify({
            uid: "demo-user-id",
            email: "daurfinance@gmail.com",
            displayName: "Демо Пользователь",
            isDemo: true
          }));
          
          toast({
            title: "Успешный вход",
            description: "Вы вошли с использованием демо-аккаунта",
          });
          setLocation("/");
        }, 1000);
        return;
      }
      
      // Обычная авторизация через Firebase
      await signInWithEmail(loginEmail, loginPassword);
      toast({
        title: "Успешный вход",
        description: "Вы успешно вошли в систему",
      });
      setLocation("/");
    } catch (error: any) {
      let errorMessage = "Не удалось войти. Проверьте email и пароль.";
      
      if (error.code === "auth/invalid-credential") {
        errorMessage = "Неверный email или пароль";
      } else if (error.code === "auth/user-not-found") {
        errorMessage = "Пользователь не найден";
      } else if (error.code === "auth/wrong-password") {
        errorMessage = "Неверный пароль";
      }
      
      toast({
        title: "Ошибка входа",
        description: errorMessage,
        variant: "destructive",
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEmailSignUp = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!registerName || !registerEmail || !registerPassword) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, заполните все поля",
        variant: "destructive",
      });
      return;
    }

    if (registerPassword.length < 6) {
      toast({
        title: "Ошибка",
        description: "Пароль должен содержать не менее 6 символов",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsLoading(true);
      await registerWithEmail(registerEmail, registerPassword, registerName);
      toast({
        title: "Успешная регистрация",
        description: "Вы успешно зарегистрировались",
      });
      setLocation("/");
    } catch (error: any) {
      let errorMessage = "Не удалось зарегистрироваться";
      
      if (error.code === "auth/email-already-in-use") {
        errorMessage = "Email уже используется";
      } else if (error.code === "auth/invalid-email") {
        errorMessage = "Некорректный email";
      } else if (error.code === "auth/weak-password") {
        errorMessage = "Слишком слабый пароль";
      }
      
      toast({
        title: "Ошибка регистрации",
        description: errorMessage,
        variant: "destructive",
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen">
      {/* Левая часть - форма авторизации */}
      <div className="flex w-full md:w-1/2 flex-col justify-center p-8">
        <div className="mx-auto w-full max-w-md">
          <div className="mb-8 text-center">
            <div className="flex justify-center mb-4">
              <MassaganAILogo size={100} animated={true} theme="platinum" />
            </div>
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500">
              {t('AppName') || 'Massagan AI'}
            </h1>
            <p className="mt-3 text-muted-foreground">
              {t('AppDescription') || 'Революционный AI-инструмент для разработки'}
            </p>
          </div>

          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="login">Вход</TabsTrigger>
              <TabsTrigger value="register">Регистрация</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Вход в систему</CardTitle>
                  <CardDescription>
                    Войдите в свой аккаунт для доступа к своим проектам
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <form id="login-form" onSubmit={handleEmailSignIn} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="email"
                          placeholder="example@email.com"
                          type="email"
                          className="pl-10"
                          required
                          value={loginEmail}
                          onChange={(e) => setLoginEmail(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="password">Пароль</Label>
                        <Button variant="link" className="h-auto p-0 text-sm">
                          Забыли пароль?
                        </Button>
                      </div>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="password"
                          type="password"
                          className="pl-10"
                          required
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? (
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent mr-2"></span>
                      ) : (
                        <LogIn className="mr-2 h-4 w-4" />
                      )}
                      Войти
                    </Button>
                    
                    {/* Кнопка для быстрого входа через демо-аккаунт */}
                    <Button 
                      type="button" 
                      variant="secondary" 
                      className="w-full mt-2" 
                      disabled={isLoading}
                      onClick={() => {
                        setLoginEmail("daurfinance@gmail.com");
                        setLoginPassword("Azamat1993@");
                        
                        // Небольшая задержка перед автоматической отправкой формы
                        setTimeout(() => {
                          const form = document.getElementById("login-form") as HTMLFormElement;
                          if (form) form.dispatchEvent(new Event("submit", { cancelable: true }));
                        }, 300);
                      }}
                    >
                      <span className="flex items-center justify-center">
                        <span className="mr-2 bg-gradient-to-r from-indigo-400 to-purple-500 p-1 rounded-full">
                          <User className="h-3.5 w-3.5 text-white" />
                        </span>
                        Демо доступ
                      </span>
                    </Button>
                  </form>

                  <div className="relative my-4">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t"></span>
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">
                        или войти через
                      </span>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleGoogleSignIn}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-indigo-500 border-t-transparent mr-2"></span>
                    ) : (
                      <svg
                        className="mr-2 h-4 w-4"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                      >
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        />
                      </svg>
                    )}
                    Google
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      toast({
                        title: "В разработке",
                        description: "Авторизация через GitHub временно недоступна",
                      });
                    }}
                  >
                    <Github className="mr-2 h-4 w-4" />
                    GitHub
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Создать аккаунт</CardTitle>
                  <CardDescription>
                    Зарегистрируйтесь для доступа к полному функционалу сервиса
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <form onSubmit={handleEmailSignUp} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Имя</Label>
                      <div className="relative">
                        <UserCircle2 className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="name"
                          placeholder="Ваше имя"
                          className="pl-10"
                          required
                          value={registerName}
                          onChange={(e) => setRegisterName(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-email"
                          placeholder="example@email.com"
                          type="email"
                          className="pl-10"
                          required
                          value={registerEmail}
                          onChange={(e) => setRegisterEmail(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="register-password">Пароль</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-password"
                          type="password"
                          className="pl-10"
                          required
                          value={registerPassword}
                          onChange={(e) => setRegisterPassword(e.target.value)}
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? (
                        <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent mr-2"></span>
                      ) : (
                        <User className="mr-2 h-4 w-4" />
                      )}
                      Зарегистрироваться
                    </Button>
                  </form>

                  <div className="relative my-4">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t"></span>
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">
                        или регистрация через
                      </span>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleGoogleSignIn}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <span className="h-4 w-4 animate-spin rounded-full border-2 border-indigo-500 border-t-transparent mr-2"></span>
                    ) : (
                      <svg
                        className="mr-2 h-4 w-4"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        width="24"
                        height="24"
                      >
                        <path
                          fill="#4285F4"
                          d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                        />
                        <path
                          fill="#34A853"
                          d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                        />
                        <path
                          fill="#EA4335"
                          d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                        />
                      </svg>
                    )}
                    Google
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      toast({
                        title: "В разработке",
                        description: "Регистрация через GitHub временно недоступна",
                      });
                    }}
                  >
                    <Github className="mr-2 h-4 w-4" />
                    GitHub
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Правая часть - информация о приложении */}
      <div className="hidden md:flex md:w-1/2 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600"></div>
        <div className="relative h-full w-full flex flex-col items-center justify-center text-white p-8">
          <div className="mb-8">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="h-16 w-16 text-white opacity-80"
            >
              <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
              <polyline points="7.5 4.21 12 6.81 16.5 4.21"></polyline>
              <polyline points="7.5 19.79 7.5 14.6 3 12"></polyline>
              <polyline points="21 12 16.5 14.6 16.5 19.79"></polyline>
              <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
              <line x1="12" y1="22.08" x2="12" y2="12"></line>
            </svg>
          </div>
          <h2 className="text-3xl font-bold mb-4 text-center">Будущее разработки уже здесь</h2>
          <p className="text-lg text-center mb-6 max-w-md opacity-90">
            Massagan AI - революционный инструмент, который анализирует ваш код и создаёт 
            готовый дизайн и интерфейс, соединяет бэкенд с фронтендом, и многое другое.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-md">
            <div className="flex flex-col items-center p-4 bg-white bg-opacity-10 rounded-lg">
              <div className="rounded-full bg-white bg-opacity-20 p-3 mb-3">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="h-6 w-6"
                >
                  <path d="M12 19l7-7 3 3-7 7-3-3z"></path>
                  <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path>
                  <path d="M2 2l7.586 7.586"></path>
                  <circle cx="11" cy="11" r="2"></circle>
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-1">Дизайн в один клик</h3>
              <p className="text-sm text-center opacity-90">
                Автоматически генерирует красивый дизайн из вашего кода
              </p>
            </div>
            <div className="flex flex-col items-center p-4 bg-white bg-opacity-10 rounded-lg">
              <div className="rounded-full bg-white bg-opacity-20 p-3 mb-3">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="h-6 w-6"
                >
                  <polyline points="16 18 22 12 16 6"></polyline>
                  <polyline points="8 6 2 12 8 18"></polyline>
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-1">Полная интеграция</h3>
              <p className="text-sm text-center opacity-90">
                Соединяет бэкенд и фронтенд в единое целое
              </p>
            </div>
            <div className="flex flex-col items-center p-4 bg-white bg-opacity-10 rounded-lg">
              <div className="rounded-full bg-white bg-opacity-20 p-3 mb-3">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="h-6 w-6"
                >
                  <path d="M14.5 10c-.83 0-1.5-.67-1.5-1.5v-5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5z"></path>
                  <path d="M20.5 10H19V8.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"></path>
                  <path d="M9.5 14c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5S8 21.33 8 20.5v-5c0-.83.67-1.5 1.5-1.5z"></path>
                  <path d="M3.5 14H5v1.5c0 .83-.67 1.5-1.5 1.5S2 16.33 2 15.5 2.67 14 3.5 14z"></path>
                  <path d="M14 14.5c0-.83.67-1.5 1.5-1.5h5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-5c-.83 0-1.5-.67-1.5-1.5z"></path>
                  <path d="M15.5 19H14v1.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5-.67-1.5-1.5-1.5z"></path>
                  <path d="M10 9.5C10 8.67 9.33 8 8.5 8h-5C2.67 8 2 8.67 2 9.5S2.67 11 3.5 11h5c.83 0 1.5-.67 1.5-1.5z"></path>
                  <path d="M8.5 5H10V3.5C10 2.67 9.33 2 8.5 2S7 2.67 7 3.5 7.67 5 8.5 5z"></path>
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-1">Умный импорт</h3>
              <p className="text-sm text-center opacity-90">
                Загрузка кода из GitHub и ZIP-файлов
              </p>
            </div>
            <div className="flex flex-col items-center p-4 bg-white bg-opacity-10 rounded-lg">
              <div className="rounded-full bg-white bg-opacity-20 p-3 mb-3">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="h-6 w-6"
                >
                  <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                  <line x1="8" y1="21" x2="16" y2="21"></line>
                  <line x1="12" y1="17" x2="12" y2="21"></line>
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-1">Мультиплатформенность</h3>
              <p className="text-sm text-center opacity-90">
                Поддержка эмуляторов для Android, iPhone, Windows и macOS
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}