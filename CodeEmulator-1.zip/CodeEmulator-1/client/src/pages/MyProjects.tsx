import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlusCircle, Code, BotMessageSquare, FileText, Edit, Trash, ChevronRight, GitBranch, Eye } from "lucide-react";
import { auth } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import TelegramBotGenerator from "@/components/TelegramBotGenerator";

interface Project {
  id: string;
  name: string;
  description: string;
  type: 'code' | 'telegram-bot';
  createdAt: Date;
  lastUpdated: Date;
}

export default function MyProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>("projects");
  const [_, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // Проверка авторизации
    const unsubscribe = auth.onAuthStateChanged((user) => {
      if (!user) {
        // Если пользователь не авторизован, перенаправляем на главную
        setLocation("/");
        toast({
          title: "Необходима авторизация",
          description: "Пожалуйста, войдите в систему для доступа к проектам",
          variant: "destructive",
        });
      } else {
        // Загрузка проектов пользователя
        // В реальном приложении здесь был бы запрос к Firebase 
        // для получения проектов пользователя
        setProjects([
          {
            id: "proj1",
            name: "Личный сайт-портфолио",
            description: "Одностраничный сайт с адаптивным дизайном",
            type: "code",
            createdAt: new Date("2024-03-15"),
            lastUpdated: new Date("2024-03-20"),
          },
          {
            id: "proj2",
            name: "WeatherNotifierBot",
            description: "Телеграм бот для уведомлений о погоде",
            type: "telegram-bot",
            createdAt: new Date("2024-04-01"),
            lastUpdated: new Date("2024-04-05"),
          },
        ]);
        setIsLoading(false);
      }
    });

    return () => unsubscribe();
  }, [setLocation, toast]);

  const deleteProject = (id: string) => {
    // В реальном приложении здесь был бы запрос для удаления проекта
    setProjects((prev) => prev.filter((p) => p.id !== id));
    toast({
      title: "Проект удален",
      description: "Проект был успешно удален",
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600">
          Мои проекты
        </h1>
        {activeTab === "projects" && (
          <div className="flex gap-3">
            <Button 
              onClick={() => setLocation("/")}
              className="flex items-center gap-2"
              variant="outline"
            >
              <Code className="h-4 w-4" />
              Новый код
            </Button>
            <Button
              onClick={() => setActiveTab("create-bot")}
              className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              <BotMessageSquare className="h-4 w-4" />
              Создать Telegram бота
            </Button>
          </div>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-2 mb-6">
          <TabsTrigger value="projects" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Все проекты
          </TabsTrigger>
          <TabsTrigger value="create-bot" className="flex items-center gap-2">
            <BotMessageSquare className="h-4 w-4" />
            Создать Telegram бота
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="projects">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-indigo-500 border-t-transparent"></div>
              <p className="mt-2 text-gray-600">Загрузка проектов...</p>
            </div>
          ) : projects.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
              <FileText className="h-12 w-12 mx-auto text-gray-400 mb-3" />
              <h3 className="text-lg font-medium text-gray-700 mb-1">Нет созданных проектов</h3>
              <p className="text-gray-500 mb-4">Создайте новый проект или Telegram бота</p>
              <Button
                onClick={() => setActiveTab("create-bot")}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Создать Telegram бота
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <Card key={project.id} className="overflow-hidden border border-gray-200 hover:border-indigo-300 hover:shadow-md transition-all duration-300">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <Badge variant={project.type === "code" ? "default" : "secondary"} className="mb-2">
                        {project.type === "code" ? "Код" : "Telegram бот"}
                      </Badge>
                      <div className="text-xs text-gray-500">
                        Создан: {formatDate(project.createdAt)}
                      </div>
                    </div>
                    <CardTitle className="text-xl">{project.name}</CardTitle>
                    <CardDescription>{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="text-sm text-gray-500">
                      Последнее обновление: {formatDate(project.lastUpdated)}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between pt-2">
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" className="h-8 px-2 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                        onClick={() => deleteProject(project.id)}
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 px-2 text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 border-indigo-200">
                        <Edit className="h-4 w-4" />
                      </Button>
                    </div>
                    <Button size="sm" className="h-8 bg-indigo-600 hover:bg-indigo-700 flex items-center gap-1">
                      {project.type === "code" ? (
                        <>
                          <Eye className="h-4 w-4" />
                          <span className="ml-1">Открыть</span>
                        </>
                      ) : (
                        <>
                          <BotMessageSquare className="h-4 w-4" />
                          <span className="ml-1">Запустить</span>
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
              
              {/* Карточка для создания нового проекта */}
              <Card className="overflow-hidden border-2 border-dashed border-gray-200 hover:border-indigo-300 transition-all duration-300 flex flex-col justify-center items-center p-8 cursor-pointer"
                onClick={() => setActiveTab("create-bot")}
              >
                <div className="rounded-full bg-indigo-100 p-4 mb-4">
                  <PlusCircle className="h-8 w-8 text-indigo-600" />
                </div>
                <CardTitle className="text-lg text-center mb-2">Создать новый проект</CardTitle>
                <CardDescription className="text-center">
                  Создайте новый код или Telegram бота
                </CardDescription>
              </Card>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="create-bot">
          <TelegramBotGenerator />
        </TabsContent>
      </Tabs>
    </div>
  );
}