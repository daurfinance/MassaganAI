/**
 * MassaganAI: Страница ИИ-эмулятора
 * Интерфейс для загрузки и эмуляции кода с поддержкой различных устройств и систем
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React from 'react';
import { useLanguage } from '@/lib/LanguageContext';
import { useAuth } from '@/hooks/AuthProvider';
import AIEmulator from '@/components/AIEmulator';
import { Code, Cpu, GitBranch, Braces, FileCode, Smartphone, Monitor } from 'lucide-react';

const EmulatorPage: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();

  return (
    <div className="container mx-auto py-6 px-4">
      <div className="mb-8">
        <div className="flex flex-col md:flex-row justify-between gap-4 mb-4">
          <div className="flex items-center space-x-4">
            <div className="bg-primary/10 p-3 rounded-lg">
              <Code size={24} className="text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{t('AICodeEmulator')}</h1>
              <p className="text-muted-foreground">{t('AICodeEmulatorDesc')}</p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          <div className="flex bg-muted/30 rounded-lg p-3">
            <Cpu className="h-5 w-5 text-primary mr-2" />
            <div>
              <h3 className="text-sm font-medium">{t('AICodeAnalysis')}</h3>
              <p className="text-xs text-muted-foreground">{t('AIAnalyzesCode')}</p>
            </div>
          </div>
          
          <div className="flex bg-muted/30 rounded-lg p-3">
            <GitBranch className="h-5 w-5 text-primary mr-2" />
            <div>
              <h3 className="text-sm font-medium">{t('GitHubIntegration')}</h3>
              <p className="text-xs text-muted-foreground">{t('ImportFromGitHub')}</p>
            </div>
          </div>
          
          <div className="flex bg-muted/30 rounded-lg p-3">
            <Braces className="h-5 w-5 text-primary mr-2" />
            <div>
              <h3 className="text-sm font-medium">{t('MultiLanguageSupport')}</h3>
              <p className="text-xs text-muted-foreground">{t('SupportForMultipleLanguages')}</p>
            </div>
          </div>
          
          <div className="flex bg-muted/30 rounded-lg p-3">
            <Smartphone className="h-5 w-5 text-primary mr-2" />
            <div>
              <h3 className="text-sm font-medium">{t('MultiDeviceEmulation')}</h3>
              <p className="text-xs text-muted-foreground">{t('EmulateOnDifferentDevices')}</p>
            </div>
          </div>
        </div>
      </div>
      
      <AIEmulator />
    </div>
  );
};

export default EmulatorPage;