import { useRef, useState } from "react";
import Header from "@/components/Header";
import WelcomeScreen from "@/components/WelcomeScreen";
import EditorLayout from "@/components/EditorLayout";
import ImportFromGithub from "@/components/ImportFromGithub";
import AITools from "@/components/AITools";
import { useCodeStore } from "@/hooks/useCodeStore";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Sparkles, X } from "lucide-react";

declare global {
  interface Window {
    Split: any;
  }
}

export default function Home() {
  const [showEditor, setShowEditor] = useState(false);
  const [showAIEmulator, setShowAIEmulator] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { htmlCode, cssCode, jsCode, handleCodeChange, resetToDefault, processFiles } = useCodeStore();
  const { toast } = useToast();

  const handleNewProject = () => {
    if (!showEditor) {
      setShowEditor(true);
    } else if (confirm("Начать новый проект? Текущие изменения будут потеряны.")) {
      resetToDefault();
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      try {
        await processFiles(e.target.files);
        setShowEditor(true);
        toast({
          title: "Файлы загружены",
          description: `${e.target.files.length} файл(ов) успешно загружено`,
        });
      } catch (error) {
        toast({
          title: "Ошибка",
          description: "Не удалось обработать загруженные файлы",
          variant: "destructive",
        });
      }
    }
  };

  const handleFileDrop = async (files: FileList) => {
    try {
      await processFiles(files);
      setShowEditor(true);
      toast({
        title: "Файлы загружены",
        description: `${files.length} файл(ов) успешно загружено`,
      });
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось обработать перетащенные файлы",
        variant: "destructive",
      });
    }
  };

  // Обработчик для импорта кода из GitHub/ZIP
  const handleImportCode = (htmlCode: string, cssCode: string, jsCode: string) => {
    if (htmlCode || cssCode || jsCode) {
      handleCodeChange("html", htmlCode);
      handleCodeChange("css", cssCode);
      handleCodeChange("js", jsCode);
      setShowEditor(true);
      toast({
        title: "Код импортирован",
        description: "Код успешно импортирован и загружен в редактор",
      });
    } else {
      toast({
        title: "Ошибка",
        description: "Не удалось найти HTML, CSS или JavaScript код в импортированных файлах",
        variant: "destructive",
      });
    }
  };
  
  // Обработчик для переключения отображения ИИ-эмулятора
  const toggleAIEmulator = () => {
    setShowAIEmulator(!showAIEmulator);
  };
  
  // Обработчик для применения сгенерированного кода
  const handleApplyGeneratedCode = (html: string, css: string, js: string) => {
    handleCodeChange("html", html);
    handleCodeChange("css", css);
    handleCodeChange("js", js);
    
    toast({
      title: "Код ИИ применен",
      description: "Сгенерированный ИИ код успешно применен к проекту",
    });
  };
  
  // Обработчик для применения сгенерированного проекта
  const handleApplyProjectCode = (files: {
    frontend: {
      components: Array<{name: string, path: string, code: string}>,
      pages: Array<{name: string, path: string, code: string}>
    },
    backend: {
      routes: Array<{name: string, path: string, code: string}>,
      models: Array<{name: string, path: string, code: string}>,
      server: {name: string, path: string, code: string} | null
    }
  }) => {
    // Для демонстрации возьмем первую страницу и превратим её в HTML
    if (files.frontend.pages.length > 0) {
      const mainPage = files.frontend.pages[0];
      // Подготовим демо HTML, который покажет структуру React компонента
      const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${mainPage.name}</title>
</head>
<body>
  <div id="root">
    <!-- React компонент будет отрендерен здесь -->
    <pre style="font-family: monospace; background-color: #f5f5f5; padding: 1rem; border-radius: 5px; overflow: auto; max-height: 60vh;">
      ${mainPage.code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}
    </pre>
  </div>
</body>
</html>
      `;
      handleCodeChange("html", html);
      
      // Добавим CSS для демонстрации
      const css = `
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  margin: 0;
  padding: 20px;
  background-color: #f8f9fa;
}

#root {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

h1, h2, h3 {
  color: #333;
}

pre {
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 4px;
  overflow-x: auto;
}
      `;
      handleCodeChange("css", css);
      
      // Добавим JS для создания демо интерактивности
      const js = `
console.log('Сгенерированный проект:');
console.log('Фронтенд Компоненты:', ${JSON.stringify(files.frontend.components.map(c => c.name))});
console.log('Фронтенд Страницы:', ${JSON.stringify(files.frontend.pages.map(p => p.name))});
console.log('Бэкенд Маршруты:', ${JSON.stringify(files.backend.routes.map(r => r.name))});
console.log('Бэкенд Модели:', ${JSON.stringify(files.backend.models.map(m => m.name))});
console.log('Бэкенд Сервер:', ${files.backend.server ? `'${files.backend.server.name}'` : 'null'});

// Создаем навигацию по сгенерированным файлам
const root = document.getElementById('root');
const nav = document.createElement('nav');
nav.style.marginBottom = '20px';
nav.style.padding = '10px';
nav.style.backgroundColor = '#f0f4f8';
nav.style.borderRadius = '4px';

const title = document.createElement('h2');
title.textContent = 'Сгенерированные файлы проекта:';
nav.appendChild(title);

// Функция для создания секции навигации
function createSection(title, items) {
  const section = document.createElement('div');
  section.style.marginBottom = '15px';
  
  const header = document.createElement('h3');
  header.textContent = title;
  header.style.marginBottom = '5px';
  section.appendChild(header);
  
  const list = document.createElement('ul');
  items.forEach(item => {
    const li = document.createElement('li');
    li.textContent = \`\${item.name} (\${item.path})\`;
    li.style.cursor = 'pointer';
    li.style.color = '#0066cc';
    li.style.marginBottom = '3px';
    li.addEventListener('click', () => {
      // При клике обновляем содержимое pre тега
      const codeDisplay = document.querySelector('pre');
      codeDisplay.textContent = item.code;
    });
    list.appendChild(li);
  });
  section.appendChild(list);
  return section;
}

// Добавляем секции
if (${files.frontend.components.length > 0}) {
  nav.appendChild(createSection('Компоненты', ${JSON.stringify(files.frontend.components)}));
}
if (${files.frontend.pages.length > 0}) {
  nav.appendChild(createSection('Страницы', ${JSON.stringify(files.frontend.pages)}));
}
if (${files.backend.routes.length > 0}) {
  nav.appendChild(createSection('Маршруты API', ${JSON.stringify(files.backend.routes)}));
}
if (${files.backend.models.length > 0}) {
  nav.appendChild(createSection('Модели данных', ${JSON.stringify(files.backend.models)}));
}
if (${!!files.backend.server}) {
  nav.appendChild(createSection('Сервер', [${files.backend.server ? JSON.stringify(files.backend.server) : ''}]));
}

// Вставляем навигацию перед pre тегом
root.insertBefore(nav, root.querySelector('pre'));
      `;
      handleCodeChange("js", js);
    }
    
    toast({
      title: "Проект создан",
      description: "Сгенерированный проект был успешно создан",
    });
  };

  // Load Split.js from CDN
  useState(() => {
    if (typeof window !== 'undefined' && !window.Split) {
      const script = document.createElement('script');
      script.src = 'https://unpkg.com/split.js/dist/split.min.js';
      script.async = true;
      document.body.appendChild(script);
    }
  });

  return (
    <div className="flex flex-col min-h-screen">
      <Header 
        onNewProject={handleNewProject} 
        onUploadCode={handleUploadClick}
        onImportCode={handleImportCode}
      />
      
      <input 
        type="file" 
        ref={fileInputRef}
        className="hidden" 
        multiple 
        accept=".html,.css,.js"
        onChange={handleFileChange}
      />

      {!showEditor ? (
        <WelcomeScreen 
          onUpload={handleUploadClick}
          onDrop={handleFileDrop}
          onImportCode={handleImportCode}
        />
      ) : (
        <div className="flex flex-col flex-grow relative">
          <EditorLayout 
            htmlCode={htmlCode}
            cssCode={cssCode}
            jsCode={jsCode}
            onCodeChange={handleCodeChange}
          />
          
          {/* Кнопка для открытия/закрытия ИИ-эмулятора */}
          <div className="fixed bottom-6 right-6 z-50">
            <Button
              onClick={toggleAIEmulator}
              className={`rounded-full w-14 h-14 shadow-lg ${
                showAIEmulator ? "bg-red-500 hover:bg-red-600" : "bg-blue-600 hover:bg-blue-700"
              }`}
              aria-label={showAIEmulator ? "Закрыть ИИ-инструменты" : "Открыть ИИ-инструменты"}
              size="lg"
            >
              {showAIEmulator ? <X className="h-6 w-6" /> : <Sparkles className="h-6 w-6" />}
            </Button>
          </div>
          
          {/* Панель ИИ-инструментов */}
          {showAIEmulator && (
            <div className="fixed bottom-24 right-6 w-[80vw] max-w-4xl bg-white shadow-2xl rounded-lg z-40 border border-gray-200 max-h-[80vh] overflow-auto">
              <AITools
                htmlCode={htmlCode}
                cssCode={cssCode}
                jsCode={jsCode}
                onApplyGeneratedCode={handleApplyGeneratedCode}
                onApplyProjectCode={handleApplyProjectCode}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
