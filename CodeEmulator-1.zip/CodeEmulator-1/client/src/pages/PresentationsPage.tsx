/**
 * Страница создания презентаций MassaganAI
 * Поддерживает генерацию моков и анимированных презентаций по промпту с озвучкой
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/AuthProvider';
import { useLanguage } from '../lib/LanguageContext';
import { useToast } from '../hooks/use-toast';
import { queryClient, apiRequest } from '../lib/queryClient';

// Иконки
import { 
  Presentation, 
  FileText, 
  Play, 
  Download, 
  Loader2, 
  Plus, 
  Mic, 
  Image, 
  Film,
  Palette,
  Bookmark,
  MoreVertical,
  Languages
} from 'lucide-react';

// UI компоненты
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Switch } from '../components/ui/switch';
import { Slider } from '../components/ui/slider';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '../components/ui/dropdown-menu';
import MassaganAILogo from '../components/MassaganAILogo';

// Типы презентаций
type PresentationType = 'standard' | 'animated' | 'infographic' | 'pitch' | 'mockup';

// Структура для хранения презентации
interface Presentation {
  id: string;
  prompt: string;
  type: PresentationType;
  pptxPath?: string;
  pdfPath?: string;
  videoPath?: string;
  audioPath?: string;
  thumbnailPath?: string;
  slidesCount: number;
  createdAt: string;
}

// Параметры запроса на создание презентации
interface PresentationRequest {
  prompt: string;
  type: PresentationType;
  slides?: number;
  audioEnabled?: boolean;
  language?: string;
  theme?: string;
  style?: string;
}

// Компонент карточки презентации
const PresentationCard: React.FC<{ presentation: Presentation }> = ({ presentation }) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  
  const handleDownload = (path: string | undefined, type: string) => {
    if (!path) {
      toast({
        title: t('Error'),
        description: t('FileNotAvailable'),
        variant: 'destructive',
      });
      return;
    }
    
    // Создаем ссылку для скачивания файла
    const link = document.createElement('a');
    link.href = path;
    link.download = `MassaganAI_${presentation.type}_${type}_${new Date().toISOString().slice(0, 10)}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: t('DownloadStarted'),
      description: t('FileDownloading'),
    });
  };
  
  // Форматирование даты
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };
  
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all">
      <div className="relative aspect-video bg-muted">
        {presentation.thumbnailPath ? (
          <img 
            src={presentation.thumbnailPath} 
            alt={presentation.prompt}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/10">
            <Presentation size={48} className="text-primary/50" />
          </div>
        )}
        
        <div className="absolute top-2 right-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="bg-background/80 hover:bg-background rounded-full h-8 w-8">
                <MoreVertical size={16} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t('Options')}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {presentation.pptxPath && (
                <DropdownMenuItem onClick={() => handleDownload(presentation.pptxPath, 'pptx')}>
                  <FileText className="mr-2 h-4 w-4" /> {t('DownloadPPTX')}
                </DropdownMenuItem>
              )}
              {presentation.pdfPath && (
                <DropdownMenuItem onClick={() => handleDownload(presentation.pdfPath, 'pdf')}>
                  <FileText className="mr-2 h-4 w-4" /> {t('DownloadPDF')}
                </DropdownMenuItem>
              )}
              {presentation.videoPath && (
                <DropdownMenuItem onClick={() => handleDownload(presentation.videoPath, 'video')}>
                  <Film className="mr-2 h-4 w-4" /> {t('DownloadVideo')}
                </DropdownMenuItem>
              )}
              {presentation.audioPath && (
                <DropdownMenuItem onClick={() => handleDownload(presentation.audioPath, 'audio')}>
                  <Mic className="mr-2 h-4 w-4" /> {t('DownloadAudio')}
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <CardHeader className="pb-2">
        <div className="flex justify-between">
          <div>
            <CardTitle className="line-clamp-1">{presentation.prompt}</CardTitle>
            <CardDescription>
              {t(presentation.type.charAt(0).toUpperCase() + presentation.type.slice(1))} • {formatDate(presentation.createdAt)}
            </CardDescription>
          </div>
          
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Bookmark className="h-4 w-4" />
            <span>{presentation.slidesCount} {t('slides')}</span>
          </div>
        </div>
      </CardHeader>
      
      <CardFooter className="pt-2 flex justify-between">
        {presentation.pptxPath && (
          <Button size="sm" variant="outline" onClick={() => handleDownload(presentation.pptxPath, 'pptx')}>
            <Download className="mr-2 h-4 w-4" /> {t('Download')}
          </Button>
        )}
        
        {presentation.videoPath && (
          <Button size="sm" variant="default">
            <Play className="mr-2 h-4 w-4" /> {t('Play')}
          </Button>
        )}
        
        {!presentation.pptxPath && !presentation.videoPath && (
          <Button size="sm" variant="outline" onClick={() => handleDownload(presentation.thumbnailPath, 'image')}>
            <Image className="mr-2 h-4 w-4" /> {t('ViewMockup')}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

// Основной компонент страницы презентаций
const PresentationsPage: React.FC = () => {
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const { toast } = useToast();
  
  // Состояние формы
  const [presentationType, setPresentationType] = useState<PresentationType>('standard');
  const [prompt, setPrompt] = useState('');
  const [slides, setSlides] = useState(5);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [presentationLanguage, setPresentationLanguage] = useState(language.slice(0, 2));
  const [theme, setTheme] = useState('modern');
  
  // Загружаем список презентаций
  const { data: presentations = [], isLoading } = useQuery<Presentation[]>({
    queryKey: ['/api/presentations'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/presentations');
      return res.json();
    },
  });
  
  // Мутация для создания презентации
  const createPresentationMutation = useMutation({
    mutationFn: async (data: PresentationRequest) => {
      const res = await apiRequest('POST', '/api/presentations', data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: t('Success'),
        description: t('PresentationCreated'),
      });
      
      // Сбрасываем форму
      setPrompt('');
      
      // Обновляем список презентаций
      queryClient.invalidateQueries({ queryKey: ['/api/presentations'] });
    },
    onError: (error: Error) => {
      toast({
        title: t('Error'),
        description: error.message || t('ErrorCreatingPresentation'),
        variant: 'destructive',
      });
    },
  });
  
  // Функция создания презентации
  const handleCreatePresentation = () => {
    if (!prompt) {
      toast({
        title: t('Error'),
        description: t('PromptRequired'),
        variant: 'destructive',
      });
      return;
    }
    
    const request: PresentationRequest = {
      prompt,
      type: presentationType,
      slides,
      audioEnabled,
      language: presentationLanguage,
      theme,
    };
    
    createPresentationMutation.mutate(request);
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col space-y-6">
        {/* Заголовок */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center space-x-4">
            <div className="bg-primary/10 p-3 rounded-lg">
              <Presentation size={24} className="text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{t('Presentations')}</h1>
              <p className="text-muted-foreground">{t('CreatePresentationsDescription')}</p>
            </div>
          </div>
        </div>
        
        {/* Основной контент */}
        <Tabs defaultValue="create" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-2">
            <TabsTrigger value="create">{t('Create')}</TabsTrigger>
            <TabsTrigger value="history">{t('History')}</TabsTrigger>
          </TabsList>
          
          {/* Вкладка создания */}
          <TabsContent value="create" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('CreateNewPresentation')}</CardTitle>
                <CardDescription>{t('CreatePresentationDescription')}</CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Выбор типа презентации */}
                <div className="space-y-2">
                  <Label>{t('PresentationType')}</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                    <Button 
                      variant={presentationType === 'standard' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setPresentationType('standard')}
                    >
                      <Presentation className="mr-2 h-4 w-4" /> {t('Standard')}
                    </Button>
                    <Button 
                      variant={presentationType === 'animated' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setPresentationType('animated')}
                    >
                      <Film className="mr-2 h-4 w-4" /> {t('Animated')}
                    </Button>
                    <Button 
                      variant={presentationType === 'infographic' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setPresentationType('infographic')}
                    >
                      <FileText className="mr-2 h-4 w-4" /> {t('Infographic')}
                    </Button>
                    <Button 
                      variant={presentationType === 'pitch' ? 'default' : 'outline'}
                      className="justify-start"
                      onClick={() => setPresentationType('pitch')}
                    >
                      <Play className="mr-2 h-4 w-4" /> {t('Pitch')}
                    </Button>
                    <Button 
                      variant={presentationType === 'mockup' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setPresentationType('mockup')}
                    >
                      <Image className="mr-2 h-4 w-4" /> {t('Mockup')}
                    </Button>
                  </div>
                </div>
                
                {/* Промпт */}
                <div className="space-y-2">
                  <Label htmlFor="prompt">{t('PromptForPresentation')}</Label>
                  <Textarea 
                    id="prompt"
                    placeholder={t('EnterDescriptionForPresentation')}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Количество слайдов */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="slides">{t('SlideCount')}</Label>
                      <span className="text-sm text-muted-foreground">{slides}</span>
                    </div>
                    <Slider 
                      id="slides"
                      min={3} 
                      max={20} 
                      step={1} 
                      value={[slides]} 
                      onValueChange={(value) => setSlides(value[0])}
                    />
                  </div>
                  
                  {/* Выбор темы */}
                  <div className="space-y-2">
                    <Label htmlFor="theme">{t('Theme')}</Label>
                    <Select value={theme} onValueChange={setTheme}>
                      <SelectTrigger id="theme">
                        <SelectValue placeholder={t('SelectTheme')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="modern">{t('Modern')}</SelectItem>
                        <SelectItem value="minimal">{t('Minimal')}</SelectItem>
                        <SelectItem value="corporate">{t('Corporate')}</SelectItem>
                        <SelectItem value="creative">{t('Creative')}</SelectItem>
                        <SelectItem value="professional">{t('Professional')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Озвучка */}
                  <div className="flex items-center justify-between space-x-2 rounded-md border p-4">
                    <div className="space-y-0.5">
                      <Label htmlFor="audio">{t('EnableAudioNarration')}</Label>
                      <p className="text-muted-foreground text-sm">{t('EnableAudioDescription')}</p>
                    </div>
                    <Switch
                      id="audio"
                      checked={audioEnabled}
                      onCheckedChange={setAudioEnabled}
                    />
                  </div>
                  
                  {/* Язык */}
                  <div className="space-y-2">
                    <Label htmlFor="language">{t('Language')}</Label>
                    <Select 
                      value={presentationLanguage} 
                      onValueChange={setPresentationLanguage}
                      disabled={!audioEnabled}
                    >
                      <SelectTrigger id="language">
                        <SelectValue placeholder={t('SelectLanguage')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="ru">Русский</SelectItem>
                        <SelectItem value="kk">Қазақша</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="tr">Türkçe</SelectItem>
                        <SelectItem value="ar">العربية</SelectItem>
                        <SelectItem value="uz">O'zbek</SelectItem>
                        <SelectItem value="ky">Кыргызча</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setPrompt('')}>
                  {t('Reset')}
                </Button>
                <Button 
                  onClick={handleCreatePresentation}
                  disabled={!prompt || createPresentationMutation.isPending}
                >
                  {createPresentationMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t('Creating')}
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" /> {t('CreatePresentation')}
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Вкладка истории */}
          <TabsContent value="history" className="space-y-6">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : presentations.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {presentations.map((presentation) => (
                  <PresentationCard key={presentation.id} presentation={presentation} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-muted/30 rounded-lg space-y-4">
                <MassaganAILogo size={80} theme="platinum" animated={false} className="mx-auto opacity-40" />
                <h3 className="text-xl font-semibold">{t('NoPresentationsYet')}</h3>
                <p className="text-muted-foreground">{t('CreateYourFirstPresentation')}</p>
                <Button 
                  variant="outline" 
                  className="mt-2" 
                  onClick={() => {
                    const element = document.querySelector('[data-value="create"]') as HTMLElement;
                    if (element) element.click();
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" /> {t('CreateFirst')}
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default PresentationsPage;