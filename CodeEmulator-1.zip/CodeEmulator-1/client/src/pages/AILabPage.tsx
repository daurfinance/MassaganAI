/**
 * MassaganAI: ИИ-лаборатория
 * Страница для управления функциями ИИ-лаборатории, моделирования сценариев
 * и анализа различных типов данных
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React, { useState, useEffect } from 'react';
import { useLanguage } from '@/lib/LanguageContext';
import { useAuth } from '@/hooks/AuthProvider';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Microscope, Sparkles, FileText, Code, Image, PlayCircle, Headphones, BookOpen, Rocket, BrainCircuit, HelpCircle } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from '@/components/ui/tabs';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';

// Типы сценариев моделирования
type ScenarioType = 'business' | 'technical' | 'research' | 'creative' | 'educational';

// Типы анализируемых документов
type DocumentType = 'text' | 'pdf' | 'image' | 'audio' | 'video' | 'code';

const AILabPage: React.FC = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Состояние для вкладок
  const [activeTab, setActiveTab] = useState('scenario');
  
  // Состояние для статуса API
  const [apiStatus, setApiStatus] = useState<'loading'|'operational'|'limited'|'failed'>('loading');
  
  // Состояние для документов
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [documentType, setDocumentType] = useState<DocumentType>('text');
  const [documentAnalysisLoading, setDocumentAnalysisLoading] = useState(false);
  const [documentAnalysisResult, setDocumentAnalysisResult] = useState<any>(null);
  
  // Состояние для сценариев
  const [scenarioPrompt, setScenarioPrompt] = useState('');
  const [scenarioType, setScenarioType] = useState<ScenarioType>('business');
  const [scenarioComplexity, setScenarioComplexity] = useState<'low'|'medium'|'high'>('medium');
  const [scenarioLoading, setScenarioLoading] = useState(false);
  const [scenarioResult, setScenarioResult] = useState<any>(null);
  
  // Состояние для анализа кода
  const [codeText, setCodeText] = useState('');
  const [codeLanguage, setCodeLanguage] = useState('javascript');
  const [codeAnalysisLoading, setCodeAnalysisLoading] = useState(false);
  const [codeAnalysisResult, setCodeAnalysisResult] = useState<any>(null);
  
  // Проверяем статус API при загрузке
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const response = await apiRequest('GET', '/api/ai-lab/status');
        const data = await response.json();
        setApiStatus(data.status === 'operational' ? 'operational' : 'limited');
      } catch (error) {
        console.error("Ошибка при проверке статуса ИИ-лаборатории:", error);
        setApiStatus('failed');
      }
    };
    
    checkStatus();
  }, []);
  
  // Обработчик анализа документа
  const handleDocumentAnalysis = async () => {
    if (!documentFile) {
      toast({
        title: "Ошибка",
        description: "Выберите файл для анализа",
        variant: "destructive"
      });
      return;
    }
    
    setDocumentAnalysisLoading(true);
    
    try {
      const formData = new FormData();
      formData.append('document', documentFile);
      formData.append('type', documentType);
      
      const response = await fetch('/api/ai-lab/analyze-document', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        throw new Error(`Ошибка: ${response.status}`);
      }
      
      const result = await response.json();
      setDocumentAnalysisResult(result);
      
      toast({
        title: "Анализ завершен",
        description: "Документ успешно проанализирован",
      });
    } catch (error) {
      console.error("Ошибка при анализе документа:", error);
      toast({
        title: "Ошибка анализа",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive"
      });
    } finally {
      setDocumentAnalysisLoading(false);
    }
  };
  
  // Обработчик моделирования сценария
  const handleScenarioModeling = async () => {
    if (!scenarioPrompt.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите описание сценария",
        variant: "destructive"
      });
      return;
    }
    
    setScenarioLoading(true);
    
    try {
      const response = await apiRequest('POST', '/api/ai-lab/model-scenario', {
        prompt: scenarioPrompt,
        type: scenarioType,
        complexity: scenarioComplexity
      });
      
      const result = await response.json();
      setScenarioResult(result);
      
      toast({
        title: "Моделирование завершено",
        description: "Сценарий успешно смоделирован",
      });
    } catch (error) {
      console.error("Ошибка при моделировании сценария:", error);
      toast({
        title: "Ошибка моделирования",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive"
      });
    } finally {
      setScenarioLoading(false);
    }
  };
  
  // Обработчик анализа кода
  const handleCodeAnalysis = async () => {
    if (!codeText.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите код для анализа",
        variant: "destructive"
      });
      return;
    }
    
    setCodeAnalysisLoading(true);
    
    try {
      const response = await apiRequest('POST', '/api/ai-lab/analyze-code', {
        code: codeText,
        language: codeLanguage
      });
      
      const result = await response.json();
      setCodeAnalysisResult(result);
      
      toast({
        title: "Анализ завершен",
        description: "Код успешно проанализирован",
      });
    } catch (error) {
      console.error("Ошибка при анализе кода:", error);
      toast({
        title: "Ошибка анализа",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive"
      });
    } finally {
      setCodeAnalysisLoading(false);
    }
  };
  
  return (
    <div className="container mx-auto py-8">
      <header className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
              ИИ-лаборатория
            </h1>
            <p className="text-lg text-gray-500 mt-2">
              Моделирование, анализ и генерация с использованием продвинутых ИИ алгоритмов
            </p>
          </div>
          
          <div className="flex items-center">
            <Microscope className="mr-2 h-6 w-6 text-blue-600" />
            <div className="flex items-center">
              <span className="mr-2">Статус API:</span>
              {apiStatus === 'loading' && (
                <span className="flex items-center">
                  <Loader2 className="mr-1 h-4 w-4 animate-spin text-amber-500" />
                  Проверка...
                </span>
              )}
              {apiStatus === 'operational' && (
                <span className="text-green-600 font-medium">Работает</span>
              )}
              {apiStatus === 'limited' && (
                <span className="text-amber-500 font-medium">Ограниченный режим</span>
              )}
              {apiStatus === 'failed' && (
                <span className="text-red-600 font-medium">Недоступно</span>
              )}
            </div>
          </div>
        </div>
      </header>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-3 mb-8 w-full bg-gray-100 rounded-xl p-1 max-w-3xl mx-auto">
          <TabsTrigger 
            value="scenario" 
            className="flex items-center data-[state=active]:bg-white data-[state=active]:shadow-sm p-3 rounded-lg"
          >
            <Rocket className="mr-2 h-5 w-5" />
            <span>Моделирование сценариев</span>
          </TabsTrigger>
          <TabsTrigger 
            value="document" 
            className="flex items-center data-[state=active]:bg-white data-[state=active]:shadow-sm p-3 rounded-lg"
          >
            <FileText className="mr-2 h-5 w-5" />
            <span>Анализ документов</span>
          </TabsTrigger>
          <TabsTrigger 
            value="code" 
            className="flex items-center data-[state=active]:bg-white data-[state=active]:shadow-sm p-3 rounded-lg"
          >
            <Code className="mr-2 h-5 w-5" />
            <span>Анализ кода</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Моделирование сценариев */}
        <TabsContent value="scenario" className="animate-in fade-in-50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Моделирование сценария</CardTitle>
                <CardDescription>
                  Создайте виртуальный сценарий для моделирования бизнес-процессов, технической реализации или образовательных моделей.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="scenario-type">Тип сценария</Label>
                    <Select 
                      defaultValue={scenarioType}
                      onValueChange={(value) => setScenarioType(value as ScenarioType)}
                    >
                      <SelectTrigger id="scenario-type">
                        <SelectValue placeholder="Выберите тип сценария" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="business">Бизнес</SelectItem>
                        <SelectItem value="technical">Технический</SelectItem>
                        <SelectItem value="research">Исследовательский</SelectItem>
                        <SelectItem value="creative">Творческий</SelectItem>
                        <SelectItem value="educational">Образовательный</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="scenario-complexity">Сложность</Label>
                    <Select 
                      defaultValue={scenarioComplexity}
                      onValueChange={(value) => setScenarioComplexity(value as 'low'|'medium'|'high')}
                    >
                      <SelectTrigger id="scenario-complexity">
                        <SelectValue placeholder="Выберите уровень сложности" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Низкая</SelectItem>
                        <SelectItem value="medium">Средняя</SelectItem>
                        <SelectItem value="high">Высокая</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="scenario-prompt">Описание сценария</Label>
                    <Textarea 
                      id="scenario-prompt"
                      placeholder="Опишите сценарий для моделирования..."
                      value={scenarioPrompt}
                      onChange={(e) => setScenarioPrompt(e.target.value)}
                      rows={6}
                      className="resize-none"
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={handleScenarioModeling}
                  disabled={scenarioLoading || !scenarioPrompt.trim()}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {scenarioLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Моделирование...
                    </>
                  ) : (
                    <>
                      <BrainCircuit className="mr-2 h-4 w-4" />
                      Смоделировать сценарий
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Результат моделирования</CardTitle>
                <CardDescription>
                  Подробный анализ смоделированного сценария
                </CardDescription>
              </CardHeader>
              <CardContent className="min-h-[360px] max-h-[650px] overflow-y-auto">
                {scenarioLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    <span className="ml-2">Моделирование сценария...</span>
                  </div>
                ) : !scenarioResult ? (
                  <div className="flex flex-col items-center justify-center h-64 text-center text-gray-500">
                    <BrainCircuit className="h-12 w-12 mb-4" />
                    <p>Введите описание сценария и нажмите "Смоделировать сценарий" для генерации результата.</p>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-xl font-semibold mb-4">{scenarioResult.summary}</h3>
                    
                    {scenarioResult.visualizationPath && (
                      <div className="mb-4">
                        <img 
                          src={scenarioResult.visualizationPath} 
                          alt="Визуализация сценария" 
                          className="w-full rounded-lg"
                        />
                      </div>
                    )}
                    
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      <div dangerouslySetInnerHTML={{ __html: scenarioResult.details.replace(/\n/g, '<br/>') }} />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Анализ документов */}
        <TabsContent value="document" className="animate-in fade-in-50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Анализ документа</CardTitle>
                <CardDescription>
                  Загрузите документ для анализа и извлечения полезной информации.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="document-type">Тип документа</Label>
                    <Select 
                      defaultValue={documentType}
                      onValueChange={(value) => setDocumentType(value as DocumentType)}
                    >
                      <SelectTrigger id="document-type">
                        <SelectValue placeholder="Выберите тип документа" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="text">Текст</SelectItem>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="image">Изображение</SelectItem>
                        <SelectItem value="audio">Аудио</SelectItem>
                        <SelectItem value="video">Видео</SelectItem>
                        <SelectItem value="code">Код</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="document-file">Файл документа</Label>
                    <div className="grid w-full max-w-full items-center gap-1.5">
                      <Input
                        id="document-file"
                        type="file"
                        onChange={(e) => setDocumentFile(e.target.files?.[0] || null)}
                        className="cursor-pointer"
                      />
                    </div>
                    <p className="text-xs text-gray-500">
                      Поддерживаемые форматы: .txt, .pdf, .jpg, .png, .mp3, .mp4, и другие в зависимости от типа документа
                    </p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={handleDocumentAnalysis}
                  disabled={documentAnalysisLoading || !documentFile}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {documentAnalysisLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Анализ...
                    </>
                  ) : (
                    <>
                      <FileText className="mr-2 h-4 w-4" />
                      Анализировать документ
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Результат анализа</CardTitle>
                <CardDescription>
                  Извлеченная информация и анализ документа
                </CardDescription>
              </CardHeader>
              <CardContent className="min-h-[360px] max-h-[650px] overflow-y-auto">
                {documentAnalysisLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    <span className="ml-2">Анализ документа...</span>
                  </div>
                ) : !documentAnalysisResult ? (
                  <div className="flex flex-col items-center justify-center h-64 text-center text-gray-500">
                    <FileText className="h-12 w-12 mb-4" />
                    <p>Загрузите документ и нажмите "Анализировать документ" для получения результатов.</p>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-xl font-semibold mb-4">Сводка</h3>
                    <p className="text-gray-700 mb-4">{documentAnalysisResult.summary}</p>
                    
                    {documentAnalysisResult.visualPath && (
                      <div className="mb-4">
                        <img 
                          src={documentAnalysisResult.visualPath} 
                          alt="Визуализация документа" 
                          className="w-full rounded-lg"
                        />
                      </div>
                    )}
                    
                    {documentAnalysisResult.extractedText && (
                      <div className="mb-4">
                        <h4 className="text-lg font-medium mb-2">Извлеченный текст</h4>
                        <div className="p-4 bg-gray-100 rounded-lg max-h-80 overflow-y-auto">
                          <pre className="whitespace-pre-wrap text-sm">{documentAnalysisResult.extractedText}</pre>
                        </div>
                      </div>
                    )}
                    
                    {documentAnalysisResult.entities && (
                      <div className="mb-4">
                        <h4 className="text-lg font-medium mb-2">Обнаруженные сущности</h4>
                        <div className="grid grid-cols-2 gap-2">
                          {Object.entries(documentAnalysisResult.entities).map(([key, value]) => (
                            <div key={key} className="p-2 border rounded-md bg-gray-50">
                              <span className="font-medium">{key}:</span> {String(value)}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {documentAnalysisResult.sentiment && (
                      <div>
                        <h4 className="text-lg font-medium mb-2">Тональность</h4>
                        <div className="p-2 border rounded-md inline-block bg-gray-50">
                          {documentAnalysisResult.sentiment}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Анализ кода */}
        <TabsContent value="code" className="animate-in fade-in-50">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Анализ кода</CardTitle>
                <CardDescription>
                  Проанализируйте код с помощью ИИ для выявления проблем, повышения производительности и улучшения безопасности.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="code-language">Язык программирования</Label>
                    <Select 
                      defaultValue={codeLanguage}
                      onValueChange={setCodeLanguage}
                    >
                      <SelectTrigger id="code-language">
                        <SelectValue placeholder="Выберите язык" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="javascript">JavaScript</SelectItem>
                        <SelectItem value="typescript">TypeScript</SelectItem>
                        <SelectItem value="python">Python</SelectItem>
                        <SelectItem value="java">Java</SelectItem>
                        <SelectItem value="csharp">C#</SelectItem>
                        <SelectItem value="php">PHP</SelectItem>
                        <SelectItem value="html">HTML</SelectItem>
                        <SelectItem value="css">CSS</SelectItem>
                        <SelectItem value="sql">SQL</SelectItem>
                        <SelectItem value="go">Go</SelectItem>
                        <SelectItem value="swift">Swift</SelectItem>
                        <SelectItem value="kotlin">Kotlin</SelectItem>
                        <SelectItem value="other">Другой</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="code-text">Код для анализа</Label>
                    <Textarea 
                      id="code-text"
                      placeholder="Вставьте ваш код сюда..."
                      value={codeText}
                      onChange={(e) => setCodeText(e.target.value)}
                      rows={10}
                      className="font-mono"
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  onClick={handleCodeAnalysis}
                  disabled={codeAnalysisLoading || !codeText.trim()}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {codeAnalysisLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Анализ...
                    </>
                  ) : (
                    <>
                      <Code className="mr-2 h-4 w-4" />
                      Анализировать код
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Результат анализа</CardTitle>
                <CardDescription>
                  Рекомендации и улучшения для вашего кода
                </CardDescription>
              </CardHeader>
              <CardContent className="min-h-[360px] max-h-[650px] overflow-y-auto">
                {codeAnalysisLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                    <span className="ml-2">Анализ кода...</span>
                  </div>
                ) : !codeAnalysisResult ? (
                  <div className="flex flex-col items-center justify-center h-64 text-center text-gray-500">
                    <Code className="h-12 w-12 mb-4" />
                    <p>Вставьте код и нажмите "Анализировать код" для получения рекомендаций.</p>
                  </div>
                ) : (
                  <div>
                    <div className="prose prose-sm max-w-none dark:prose-invert">
                      <div dangerouslySetInnerHTML={{ __html: codeAnalysisResult.analysis.replace(/\n/g, '<br/>') }} />
                    </div>
                    
                    {codeAnalysisResult.suggestions && codeAnalysisResult.suggestions.length > 0 && (
                      <div className="mt-4">
                        <h4 className="text-lg font-medium mb-2">Предложения по улучшению</h4>
                        <ul className="space-y-2 list-disc pl-5">
                          {codeAnalysisResult.suggestions.map((suggestion: string, index: number) => (
                            <li key={index}>{suggestion}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      <div className="mt-8 bg-blue-50 rounded-lg p-4 flex items-start">
        <HelpCircle className="text-blue-600 h-5 w-5 mt-0.5 mr-2 flex-shrink-0" />
        <div>
          <h3 className="font-medium text-blue-700">О ИИ-лаборатории</h3>
          <p className="text-sm text-blue-600 mt-1">
            ИИ-лаборатория - это набор инструментов для моделирования сценариев, анализа документов и кода с использованием передовых технологий искусственного интеллекта. Лаборатория интегрирует несколько ИИ-моделей, включая Anthropic Claude и Perplexity API, для предоставления многогранного анализа и высококачественных результатов.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AILabPage;