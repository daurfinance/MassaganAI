/**
 * Страница создания 3D моделей MassaganAI
 * Поддерживает генерацию простых и сложных 3D моделей по текстовому описанию
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/AuthProvider';
import { useLanguage } from '../lib/LanguageContext';
import { useToast } from '../hooks/use-toast';
import { queryClient, apiRequest } from '../lib/queryClient';

// Иконки
import { 
  FileText, 
  Play, 
  Download, 
  Loader2, 
  Plus, 
  Image, 
  Box,
  Package,
  Grid3X3,
  Building,
  Bot,
  Check,
  Eye,
  SlidersHorizontal,
  MoreVertical,
  Crosshair,
  RotateCcw
} from 'lucide-react';

// UI компоненты
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Switch } from '../components/ui/switch';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '../components/ui/dropdown-menu';
import MassaganAILogo from '../components/MassaganAILogo';

// Типы 3D моделей
type ModelType = 'simple' | 'detailed' | 'animation' | 'product' | 'scene';

// Структура для хранения 3D модели
interface Model {
  id: string;
  prompt: string;
  type: ModelType;
  filePath: string;
  thumbnailPath?: string;
  format: string;
  createdAt: string;
}

// Параметры запроса на создание 3D модели
interface ModelRequest {
  prompt: string;
  type: ModelType;
  format?: 'obj' | 'stl' | 'glb' | 'fbx';
  complexity?: 'low' | 'medium' | 'high';
  textures?: boolean;
  animation?: boolean;
}

// Компонент карточки 3D модели
const ModelCard: React.FC<{ model: Model }> = ({ model }) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  
  const handleDownload = (path: string | undefined, type: string) => {
    if (!path) {
      toast({
        title: t('Error'),
        description: t('FileNotAvailable'),
        variant: 'destructive',
      });
      return;
    }
    
    // Создаем ссылку для скачивания файла
    const link = document.createElement('a');
    link.href = path;
    link.download = `MassaganAI_${model.type}_${type}_${new Date().toISOString().slice(0, 10)}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: t('DownloadStarted'),
      description: t('FileDownloading'),
    });
  };
  
  // Форматирование даты
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };
  
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all">
      <div className="relative aspect-video bg-muted">
        {model.thumbnailPath ? (
          <img 
            src={model.thumbnailPath} 
            alt={model.prompt}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/10">
            <Box size={48} className="text-primary/50" />
          </div>
        )}
        
        <div className="absolute top-2 right-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="bg-background/80 hover:bg-background rounded-full h-8 w-8">
                <MoreVertical size={16} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t('Options')}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {model.filePath && (
                <DropdownMenuItem onClick={() => handleDownload(model.filePath, model.format)}>
                  <Download className="mr-2 h-4 w-4" /> {t('Download3DModel')}
                </DropdownMenuItem>
              )}
              {model.thumbnailPath && (
                <DropdownMenuItem onClick={() => handleDownload(model.thumbnailPath, 'png')}>
                  <Image className="mr-2 h-4 w-4" /> {t('DownloadPreview')}
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <CardHeader className="pb-2">
        <div className="flex justify-between">
          <div>
            <CardTitle className="line-clamp-1">{model.prompt}</CardTitle>
            <CardDescription>
              {t(model.type.charAt(0).toUpperCase() + model.type.slice(1))} • {model.format.toUpperCase()} • {formatDate(model.createdAt)}
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      
      <CardFooter className="pt-2 flex justify-between">
        <Button size="sm" variant="outline" onClick={() => handleDownload(model.filePath, model.format)}>
          <Download className="mr-2 h-4 w-4" /> {t('Download')}
        </Button>
        
        <Button size="sm" variant="default">
          <Eye className="mr-2 h-4 w-4" /> {t('View3DPreview')}
        </Button>
      </CardFooter>
    </Card>
  );
};

// Основной компонент страницы 3D моделей
const ModelsPage: React.FC = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();
  
  // Состояние формы
  const [modelType, setModelType] = useState<ModelType>('simple');
  const [prompt, setPrompt] = useState('');
  const [format, setFormat] = useState<'obj' | 'stl' | 'glb' | 'fbx'>('obj');
  const [complexity, setComplexity] = useState<'low' | 'medium' | 'high'>('medium');
  const [textures, setTextures] = useState(true);
  const [animation, setAnimation] = useState(false);
  
  // Загружаем список 3D моделей
  const { data: models = [], isLoading } = useQuery<Model[]>({
    queryKey: ['/api/models'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/models');
      return res.json();
    },
  });
  
  // Мутация для создания 3D модели
  const createModelMutation = useMutation({
    mutationFn: async (data: ModelRequest) => {
      const res = await apiRequest('POST', '/api/models', data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: t('Success'),
        description: t('ModelCreated'),
      });
      
      // Сбрасываем форму
      setPrompt('');
      
      // Обновляем список моделей
      queryClient.invalidateQueries({ queryKey: ['/api/models'] });
    },
    onError: (error: Error) => {
      toast({
        title: t('Error'),
        description: error.message || t('ErrorCreatingModel'),
        variant: 'destructive',
      });
    },
  });
  
  // Функция создания 3D модели
  const handleCreateModel = () => {
    if (!prompt) {
      toast({
        title: t('Error'),
        description: t('PromptRequired'),
        variant: 'destructive',
      });
      return;
    }
    
    const request: ModelRequest = {
      prompt,
      type: modelType,
      format,
      complexity,
      textures,
      animation,
    };
    
    createModelMutation.mutate(request);
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col space-y-6">
        {/* Заголовок */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center space-x-4">
            <div className="bg-primary/10 p-3 rounded-lg">
              <Box size={24} className="text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{t('3DModels')}</h1>
              <p className="text-muted-foreground">{t('Create3DModelsDescription')}</p>
            </div>
          </div>
        </div>
        
        {/* Основной контент */}
        <Tabs defaultValue="create" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-2">
            <TabsTrigger value="create">{t('Create')}</TabsTrigger>
            <TabsTrigger value="history">{t('History')}</TabsTrigger>
          </TabsList>
          
          {/* Вкладка создания */}
          <TabsContent value="create" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('CreateNew3DModel')}</CardTitle>
                <CardDescription>{t('Create3DModelDescription')}</CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Выбор типа модели */}
                <div className="space-y-2">
                  <Label>{t('ModelType')}</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                    <Button 
                      variant={modelType === 'simple' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setModelType('simple')}
                    >
                      <Box className="mr-2 h-4 w-4" /> {t('Simple')}
                    </Button>
                    <Button 
                      variant={modelType === 'detailed' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setModelType('detailed')}
                    >
                      <Package className="mr-2 h-4 w-4" /> {t('Detailed')}
                    </Button>
                    <Button 
                      variant={modelType === 'animation' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setModelType('animation')}
                    >
                      <RotateCcw className="mr-2 h-4 w-4" /> {t('Animation')}
                    </Button>
                    <Button 
                      variant={modelType === 'product' ? 'default' : 'outline'}
                      className="justify-start"
                      onClick={() => setModelType('product')}
                    >
                      <Package className="mr-2 h-4 w-4" /> {t('Product')}
                    </Button>
                    <Button 
                      variant={modelType === 'scene' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setModelType('scene')}
                    >
                      <Grid3X3 className="mr-2 h-4 w-4" /> {t('Scene')}
                    </Button>
                  </div>
                </div>
                
                {/* Промпт */}
                <div className="space-y-2">
                  <Label htmlFor="prompt">{t('PromptFor3DModel')}</Label>
                  <Textarea 
                    id="prompt"
                    placeholder={t('EnterDescriptionFor3DModel')}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Формат файла */}
                  <div className="space-y-2">
                    <Label htmlFor="format">{t('FileFormat')}</Label>
                    <Select value={format} onValueChange={(value: 'obj' | 'stl' | 'glb' | 'fbx') => setFormat(value)}>
                      <SelectTrigger id="format">
                        <SelectValue placeholder={t('SelectFormat')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="obj">OBJ</SelectItem>
                        <SelectItem value="stl">STL</SelectItem>
                        <SelectItem value="glb">GLB</SelectItem>
                        <SelectItem value="fbx">FBX</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      {format === 'obj' && t('OBJFormatDescription')}
                      {format === 'stl' && t('STLFormatDescription')}
                      {format === 'glb' && t('GLBFormatDescription')}
                      {format === 'fbx' && t('FBXFormatDescription')}
                    </p>
                  </div>
                  
                  {/* Сложность */}
                  <div className="space-y-2">
                    <Label htmlFor="complexity">{t('Complexity')}</Label>
                    <Select 
                      value={complexity} 
                      onValueChange={(value: 'low' | 'medium' | 'high') => setComplexity(value)}
                    >
                      <SelectTrigger id="complexity">
                        <SelectValue placeholder={t('SelectComplexity')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">{t('Low')}</SelectItem>
                        <SelectItem value="medium">{t('Medium')}</SelectItem>
                        <SelectItem value="high">{t('High')}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Текстуры */}
                  <div className="flex items-center justify-between space-x-2 rounded-md border p-4">
                    <div className="space-y-0.5">
                      <Label htmlFor="textures">{t('IncludeTextures')}</Label>
                      <p className="text-muted-foreground text-sm">{t('TexturesDescription')}</p>
                    </div>
                    <Switch
                      id="textures"
                      checked={textures}
                      onCheckedChange={setTextures}
                    />
                  </div>
                  
                  {/* Анимация */}
                  <div className="flex items-center justify-between space-x-2 rounded-md border p-4">
                    <div className="space-y-0.5">
                      <Label htmlFor="animation">{t('IncludeAnimation')}</Label>
                      <p className="text-muted-foreground text-sm">{t('AnimationDescription')}</p>
                    </div>
                    <Switch
                      id="animation"
                      checked={animation}
                      onCheckedChange={setAnimation}
                      disabled={modelType !== 'animation'}
                    />
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => setPrompt('')}>
                  {t('Reset')}
                </Button>
                <Button 
                  onClick={handleCreateModel}
                  disabled={!prompt || createModelMutation.isPending}
                >
                  {createModelMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t('Creating')}
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" /> {t('Create3DModel')}
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Вкладка истории */}
          <TabsContent value="history" className="space-y-6">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : models.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {models.map((model) => (
                  <ModelCard key={model.id} model={model} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-muted/30 rounded-lg space-y-4">
                <MassaganAILogo size={80} theme="platinum" animated={false} className="mx-auto opacity-40" />
                <h3 className="text-xl font-semibold">{t('NoModelsYet')}</h3>
                <p className="text-muted-foreground">{t('CreateYourFirst3DModel')}</p>
                <Button 
                  variant="outline" 
                  className="mt-2" 
                  onClick={() => {
                    const element = document.querySelector('[data-value="create"]') as HTMLElement;
                    if (element) element.click();
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" /> {t('CreateFirst')}
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ModelsPage;