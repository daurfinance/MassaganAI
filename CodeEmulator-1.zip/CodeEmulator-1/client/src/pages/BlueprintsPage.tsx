/**
 * Страница создания чертежей MassaganAI
 * Поддерживает генерацию архитектурных, инженерных и других типов чертежей по промпту
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/AuthProvider';
import { useLanguage } from '../lib/LanguageContext';
import { useToast } from '../hooks/use-toast';
import { queryClient, apiRequest } from '../lib/queryClient';

// Иконки
import { 
  PenTool, 
  FileText, 
  Download, 
  Loader2, 
  Plus, 
  Image,
  Home,
  Cpu,
  Zap,
  Ruler,
  Layers,
  Copy,
  CheckCircle,
  MoreVertical,
  Search,
  ArrowUpRight
} from 'lucide-react';

// UI компоненты
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '../components/ui/dropdown-menu';
import MassaganAILogo from '../components/MassaganAILogo';

// Типы чертежей
type BlueprintType = 'architecture' | 'engineering' | 'electrical' | 'mechanical' | 'interior';

// Структура для хранения чертежа
interface Blueprint {
  id: string;
  prompt: string;
  type: BlueprintType;
  filePath: string;
  thumbnailPath?: string;
  dimensions?: string;
  createdAt: string;
}

// Параметры запроса на создание чертежа
interface BlueprintRequest {
  prompt: string;
  type: BlueprintType;
  dimensions?: string;
  details?: string;
  format?: 'svg' | 'pdf' | 'png';
  scale?: string;
}

// Компонент карточки чертежа
const BlueprintCard: React.FC<{ blueprint: Blueprint }> = ({ blueprint }) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  
  const handleDownload = (path: string | undefined, type: string) => {
    if (!path) {
      toast({
        title: t('Error'),
        description: t('FileNotAvailable'),
        variant: 'destructive',
      });
      return;
    }
    
    // Создаем ссылку для скачивания файла
    const link = document.createElement('a');
    link.href = path;
    link.download = `MassaganAI_${blueprint.type}_${type}_${new Date().toISOString().slice(0, 10)}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: t('DownloadStarted'),
      description: t('FileDownloading'),
    });
  };
  
  // Форматирование даты
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };
  
  // Получение типа файла
  const getFileType = (path: string) => {
    const extension = path.split('.').pop()?.toLowerCase();
    return extension || 'file';
  };
  
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all">
      <div className="relative aspect-video bg-muted">
        {blueprint.thumbnailPath ? (
          <img 
            src={blueprint.thumbnailPath} 
            alt={blueprint.prompt}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary/10">
            <PenTool size={48} className="text-primary/50" />
          </div>
        )}
        
        <div className="absolute top-2 right-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="bg-background/80 hover:bg-background rounded-full h-8 w-8">
                <MoreVertical size={16} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{t('Options')}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {blueprint.filePath && (
                <DropdownMenuItem onClick={() => handleDownload(blueprint.filePath, getFileType(blueprint.filePath))}>
                  <FileText className="mr-2 h-4 w-4" /> {t('DownloadBlueprint')}
                </DropdownMenuItem>
              )}
              {blueprint.thumbnailPath && (
                <DropdownMenuItem onClick={() => handleDownload(blueprint.thumbnailPath, 'png')}>
                  <Image className="mr-2 h-4 w-4" /> {t('DownloadThumbnail')}
                </DropdownMenuItem>
              )}
              <DropdownMenuItem>
                <Copy className="mr-2 h-4 w-4" /> {t('CopyPrompt')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <CardHeader className="pb-2">
        <div className="flex justify-between">
          <div>
            <CardTitle className="line-clamp-1">{blueprint.prompt}</CardTitle>
            <CardDescription>
              {t(blueprint.type.charAt(0).toUpperCase() + blueprint.type.slice(1))} • {formatDate(blueprint.createdAt)}
            </CardDescription>
          </div>
          
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            {blueprint.dimensions && (
              <>
                <Ruler className="h-4 w-4" />
                <span>{blueprint.dimensions}</span>
              </>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardFooter className="pt-2 flex justify-between">
        <Button size="sm" variant="outline" onClick={() => handleDownload(blueprint.filePath, getFileType(blueprint.filePath))}>
          <Download className="mr-2 h-4 w-4" /> {t('Download')}
        </Button>
        
        <Button size="sm" variant="default" asChild>
          <a href={blueprint.filePath} target="_blank" rel="noopener noreferrer">
            <Search className="mr-2 h-4 w-4" /> {t('View')}
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
};

// Основной компонент страницы чертежей
const BlueprintsPage: React.FC = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const { toast } = useToast();
  
  // Состояние формы
  const [blueprintType, setBlueprintType] = useState<BlueprintType>('architecture');
  const [prompt, setPrompt] = useState('');
  const [dimensions, setDimensions] = useState('10m x 8m');
  const [details, setDetails] = useState('');
  const [format, setFormat] = useState<'svg' | 'pdf' | 'png'>('svg');
  
  // Загружаем список чертежей
  const { data: blueprints = [], isLoading } = useQuery<Blueprint[]>({
    queryKey: ['/api/blueprints'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/blueprints');
      return res.json();
    },
  });
  
  // Мутация для создания чертежа
  const createBlueprintMutation = useMutation({
    mutationFn: async (data: BlueprintRequest) => {
      const res = await apiRequest('POST', '/api/blueprints', data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: t('Success'),
        description: t('BlueprintCreated'),
      });
      
      // Сбрасываем форму
      setPrompt('');
      setDetails('');
      
      // Обновляем список чертежей
      queryClient.invalidateQueries({ queryKey: ['/api/blueprints'] });
    },
    onError: (error: Error) => {
      toast({
        title: t('Error'),
        description: error.message || t('ErrorCreatingBlueprint'),
        variant: 'destructive',
      });
    },
  });
  
  // Функция создания чертежа
  const handleCreateBlueprint = () => {
    if (!prompt) {
      toast({
        title: t('Error'),
        description: t('PromptRequired'),
        variant: 'destructive',
      });
      return;
    }
    
    const request: BlueprintRequest = {
      prompt,
      type: blueprintType,
      dimensions,
      details,
      format,
    };
    
    createBlueprintMutation.mutate(request);
  };

  // Иконка для типа чертежа
  const getTypeIcon = (type: BlueprintType) => {
    switch (type) {
      case 'architecture':
        return <Home className="mr-2 h-4 w-4" />;
      case 'engineering':
        return <Cpu className="mr-2 h-4 w-4" />;
      case 'electrical':
        return <Zap className="mr-2 h-4 w-4" />;
      case 'mechanical':
        return <Ruler className="mr-2 h-4 w-4" />;
      case 'interior':
        return <Layers className="mr-2 h-4 w-4" />;
      default:
        return <PenTool className="mr-2 h-4 w-4" />;
    }
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col space-y-6">
        {/* Заголовок */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center space-x-4">
            <div className="bg-primary/10 p-3 rounded-lg">
              <PenTool size={24} className="text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">{t('Blueprints')}</h1>
              <p className="text-muted-foreground">{t('CreateBlueprintsDescription')}</p>
            </div>
          </div>
        </div>
        
        {/* Основной контент */}
        <Tabs defaultValue="create" className="w-full">
          <TabsList className="grid w-full md:w-auto grid-cols-2">
            <TabsTrigger value="create">{t('Create')}</TabsTrigger>
            <TabsTrigger value="history">{t('History')}</TabsTrigger>
          </TabsList>
          
          {/* Вкладка создания */}
          <TabsContent value="create" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t('CreateNewBlueprint')}</CardTitle>
                <CardDescription>{t('CreateBlueprintDescription')}</CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Выбор типа чертежа */}
                <div className="space-y-2">
                  <Label>{t('BlueprintType')}</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                    <Button 
                      variant={blueprintType === 'architecture' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setBlueprintType('architecture')}
                    >
                      <Home className="mr-2 h-4 w-4" /> {t('Architecture')}
                    </Button>
                    <Button 
                      variant={blueprintType === 'engineering' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setBlueprintType('engineering')}
                    >
                      <Cpu className="mr-2 h-4 w-4" /> {t('Engineering')}
                    </Button>
                    <Button 
                      variant={blueprintType === 'electrical' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setBlueprintType('electrical')}
                    >
                      <Zap className="mr-2 h-4 w-4" /> {t('Electrical')}
                    </Button>
                    <Button 
                      variant={blueprintType === 'mechanical' ? 'default' : 'outline'}
                      className="justify-start"
                      onClick={() => setBlueprintType('mechanical')}
                    >
                      <Ruler className="mr-2 h-4 w-4" /> {t('Mechanical')}
                    </Button>
                    <Button 
                      variant={blueprintType === 'interior' ? 'default' : 'outline'} 
                      className="justify-start"
                      onClick={() => setBlueprintType('interior')}
                    >
                      <Layers className="mr-2 h-4 w-4" /> {t('Interior')}
                    </Button>
                  </div>
                </div>
                
                {/* Промпт */}
                <div className="space-y-2">
                  <Label htmlFor="prompt">{t('PromptForBlueprint')}</Label>
                  <Textarea 
                    id="prompt"
                    placeholder={blueprintType === 'architecture' 
                      ? t('EnterDescriptionForArchitecturalBlueprint')
                      : t('EnterDescriptionForBlueprint')}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Размеры */}
                  <div className="space-y-2">
                    <Label htmlFor="dimensions">{t('Dimensions')}</Label>
                    <Input 
                      id="dimensions"
                      placeholder={t('EnterDimensions')}
                      value={dimensions}
                      onChange={(e) => setDimensions(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">{t('DimensionsDescription')}</p>
                  </div>
                  
                  {/* Формат файла */}
                  <div className="space-y-2">
                    <Label htmlFor="format">{t('FileFormat')}</Label>
                    <Select value={format} onValueChange={(value: 'svg' | 'pdf' | 'png') => setFormat(value)}>
                      <SelectTrigger id="format">
                        <SelectValue placeholder={t('SelectFormat')} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="svg">SVG</SelectItem>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="png">PNG</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                {/* Дополнительные детали */}
                <div className="space-y-2">
                  <Label htmlFor="details">{t('AdditionalDetails')}</Label>
                  <Textarea 
                    id="details"
                    placeholder={t('EnterAdditionalDetails')}
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">{t('AdditionalDetailsDescription')}</p>
                </div>
              </CardContent>
              
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={() => {
                  setPrompt('');
                  setDetails('');
                }}>
                  {t('Reset')}
                </Button>
                <Button 
                  onClick={handleCreateBlueprint}
                  disabled={!prompt || createBlueprintMutation.isPending}
                >
                  {createBlueprintMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> {t('Creating')}
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" /> {t('CreateBlueprint')}
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Вкладка истории */}
          <TabsContent value="history" className="space-y-6">
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : blueprints.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {blueprints.map((blueprint) => (
                  <BlueprintCard key={blueprint.id} blueprint={blueprint} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-muted/30 rounded-lg space-y-4">
                <MassaganAILogo size={80} theme="platinum" animated={false} className="mx-auto opacity-40" />
                <h3 className="text-xl font-semibold">{t('NoBlueprintsYet')}</h3>
                <p className="text-muted-foreground">{t('CreateYourFirstBlueprint')}</p>
                <Button 
                  variant="outline" 
                  className="mt-2" 
                  onClick={() => {
                    const element = document.querySelector('[data-value="create"]') as HTMLElement;
                    if (element) element.click();
                  }}
                >
                  <Plus className="mr-2 h-4 w-4" /> {t('CreateFirst')}
                </Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default BlueprintsPage;