/**
 * MassaganAI: Страница подписки с интеграцией Stripe
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import { useEffect, useState } from 'react';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Link, useLocation } from 'wouter';
import { ArrowRight, CheckCircle, BadgeCheck, PlusCircle, Clock, Star } from 'lucide-react';

// Загрузка Stripe публичного ключа
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

// Форма оплаты с использованием Stripe Elements
function CheckoutForm({ clientSecret, planType }: { clientSecret: string, planType: string }) {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!stripe || !elements) {
      return;
    }
    
    setIsLoading(true);
    
    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin + '/subscription-success',
        },
      });
      
      if (error) {
        toast({
          title: 'Ошибка оплаты',
          description: error.message || 'Произошла ошибка при обработке платежа',
          variant: 'destructive',
        });
      }
    } catch (err) {
      toast({
        title: 'Ошибка оплаты',
        description: 'Произошла ошибка при обработке платежа',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-6">
        <h2 className="text-xl font-semibold text-center">
          Подписка {planType === 'premium' ? 'Premium' : 'Business'}
        </h2>
        
        <div className="my-8">
          <PaymentElement />
        </div>
        
        <Button
          type="submit"
          className="w-full bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700"
          disabled={!stripe || isLoading}
        >
          {isLoading ? 'Обработка...' : 'Оформить подписку'}
        </Button>
        
        <p className="text-center text-sm text-muted-foreground mt-4">
          Подписываясь, вы соглашаетесь с нашими условиями использования и политикой конфиденциальности.
        </p>
      </div>
    </form>
  );
}

// Компонент плана подписки
function PlanCard({ 
  title, 
  price, 
  description, 
  features,
  isPopular,
  onSelect
}: { 
  title: string;
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
  onSelect: () => void;
}) {
  return (
    <Card className={`w-full max-w-sm border ${isPopular ? 'border-violet-400 shadow-lg' : ''}`}>
      <CardHeader>
        {isPopular && (
          <div className="py-1 px-3 bg-gradient-to-r from-indigo-500 to-violet-600 text-white rounded-full text-xs font-medium mb-2 w-fit">
            Популярный выбор
          </div>
        )}
        <CardTitle className="text-2xl">{title}</CardTitle>
        <div className="flex items-baseline mt-2">
          <span className="text-4xl font-bold">{price}</span>
          <span className="ml-1 text-sm text-muted-foreground">/месяц</span>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {features.map((feature, i) => (
            <li key={i} className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button
          onClick={onSelect}
          className={`w-full ${isPopular 
            ? 'bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700' 
            : ''}`}
          variant={isPopular ? 'default' : 'outline'}
        >
          Выбрать план
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}

export default function SubscribePage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  
  // Функция для создания подписки
  const createSubscription = async (plan: string) => {
    setIsLoading(true);
    
    try {
      const response = await apiRequest('POST', '/api/create-subscription', { plan });
      const data = await response.json();
      
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
      } else {
        throw new Error('Не удалось получить ключ для оплаты');
      }
    } catch (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось создать подписку. Пожалуйста, попробуйте позже.',
        variant: 'destructive',
      });
      console.error('Ошибка при создании подписки:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Выбор плана подписки
  const handleSelectPlan = (plan: string) => {
    setSelectedPlan(plan);
    createSubscription(plan);
  };
  
  // Планы подписки
  const plans = [
    {
      id: 'premium',
      title: 'Premium',
      price: '₸14,990',
      description: 'Идеальный план для индивидуальных разработчиков и небольших проектов',
      features: [
        'Доступ ко всем функциям ИИ-эмулятора',
        'Генерация до 100 проектов в месяц',
        'Приоритетная поддержка по email',
        'Доступ к Telegram боту',
        'Импорт из GitHub и ZIP файлов'
      ],
      isPopular: true
    },
    {
      id: 'business',
      title: 'Business',
      price: '₸24,990',
      description: 'Расширенный план для команд и крупных проектов',
      features: [
        'Все функции Premium плана',
        'Неограниченная генерация проектов',
        'Приоритетная поддержка 24/7',
        'Работа с видео и озвучивание',
        'Расширенные функции интеграции',
        'Доступ к API для интеграции с вашими проектами'
      ],
      isPopular: false
    }
  ];
  
  // Если загружается секретный ключ для оплаты
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-100px)]">
        <div className="text-center">
          <div className="inline-block animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
          <p className="text-xl">Подготовка к оплате...</p>
        </div>
      </div>
    );
  }
  
  // Если есть ключ для оплаты, показываем форму оплаты
  if (clientSecret && selectedPlan) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-12">
        <Link to="/" className="inline-flex items-center text-sm mb-8 hover:underline">
          ← Вернуться на главную
        </Link>
        
        <div className="max-w-md mx-auto">
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <Card className="w-full">
              <CardContent className="pt-6">
                <CheckoutForm clientSecret={clientSecret} planType={selectedPlan} />
              </CardContent>
            </Card>
          </Elements>
        </div>
      </div>
    );
  }
  
  // По умолчанию показываем выбор планов
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-4">Выберите подходящий план</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          MassaganAI предлагает гибкие планы подписки для любых потребностей - от индивидуальных разработчиков до крупных команд
        </p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {plans.map((plan) => (
          <PlanCard
            key={plan.id}
            title={plan.title}
            price={plan.price}
            description={plan.description}
            features={plan.features}
            isPopular={plan.isPopular}
            onSelect={() => handleSelectPlan(plan.id)}
          />
        ))}
      </div>
      
      <div className="mt-20 max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-8 text-center">Часто задаваемые вопросы</h2>
        
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium mb-2">Как работает подписка?</h3>
            <p className="text-muted-foreground">
              После оформления подписки вы получаете мгновенный доступ ко всем функциям выбранного плана. Подписка автоматически продлевается каждый месяц, но вы можете отменить её в любое время.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">Могу ли я изменить или отменить план?</h3>
            <p className="text-muted-foreground">
              Да, вы можете изменить или отменить ваш план в любое время в настройках вашего аккаунта. При отмене вы сохраняете доступ до конца оплаченного периода.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">Какие методы оплаты вы принимаете?</h3>
            <p className="text-muted-foreground">
              Мы принимаем все основные кредитные и дебетовые карты Visa, Mastercard, American Express, а также Apple Pay и Google Pay.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}