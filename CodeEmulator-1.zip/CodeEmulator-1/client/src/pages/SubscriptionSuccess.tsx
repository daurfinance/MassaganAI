/**
 * MassaganAI: Страница успешной подписки
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, ArrowRight } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

// Интерфейс для информации о подписке
interface SubscriptionInfo {
  hasSubscription: boolean;
  subscription?: {
    id: number;
    status: string;
    planType: string;
    currentPeriodEnd: string;
  };
}

export default function SubscriptionSuccessPage() {
  const [subscriptionInfo, setSubscriptionInfo] = useState<SubscriptionInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // Получение информации о подписке
  useEffect(() => {
    const fetchSubscriptionInfo = async () => {
      try {
        const response = await apiRequest('GET', '/api/subscription');
        
        if (response.ok) {
          const data = await response.json();
          setSubscriptionInfo(data);
        } else {
          throw new Error('Не удалось получить информацию о подписке');
        }
      } catch (err) {
        console.error('Ошибка при получении информации о подписке:', err);
        setError('Не удалось загрузить данные о подписке');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchSubscriptionInfo();
  }, []);
  
  // Преобразование даты окончания периода подписки в локальный формат
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Если данные загружаются
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-100px)]">
        <div className="text-center">
          <div className="inline-block animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
          <p className="text-xl">Загрузка информации о подписке...</p>
        </div>
      </div>
    );
  }
  
  // Если произошла ошибка
  if (error) {
    return (
      <div className="container max-w-md mx-auto px-4 py-12">
        <Card className="text-center">
          <CardHeader>
            <CardTitle className="text-2xl">Что-то пошло не так</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardFooter className="flex justify-center">
            <Button asChild>
              <Link to="/">Вернуться на главную</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  // Если у пользователя нет подписки
  if (!subscriptionInfo || !subscriptionInfo.hasSubscription) {
    return (
      <div className="container max-w-md mx-auto px-4 py-12">
        <Card className="text-center">
          <CardHeader>
            <CardTitle className="text-2xl">Подписка не найдена</CardTitle>
            <CardDescription>Информация о вашей подписке не найдена. Возможно, платеж ещё обрабатывается.</CardDescription>
          </CardHeader>
          <CardFooter className="flex justify-center space-x-4">
            <Button variant="outline" asChild>
              <Link to="/">Вернуться на главную</Link>
            </Button>
            <Button asChild>
              <Link to="/subscribe">Оформить подписку</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  // Определение типа подписки
  const planType = subscriptionInfo.subscription?.planType === 'premium' ? 'Premium' : 'Business';
  const isActive = subscriptionInfo.subscription?.status === 'active' || 
                  subscriptionInfo.subscription?.status === 'trialing';
  
  // Успешная страница подписки
  return (
    <div className="container max-w-4xl mx-auto px-4 py-16">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
          <CheckCircle className="h-12 w-12 text-green-600" />
        </div>
        <h1 className="text-4xl font-bold mb-4">Подписка успешно оформлена!</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Спасибо за подписку на MassaganAI. Теперь у вас есть доступ ко всем функциям плана {planType}.
        </p>
      </div>
      
      <Card className="max-w-lg mx-auto mb-10">
        <CardHeader>
          <CardTitle>Информация о подписке</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between">
            <span className="text-muted-foreground">План:</span>
            <span className="font-medium">{planType}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Статус:</span>
            <span className={`font-medium ${isActive ? 'text-green-600' : 'text-amber-600'}`}>
              {isActive ? 'Активна' : 'Ожидает подтверждения'}
            </span>
          </div>
          {subscriptionInfo.subscription?.currentPeriodEnd && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Следующее списание:</span>
              <span className="font-medium">{formatDate(subscriptionInfo.subscription.currentPeriodEnd)}</span>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="text-center space-y-6">
        <p>
          Доступ ко всем функциям плана {planType} теперь активен.
          Вы можете начать пользоваться всеми преимуществами прямо сейчас.
        </p>
        
        <div className="flex justify-center space-x-4">
          <Button variant="outline" asChild>
            <Link to="/">Вернуться на главную</Link>
          </Button>
          <Button asChild>
            <Link to="/projects">
              Мои проекты
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}