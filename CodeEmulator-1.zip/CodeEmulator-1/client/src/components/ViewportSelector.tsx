import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Smartphone, Tablet, Monitor, Laptop } from "lucide-react";

// Расширенные типы устройств
export type DeviceType = 
  "responsive" | 
  "mobile-android" | 
  "mobile-iphone" | 
  "tablet" | 
  "desktop-windows" | 
  "desktop-macos";

interface ViewportSelectorProps {
  size: string;
  onChange: (size: DeviceType) => void;
}

export default function ViewportSelector({ size, onChange }: ViewportSelectorProps) {
  return (
    <div className="flex items-center">
      <span className="text-xs text-gray-500 mr-2">Режим просмотра:</span>
      <Select
        value={size}
        onValueChange={(value) => 
          onChange(value as DeviceType)
        }
      >
        <SelectTrigger className="h-8 text-xs bg-white border border-gray-300 min-w-[150px]">
          <SelectValue placeholder="Адаптивный" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="responsive" className="flex items-center">
            <span className="flex items-center">
              <Monitor className="h-3.5 w-3.5 mr-2" /> Адаптивный
            </span>
          </SelectItem>
          
          {/* Мобильные устройства */}
          <SelectItem value="mobile-android" className="flex items-center">
            <span className="flex items-center">
              <Smartphone className="h-3.5 w-3.5 mr-2" /> Android
            </span>
          </SelectItem>
          <SelectItem value="mobile-iphone" className="flex items-center">
            <span className="flex items-center">
              <Smartphone className="h-3.5 w-3.5 mr-2" /> iPhone
            </span>
          </SelectItem>
          
          {/* Планшеты */}
          <SelectItem value="tablet" className="flex items-center">
            <span className="flex items-center">
              <Tablet className="h-3.5 w-3.5 mr-2" /> Планшет
            </span>
          </SelectItem>
          
          {/* Настольные компьютеры */}
          <SelectItem value="desktop-windows" className="flex items-center">
            <span className="flex items-center">
              <Monitor className="h-3.5 w-3.5 mr-2" /> Windows
            </span>
          </SelectItem>
          <SelectItem value="desktop-macos" className="flex items-center">
            <span className="flex items-center">
              <Laptop className="h-3.5 w-3.5 mr-2" /> macOS
            </span>
          </SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}
