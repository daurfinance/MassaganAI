import React, { useState, useEffect } from "react";

/**
 * MassaganAI: Анимированный логотип снежного барса в казахской национальной одежде на ракете
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */
const MassaganLogo: React.FC<{ size?: number }> = ({ size = 50 }) => {
  const [rotation, setRotation] = useState(0);
  const [scale, setScale] = useState(1);
  const [flame, setFlame] = useState(1);
  
  // Анимация ракеты
  useEffect(() => {
    const interval = setInterval(() => {
      setRotation(prev => (prev + 1) % 10 - 5);  // колебание от -5 до 5 градусов
      setScale(prev => 1 + Math.sin(Date.now() / 500) * 0.03);  // пульсация размера
      setFlame(prev => 0.8 + Math.random() * 0.4); // случайное колебание пламени
    }, 50);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="rocket-container" style={{ width: size, height: size }}>
      <svg 
        viewBox="0 0 100 100" 
        width={size} 
        height={size}
        style={{ 
          transform: `rotate(${rotation}deg) scale(${scale})`,
          transition: 'transform 0.2s ease',
        }}
      >
        {/* Пламя ракеты */}
        <g className="rocket-flame" style={{ transform: `scaleY(${flame})`, transformOrigin: '50% 100%' }}>
          <path 
            d="M48 80 L42 95 L50 90 L58 95 L52 80" 
            fill="url(#flameGradient)" 
            className="animate-pulse-fast"
          />
          <ellipse 
            cx="50" cy="95" rx="5" ry="4" 
            fill="#FFA500" 
            className="animate-pulse" 
          />
        </g>
        
        {/* Ракета */}
        <g className="rocket-body">
          <path 
            d="M40 40 L35 80 L50 85 L65 80 L60 40" 
            fill="#0e766e" 
            stroke="#FFD700" 
            strokeWidth="1" 
          />
          <ellipse 
            cx="50" cy="40" rx="15" ry="10" 
            fill="#0e766e" 
            stroke="#FFD700" 
            strokeWidth="1" 
          />
          <circle 
            cx="50" cy="65" r="5" 
            fill="#0099cc" 
            stroke="#FFD700" 
            strokeWidth="0.5" 
            className="animate-pulse-slow" 
          />
        </g>
        
        {/* Снежный барс */}
        <g className="snow-leopard">
          <ellipse cx="50" cy="30" rx="12" ry="10" fill="#f5e8d0" /> {/* Голова */}
          <path d="M45 28 Q50 33 55 28" stroke="#333" fill="none" strokeWidth="0.5" /> {/* Улыбка */}
          <circle cx="45" cy="26" r="2" fill="#111" /> {/* Левый глаз */}
          <circle cx="55" cy="26" r="2" fill="#111" /> {/* Правый глаз */}
          <circle cx="45.5" cy="25.5" r="0.6" fill="white" /> {/* Блик в левом глазу */}
          <circle cx="55.5" cy="25.5" r="0.6" fill="white" /> {/* Блик в правом глазу */}
          <circle cx="50" cy="30" r="1.5" fill="#e74c3c" /> {/* Нос */}
          
          {/* Казахские орнаменты на одежде */}
          <path d="M50 35 L46 38 L50 40 L54 38 L50 35" fill="#FFD700" /> {/* Воротник */}
          <path d="M46 38 L46 42 L50 44 L54 42 L54 38" fill="#0e766e" stroke="#FFD700" strokeWidth="0.5" /> {/* Верх одежды */}
          
          {/* Казахские орнаменты на шапке */}
          <path d="M38 25 Q50 10 62 25" fill="#0e766e" stroke="#FFD700" strokeWidth="1" /> {/* Шапка */}
          <path d="M42 22 Q50 18 58 22" fill="none" stroke="#FFD700" strokeWidth="1" /> {/* Узор на шапке */}
          <path 
            d="M44 20 Q46 18 48 20 M52 20 Q54 18 56 20" 
            fill="none" 
            stroke="#FFD700" 
            strokeWidth="1" 
          /> {/* Узоры на шапке */}
          
          {/* Уши */}
          <ellipse cx="40" cy="23" rx="3" ry="4" fill="#f5e8d0" />
          <ellipse cx="60" cy="23" rx="3" ry="4" fill="#f5e8d0" />
          
          {/* Пятна */}
          <circle cx="42" cy="32" r="1.5" fill="#6d5c4d" />
          <circle cx="58" cy="32" r="1.5" fill="#6d5c4d" />
          <circle cx="47" cy="34" r="1" fill="#6d5c4d" />
          <circle cx="53" cy="34" r="1" fill="#6d5c4d" />
          
          {/* Лапы */}
          <path d="M45 42 L40 50" stroke="#f5e8d0" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M55 42 L60 50" stroke="#f5e8d0" strokeWidth="2.5" strokeLinecap="round" />
          
          {/* Хвост */}
          <path 
            d="M50 44 Q40 55 35 45" 
            stroke="#f5e8d0" 
            strokeWidth="2.5" 
            fill="none" 
            strokeLinecap="round"
            className="animate-wag" 
          />
          <circle cx="37" cy="47" r="1" fill="#6d5c4d" /> {/* Пятно на хвосте */}
          <circle cx="42" cy="52" r="1" fill="#6d5c4d" /> {/* Пятно на хвосте */}
        </g>
        
        {/* Web3 элементы */}
        <g className="web3-elements">
          <circle 
            cx="30" cy="30" r="2" 
            fill="#9C27B0" 
            className="animate-float-slow" 
            style={{ animationDelay: '0.2s' }}
          />
          <circle 
            cx="70" cy="30" r="2" 
            fill="#3F51B5" 
            className="animate-float-slow" 
            style={{ animationDelay: '0.5s' }}
          />
          <circle 
            cx="25" cy="60" r="1.5" 
            fill="#03A9F4" 
            className="animate-float-slow" 
            style={{ animationDelay: '0.7s' }}
          />
          <circle 
            cx="75" cy="60" r="1.5" 
            fill="#4CAF50" 
            className="animate-float-slow" 
            style={{ animationDelay: '1s' }}
          />
          
          {/* Цифровые элементы сзади */}
          <line x1="10" y1="20" x2="15" y2="20" stroke="#03A9F4" strokeWidth="0.5" className="animate-blink-slow" />
          <line x1="12" y1="25" x2="20" y2="25" stroke="#4CAF50" strokeWidth="0.5" className="animate-blink-slow" style={{ animationDelay: '1.5s' }} />
          <line x1="85" y1="20" x2="90" y2="20" stroke="#9C27B0" strokeWidth="0.5" className="animate-blink-slow" style={{ animationDelay: '0.7s' }} />
          <line x1="80" y1="25" x2="88" y2="25" stroke="#FF9800" strokeWidth="0.5" className="animate-blink-slow" style={{ animationDelay: '1.2s' }} />
          
          {/* Круглые частицы */}
          <circle 
            cx="20" cy="75" r="1" 
            fill="#FF9800" 
            className="animate-pulse-random" 
            style={{ animationDelay: '0.1s' }}
          />
          <circle 
            cx="80" cy="75" r="1" 
            fill="#F44336" 
            className="animate-pulse-random" 
            style={{ animationDelay: '0.8s' }}
          />
        </g>
        
        {/* Градиенты */}
        <defs>
          <linearGradient id="flameGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FF9800" />
            <stop offset="60%" stopColor="#F44336" />
            <stop offset="100%" stopColor="#FFEB3B" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

export default MassaganLogo;