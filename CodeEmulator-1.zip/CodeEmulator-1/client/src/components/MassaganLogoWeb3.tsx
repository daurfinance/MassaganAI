import React, { useEffect, useRef } from 'react';

/**
 * Современный анимированный Web3 Platinum логотип MassaganAI
 * с казахским снежным барсом на ракете
 */
const MassaganLogoWeb3: React.FC<{ size?: number }> = ({ size = 60 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Устанавливаем размер canvas
    canvas.width = size * 2;  // Удваиваем размер для лучшего качества
    canvas.height = size * 2;
    
    // Масштабирование для улучшения качества на retina дисплеях
    ctx.scale(2, 2);
    
    // Функция для отрисовки логотипа
    const draw = (time: number) => {
      // Очистка канваса
      ctx.clearRect(0, 0, size, size);
      
      // Анимационные параметры
      const pulse = Math.sin(time / 500) * 0.1 + 0.9;
      const rotation = time / 2000;
      
      // Цвета в стиле Web3 Platinum
      const platinumGradient = ctx.createLinearGradient(0, 0, size, size);
      platinumGradient.addColorStop(0, '#D9D9D9');
      platinumGradient.addColorStop(0.5, '#FFFFFF');
      platinumGradient.addColorStop(1, '#D0D0D0');
      
      const platinumOutline = '#A0A0A0';
      
      const glowColor = `rgba(255, 255, 255, ${0.3 + Math.sin(time / 300) * 0.2})`;
      
      // Рисуем внешний круг (основа логотипа)
      ctx.save();
      ctx.translate(size / 2, size / 2);
      ctx.rotate(rotation);
      
      // Внешний свет (эффект свечения)
      ctx.beginPath();
      ctx.arc(0, 0, size / 2 * pulse, 0, Math.PI * 2);
      ctx.fillStyle = glowColor;
      ctx.filter = 'blur(5px)';
      ctx.fill();
      ctx.filter = 'none';
      
      // Внешний круг с платиновым градиентом
      ctx.beginPath();
      ctx.arc(0, 0, size / 2.2, 0, Math.PI * 2);
      ctx.fillStyle = platinumGradient;
      ctx.fill();
      ctx.strokeStyle = platinumOutline;
      ctx.lineWidth = 2;
      ctx.stroke();
      
      // Внутренний круг (фон для барса)
      const innerGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, size / 2.8);
      innerGradient.addColorStop(0, '#303540');
      innerGradient.addColorStop(1, '#1A1D25');
      
      ctx.beginPath();
      ctx.arc(0, 0, size / 2.8, 0, Math.PI * 2);
      ctx.fillStyle = innerGradient;
      ctx.fill();
      
      // Цифровой орнамент (элементы Web3)
      ctx.strokeStyle = 'rgba(200, 220, 255, 0.7)';
      ctx.lineWidth = 0.5;
      
      for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * Math.PI * 2;
        const radius = size / 3;
        
        ctx.save();
        ctx.rotate(angle);
        
        // Линии орнамента
        ctx.beginPath();
        ctx.moveTo(radius * 0.7, 0);
        ctx.lineTo(radius, 0);
        ctx.stroke();
        
        // Точки орнамента с пульсацией
        const dotPulse = Math.sin(time / 200 + i) * 0.3 + 0.7;
        ctx.beginPath();
        ctx.arc(radius * 0.65, 0, 1 * dotPulse, 0, Math.PI * 2);
        ctx.fillStyle = '#88AAFF';
        ctx.fill();
        
        ctx.restore();
      }
      
      // Снежный барс (стилизованный)
      ctx.save();
      ctx.rotate(-rotation * 0.5); // Противоположное вращение для эффекта
      
      // Голова барса
      ctx.beginPath();
      ctx.ellipse(0, -size / 10, size / 8, size / 10, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      // Мордочка
      ctx.beginPath();
      ctx.ellipse(0, -size / 10, size / 10, size / 12, 0, 0, Math.PI);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      
      // Уши
      ctx.beginPath();
      ctx.moveTo(-size / 12, -size / 7);
      ctx.lineTo(-size / 20, -size / 4.5);
      ctx.lineTo(-size / 30, -size / 6.5);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      ctx.beginPath();
      ctx.moveTo(size / 12, -size / 7);
      ctx.lineTo(size / 20, -size / 4.5);
      ctx.lineTo(size / 30, -size / 6.5);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      // Глаза
      ctx.beginPath();
      ctx.ellipse(-size / 25, -size / 9, size / 80, size / 60, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();
      
      ctx.beginPath();
      ctx.ellipse(size / 25, -size / 9, size / 80, size / 60, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();
      
      // Нос
      ctx.beginPath();
      ctx.ellipse(0, -size / 11, size / 60, size / 80, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();
      
      // Тело барса (на ракете)
      ctx.beginPath();
      ctx.ellipse(0, size / 30, size / 10, size / 6, 0, Math.PI, Math.PI * 2);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      // Пятнышки
      for (let i = 0; i < 5; i++) {
        const x = (Math.random() - 0.5) * size / 10;
        const y = size / 30 + (Math.random() - 0.5) * size / 10;
        
        ctx.beginPath();
        ctx.arc(x, y, size / 100, 0, Math.PI * 2);
        ctx.fillStyle = '#555555';
        ctx.fill();
      }
      
      // Ракета
      ctx.beginPath();
      ctx.moveTo(-size / 15, size / 12);
      ctx.lineTo(size / 15, size / 12);
      ctx.lineTo(size / 15, size / 6);
      ctx.lineTo(0, size / 4.5);
      ctx.lineTo(-size / 15, size / 6);
      ctx.closePath();
      
      const rocketGradient = ctx.createLinearGradient(-size / 15, 0, size / 15, 0);
      rocketGradient.addColorStop(0, '#88AAFF');
      rocketGradient.addColorStop(1, '#6080DD');
      
      ctx.fillStyle = rocketGradient;
      ctx.fill();
      
      // Пламя ракеты (анимированное)
      const flameSize = (Math.sin(time / 100) * 0.2 + 1) * (size / 18);
      
      ctx.beginPath();
      ctx.moveTo(-size / 20, size / 6);
      ctx.quadraticCurveTo(-size / 40, size / 6 + flameSize, 0, size / 6 + flameSize * 1.5);
      ctx.quadraticCurveTo(size / 40, size / 6 + flameSize, size / 20, size / 6);
      
      const flameGradient = ctx.createLinearGradient(0, size / 6, 0, size / 6 + flameSize * 1.5);
      flameGradient.addColorStop(0, '#FF6600');
      flameGradient.addColorStop(0.6, '#FFCC00');
      flameGradient.addColorStop(1, 'rgba(255, 255, 255, 0.8)');
      
      ctx.fillStyle = flameGradient;
      ctx.fill();
      
      // Элементы казахской одежды (чапан)
      ctx.beginPath();
      ctx.moveTo(-size / 15, -size / 15);
      ctx.lineTo(-size / 12, size / 20);
      ctx.lineTo(-size / 40, size / 15);
      ctx.lineTo(-size / 30, -size / 15);
      ctx.closePath();
      
      const chpanGradient = ctx.createLinearGradient(-size / 15, -size / 15, -size / 15, size / 15);
      chpanGradient.addColorStop(0, '#0066CC');
      chpanGradient.addColorStop(1, '#004488');
      
      ctx.fillStyle = chpanGradient;
      ctx.fill();
      
      // Орнамент на одежде
      ctx.beginPath();
      ctx.moveTo(-size / 15, -size / 18);
      ctx.lineTo(-size / 13, -size / 18);
      ctx.strokeStyle = '#FFD700';
      ctx.lineWidth = 0.5;
      ctx.stroke();
      
      ctx.restore();
      
      // Внешний декоративный элемент (кольцо с прерывистой линией)
      ctx.beginPath();
      for (let i = 0; i < 60; i++) {
        const angle = (i / 60) * Math.PI * 2;
        if (i % 3 === 0) continue; // Создаем прерывистую линию
        
        const startRadius = size / 2 * 0.85;
        const endRadius = size / 2 * 0.9;
        
        ctx.moveTo(
          Math.cos(angle) * startRadius + size / 2, 
          Math.sin(angle) * startRadius + size / 2
        );
        ctx.lineTo(
          Math.cos(angle) * endRadius + size / 2, 
          Math.sin(angle) * endRadius + size / 2
        );
      }
      ctx.strokeStyle = platinumOutline;
      ctx.lineWidth = 0.5;
      ctx.stroke();
      
      // Запрос следующего кадра
      requestAnimationFrame(draw);
    };
    
    // Запускаем анимацию
    const animationId = requestAnimationFrame(draw);
    
    // Очистка при размонтировании
    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [size]);
  
  return (
    <canvas
      ref={canvasRef}
      style={{
        width: size,
        height: size,
        display: 'block'
      }}
    />
  );
};

export default MassaganLogoWeb3;