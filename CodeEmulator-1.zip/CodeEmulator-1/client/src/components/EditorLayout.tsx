import { useState, useEffect, useRef } from 'react';
import CodeEditor from './CodeEditor';
import CodePreview from './CodePreview';
import ViewportSelector, { DeviceType } from './ViewportSelector';
import { Button } from '@/components/ui/button';
import { Play } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Определяем типы для Split.js
declare global {
  interface Window {
    Split: any;
  }
}

interface EditorLayoutProps {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  onCodeChange: (type: "html" | "css" | "js", code: string) => void;
}

export default function EditorLayout({ htmlCode, cssCode, jsCode, onCodeChange }: EditorLayoutProps) {
  const [viewportSize, setViewportSize] = useState<DeviceType>("responsive");
  const [showConsole, setShowConsole] = useState(false);
  const [consoleMessages, setConsoleMessages] = useState<string[]>([]);
  const [iframeKey, setIframeKey] = useState(Date.now());
  const splitContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Listen for messages from the iframe console
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data && event.data.source === 'iframe-console') {
        const { type, message } = event.data;
        const formattedMessage = `[${type}] ${message}`;
        
        setConsoleMessages((prev) => [...prev, formattedMessage]);
        
        if (type === 'error') {
          setShowConsole(true);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  // Initialize Split.js
  useEffect(() => {
    if (splitContainerRef.current) {
      // Check if Split.js is in scope
      if (typeof window.Split !== 'undefined') {
        const split = window.Split(
          ['#code-editor-panel', '#preview-panel'],
          {
            sizes: [50, 50],
            minSize: [300, 300],
            gutterSize: 8,
            direction: 'horizontal',
            elementStyle: (dimension: string, size: number, gutterSize: number) => ({
              'flex-basis': `calc(${size}% - ${gutterSize}px)`,
            }),
            gutterStyle: () => ({
              'background-color': '#e5e7eb',
              'cursor': 'col-resize',
              'width': '8px',
            }),
          }
        );
        
        return () => {
          split.destroy();
        };
      }
    }
  }, []);
  
  const handleRunCode = () => {
    // Force iframe reload by changing the key
    setIframeKey(Date.now());
    toast({
      title: "Code running",
      description: "Your code has been refreshed in the preview",
    });
  };
  
  const handleClearConsole = () => {
    setConsoleMessages([]);
  };

  return (
    <div className="h-[calc(100vh-57px)] flex flex-col">
      <div className="flex bg-gray-100 border-b border-gray-200 px-4 items-center justify-between">
        <div className="py-2">
          <h2 className="text-sm font-medium">Редактор</h2>
        </div>
        <div className="flex items-center space-x-4">
          <ViewportSelector size={viewportSize} onChange={setViewportSize} />
          <Button 
            onClick={handleRunCode}
            className="bg-green-600 hover:bg-green-700 text-white"
            size="sm"
          >
            <Play className="mr-2 h-4 w-4" /> Запустить
          </Button>
          {showConsole && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowConsole(false)}
              className="text-xs"
            >
              Скрыть консоль
            </Button>
          )}
        </div>
      </div>
      
      <div className="flex-1 flex overflow-hidden" ref={splitContainerRef}>
        <div id="code-editor-panel" className="h-full overflow-hidden">
          <CodeEditor
            htmlCode={htmlCode}
            cssCode={cssCode}
            jsCode={jsCode}
            onCodeChange={onCodeChange}
          />
        </div>
        <div id="preview-panel" className="h-full overflow-hidden">
          <CodePreview 
            key={iframeKey}
            htmlCode={htmlCode}
            cssCode={cssCode}
            jsCode={jsCode}
            viewportSize={viewportSize}
            showConsole={showConsole}
            consoleMessages={consoleMessages}
            onClearConsole={handleClearConsole}
          />
        </div>
      </div>
    </div>
  );
}
