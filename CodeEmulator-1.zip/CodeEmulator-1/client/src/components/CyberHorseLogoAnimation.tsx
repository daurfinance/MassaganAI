import React, { useEffect, useRef } from 'react';

/**
 * Современный анимированный Web3 Platinum логотип MassaganAI
 * с казахским снежным барсом на киборг-лошади
 */
const CyberHorseLogoAnimation: React.FC<{ width?: number, height?: number }> = ({ 
  width = 200, 
  height = 200 
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Устанавливаем размер canvas, увеличиваем для ретина дисплеев
    canvas.width = width * 2;
    canvas.height = height * 2;
    
    // Масштабирование для улучшения качества
    ctx.scale(2, 2);
    
    // Настройки анимации
    let frameCount = 0;
    
    // Функция для отрисовки анимированного логотипа
    const draw = (time: number) => {
      // Очищаем холст
      ctx.clearRect(0, 0, width, height);
      
      // Увеличиваем счетчик кадров
      frameCount++;
      
      // Анимационные параметры
      const pulse = Math.sin(time / 500) * 0.1 + 0.95;
      const rotation = Math.sin(time / 3000) * 0.05;
      
      // Градиенты в стиле Web3 Platinum
      const bgGradient = ctx.createRadialGradient(width/2, height/2, 0, width/2, height/2, width*0.7);
      bgGradient.addColorStop(0, '#252A3A');
      bgGradient.addColorStop(0.7, '#1A1E2A');
      bgGradient.addColorStop(1, '#141824');
      
      // Фон
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, width, height);
      
      // Центрируем все рисование
      ctx.save();
      ctx.translate(width/2, height/2);
      ctx.rotate(rotation);
      
      // Декоративный круг сзади (технологическая аура)
      const circleGlow = ctx.createRadialGradient(0, 0, width*0.1, 0, 0, width*0.4);
      circleGlow.addColorStop(0, 'rgba(120, 180, 255, 0.1)');
      circleGlow.addColorStop(0.7, 'rgba(80, 120, 220, 0.05)');
      circleGlow.addColorStop(1, 'rgba(50, 80, 180, 0)');
      
      ctx.beginPath();
      ctx.arc(0, 0, width*0.4 * pulse, 0, Math.PI*2);
      ctx.fillStyle = circleGlow;
      ctx.fill();
      
      // Цифровые эффекты (маленькие пульсирующие точки)
      for (let i = 0; i < 30; i++) {
        const angle = (i / 30) * Math.PI * 2 + time / 2000;
        const distance = width * 0.25 + Math.sin(time / 1000 + i) * width * 0.03;
        const x = Math.cos(angle) * distance;
        const y = Math.sin(angle) * distance;
        const dotSize = (Math.sin(time / 200 + i*5) * 0.5 + 1) * 1.5;
        
        ctx.beginPath();
        ctx.arc(x, y, dotSize, 0, Math.PI*2);
        
        const opacity = 0.3 + Math.sin(time / 300 + i) * 0.2;
        ctx.fillStyle = `rgba(140, 200, 255, ${opacity})`;
        ctx.fill();
      }
      
      // Стилизованная киборг-лошадь
      drawCyberHorse(ctx, time, width * 0.2);
      
      // Барс, сидящий на лошади
      drawSnowLeopard(ctx, time, width * 0.14);
      
      // Платиновый круг вокруг
      ctx.beginPath();
      ctx.arc(0, 0, width * 0.3, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(200, 200, 220, 0.2)';
      ctx.lineWidth = 1;
      ctx.stroke();
      
      // Внешний платиновый круг с прерывистой линией
      ctx.beginPath();
      for (let i = 0; i < 120; i++) {
        const angle = (i / 120) * Math.PI * 2;
        if (i % 3 !== 0) {
          const startRadius = width * 0.31;
          const endRadius = width * 0.33;
          ctx.moveTo(Math.cos(angle) * startRadius, Math.sin(angle) * startRadius);
          ctx.lineTo(Math.cos(angle) * endRadius, Math.sin(angle) * endRadius);
        }
      }
      ctx.strokeStyle = 'rgba(210, 215, 230, 0.4)';
      ctx.lineWidth = 0.5;
      ctx.stroke();
      
      // Технологические линии (соединения)
      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2 + time / 5000;
        
        // Начальная и конечная точки линии
        const x1 = Math.cos(angle) * width * 0.05;
        const y1 = Math.sin(angle) * width * 0.05;
        const x2 = Math.cos(angle) * width * 0.28;
        const y2 = Math.sin(angle) * width * 0.28;
        
        // Создаем градиент для линии
        const lineGradient = ctx.createLinearGradient(x1, y1, x2, y2);
        lineGradient.addColorStop(0, 'rgba(120, 160, 255, 0.1)');
        lineGradient.addColorStop(0.5, 'rgba(140, 180, 255, 0.6)');
        lineGradient.addColorStop(1, 'rgba(100, 140, 255, 0.1)');
        
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = lineGradient;
        ctx.lineWidth = 0.5;
        ctx.stroke();
        
        // Добавляем точки на пересечениях
        ctx.beginPath();
        ctx.arc(x2, y2, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(160, 200, 255, 0.8)';
        ctx.fill();
      }
      
      // Текст "MassaganAI"
      ctx.fillStyle = 'rgba(220, 230, 240, 0.9)';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.fillText('MassaganAI', 0, height * 0.35);
      
      // Текст "ИИ-эмулятор"
      ctx.fillStyle = 'rgba(180, 200, 220, 0.7)';
      ctx.font = '10px Arial';
      ctx.fillText('ИИ-эмулятор', 0, height * 0.38);
      
      ctx.restore();
      
      // Запрос следующего кадра
      requestAnimationFrame(draw);
    };
    
    // Функция для рисования стилизованной киборг-лошади
    function drawCyberHorse(ctx: CanvasRenderingContext2D, time: number, size: number) {
      // Сохраняем контекст
      ctx.save();
      
      // Смещаем лошадь чуть вниз
      ctx.translate(0, size * 0.2);
      
      // Анимация движения
      const gallop = Math.sin(time / 200) * size * 0.05;
      ctx.translate(0, gallop);
      
      // Тело лошади
      ctx.beginPath();
      ctx.ellipse(0, 0, size * 0.8, size * 0.5, 0, 0, Math.PI * 2);
      const horseGradient = ctx.createLinearGradient(-size, -size, size, size);
      horseGradient.addColorStop(0, '#505668');
      horseGradient.addColorStop(0.5, '#808698');
      horseGradient.addColorStop(1, '#404456');
      ctx.fillStyle = horseGradient;
      ctx.fill();
      
      // Линии киборга на теле
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(-size * 0.7, -size * 0.3 + i * size * 0.15);
        ctx.lineTo(size * 0.7, -size * 0.3 + i * size * 0.15);
        ctx.strokeStyle = `rgba(100, 200, 255, ${0.2 + Math.sin(time / 300 + i) * 0.1})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      
      // Голова
      ctx.beginPath();
      ctx.ellipse(-size * 0.7, -size * 0.1, size * 0.4, size * 0.2, -Math.PI/4, 0, Math.PI * 2);
      ctx.fillStyle = horseGradient;
      ctx.fill();
      
      // Уши
      ctx.beginPath();
      ctx.moveTo(-size * 0.9, -size * 0.3);
      ctx.lineTo(-size * 0.8, -size * 0.5);
      ctx.lineTo(-size * 0.7, -size * 0.3);
      ctx.fillStyle = '#606678';
      ctx.fill();
      
      ctx.beginPath();
      ctx.moveTo(-size * 0.8, -size * 0.3);
      ctx.lineTo(-size * 0.7, -size * 0.5);
      ctx.lineTo(-size * 0.6, -size * 0.3);
      ctx.fillStyle = '#606678';
      ctx.fill();
      
      // Глаз (светящийся)
      ctx.beginPath();
      ctx.arc(-size * 0.8, -size * 0.1, size * 0.08, 0, Math.PI * 2);
      const eyeGlow = ctx.createRadialGradient(
        -size * 0.8, -size * 0.1, 0,
        -size * 0.8, -size * 0.1, size * 0.08
      );
      eyeGlow.addColorStop(0, '#FFFFFF');
      eyeGlow.addColorStop(0.5, '#80CCFF');
      eyeGlow.addColorStop(1, '#4080FF');
      ctx.fillStyle = eyeGlow;
      ctx.fill();
      
      // Блики в глазу
      ctx.beginPath();
      ctx.arc(-size * 0.78, -size * 0.12, size * 0.02, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      
      // Ноги (передние)
      const legAnimation = Math.sin(time / 200) * size * 0.1;
      
      // Передняя левая нога
      ctx.beginPath();
      ctx.moveTo(-size * 0.4, size * 0.3);
      ctx.lineTo(-size * 0.5, size * 0.7 + legAnimation);
      ctx.lineWidth = size * 0.12;
      ctx.strokeStyle = '#606678';
      ctx.stroke();
      
      // Передняя правая нога (в другой фазе движения)
      ctx.beginPath();
      ctx.moveTo(-size * 0.2, size * 0.3);
      ctx.lineTo(-size * 0.3, size * 0.7 - legAnimation);
      ctx.lineWidth = size * 0.12;
      ctx.strokeStyle = '#606678';
      ctx.stroke();
      
      // Задняя левая нога
      ctx.beginPath();
      ctx.moveTo(size * 0.2, size * 0.3);
      ctx.lineTo(size * 0.3, size * 0.7 - legAnimation);
      ctx.lineWidth = size * 0.12;
      ctx.strokeStyle = '#606678';
      ctx.stroke();
      
      // Задняя правая нога
      ctx.beginPath();
      ctx.moveTo(size * 0.4, size * 0.3);
      ctx.lineTo(size * 0.5, size * 0.7 + legAnimation);
      ctx.lineWidth = size * 0.12;
      ctx.strokeStyle = '#606678';
      ctx.stroke();
      
      // Хвост (с киберенетическими элементами)
      ctx.beginPath();
      ctx.moveTo(size * 0.7, 0);
      
      // Анимация хвоста
      const tailWave = Math.sin(time / 300) * size * 0.1;
      ctx.quadraticCurveTo(
        size * 0.9, size * 0.1 + tailWave,
        size * 0.9, size * 0.3 + tailWave
      );
      
      ctx.lineWidth = size * 0.08;
      const tailGradient = ctx.createLinearGradient(size * 0.7, 0, size * 0.9, size * 0.3);
      tailGradient.addColorStop(0, '#606678');
      tailGradient.addColorStop(1, '#4080FF');
      ctx.strokeStyle = tailGradient;
      ctx.stroke();
      
      // Светящиеся сегменты на хвосте
      for (let i = 0; i < 5; i++) {
        const t = i / 5;
        const tx = size * 0.7 + (size * 0.9 - size * 0.7) * t;
        const ty = (size * 0.3 + tailWave) * t;
        
        ctx.beginPath();
        ctx.arc(tx, ty, size * 0.03, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(100, 200, 255, ${0.5 + Math.sin(time / 200 + i) * 0.5})`;
        ctx.fill();
      }
      
      // Кибернетические детали (механические соединения)
      // Шея
      ctx.beginPath();
      ctx.moveTo(-size * 0.5, -size * 0.1);
      ctx.lineTo(-size * 0.3, 0);
      ctx.lineWidth = size * 0.05;
      ctx.strokeStyle = '#4080FF';
      ctx.stroke();
      
      // Механические соединения ног
      const jointColor = 'rgba(100, 180, 255, 0.8)';
      
      // Плечевое соединение
      ctx.beginPath();
      ctx.arc(-size * 0.4, size * 0.3, size * 0.05, 0, Math.PI * 2);
      ctx.fillStyle = jointColor;
      ctx.fill();
      
      // Бедренное соединение
      ctx.beginPath();
      ctx.arc(size * 0.4, size * 0.3, size * 0.05, 0, Math.PI * 2);
      ctx.fillStyle = jointColor;
      ctx.fill();
      
      ctx.restore();
    }
    
    // Функция для рисования снежного барса
    function drawSnowLeopard(ctx: CanvasRenderingContext2D, time: number, size: number) {
      // Сохраняем контекст
      ctx.save();
      
      // Позиционируем барса на спине лошади
      ctx.translate(0, -size * 0.5);
      
      // Анимация движения в такт с лошадью
      const gallop = Math.sin(time / 200) * size * 0.05;
      ctx.translate(0, gallop);
      
      // Тело барса
      ctx.beginPath();
      ctx.ellipse(0, 0, size * 0.7, size * 0.4, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      // Пятна на теле
      for (let i = 0; i < 10; i++) {
        const x = (Math.random() - 0.5) * size;
        const y = (Math.random() - 0.5) * size * 0.6;
        
        ctx.beginPath();
        ctx.arc(x, y, size * 0.05, 0, Math.PI * 2);
        ctx.fillStyle = '#505050';
        ctx.fill();
      }
      
      // Голова
      ctx.beginPath();
      ctx.ellipse(-size * 0.5, -size * 0.2, size * 0.3, size * 0.25, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      // Глаза
      ctx.beginPath();
      ctx.arc(-size * 0.6, -size * 0.25, size * 0.05, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();
      
      ctx.beginPath();
      ctx.arc(-size * 0.45, -size * 0.25, size * 0.05, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();
      
      // Блики в глазах
      ctx.beginPath();
      ctx.arc(-size * 0.58, -size * 0.27, size * 0.02, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      
      ctx.beginPath();
      ctx.arc(-size * 0.43, -size * 0.27, size * 0.02, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      
      // Нос
      ctx.beginPath();
      ctx.arc(-size * 0.52, -size * 0.15, size * 0.03, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();
      
      // Уши
      ctx.beginPath();
      ctx.moveTo(-size * 0.7, -size * 0.35);
      ctx.lineTo(-size * 0.6, -size * 0.55);
      ctx.lineTo(-size * 0.5, -size * 0.35);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      ctx.beginPath();
      ctx.moveTo(-size * 0.5, -size * 0.35);
      ctx.lineTo(-size * 0.4, -size * 0.55);
      ctx.lineTo(-size * 0.3, -size * 0.35);
      ctx.fillStyle = '#F0F0F0';
      ctx.fill();
      
      // Казахская одежда (чапан) - стилизованная
      ctx.beginPath();
      ctx.moveTo(-size * 0.2, -size * 0.35);
      ctx.lineTo(size * 0.3, -size * 0.2);
      ctx.lineTo(size * 0.1, size * 0.2);
      ctx.lineTo(-size * 0.4, size * 0.1);
      ctx.closePath();
      
      const chapanGradient = ctx.createLinearGradient(-size * 0.3, -size * 0.3, size * 0.3, size * 0.3);
      chapanGradient.addColorStop(0, '#0066CC');
      chapanGradient.addColorStop(1, '#004488');
      
      ctx.fillStyle = chapanGradient;
      ctx.globalAlpha = 0.5; // Прозрачность для эффекта
      ctx.fill();
      ctx.globalAlpha = 1.0;
      
      // Казахский орнамент на одежде
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.arc(-size * 0.1 + i * size * 0.15, -size * 0.1 + i * size * 0.1, size * 0.04, 0, Math.PI * 2);
        ctx.strokeStyle = '#FFD700';
        ctx.lineWidth = 1;
        ctx.stroke();
      }
      
      // Хвост
      ctx.beginPath();
      
      // Анимация хвоста
      const tailWave = Math.sin(time / 300) * size * 0.1;
      
      ctx.moveTo(size * 0.6, 0);
      ctx.quadraticCurveTo(
        size * 0.8, tailWave,
        size * 0.9, size * 0.2 + tailWave
      );
      
      ctx.lineWidth = size * 0.1;
      ctx.strokeStyle = '#F0F0F0';
      ctx.stroke();
      
      ctx.restore();
    }
    
    // Запускаем анимацию
    const animationId = requestAnimationFrame(draw);
    
    // Очистка при размонтировании
    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [width, height]);
  
  return (
    <canvas
      ref={canvasRef}
      style={{
        width,
        height,
        display: 'block'
      }}
    />
  );
};

export default CyberHorseLogoAnimation;