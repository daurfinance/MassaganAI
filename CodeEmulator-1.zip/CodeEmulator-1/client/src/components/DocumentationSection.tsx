/**
 * Компонент документации MassaganAI
 * Отображает подробную информацию о функциональности проекта и используемых технологиях
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React, { useState } from 'react';
import { 
  FileText,
  Code,
  Database,
  Globe,
  Users,
  Bot,
  Cpu,
  ChevronDown,
  ChevronUp,
  Presentation,
  PenTool,
  Layers,
  BrainCircuit,
  Film,
  Image as ImageIcon,
  Sparkles
} from 'lucide-react';
import { useLanguage } from '@/lib/LanguageContext';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const DocumentationSection: React.FC = () => {
  const { t } = useLanguage();
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <section className="py-16 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            MassaganAI: Документация проекта
          </h2>
          <p className="mt-4 text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Подробное описание возможностей платформы, технологий и функциональности
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid grid-cols-4">
              <TabsTrigger value="overview">Обзор</TabsTrigger>
              <TabsTrigger value="features">Функции</TabsTrigger>
              <TabsTrigger value="tech">Технологии</TabsTrigger>
              <TabsTrigger value="apis">API и интеграции</TabsTrigger>
            </TabsList>

            {/* Вкладка обзора */}
            <TabsContent value="overview" className="space-y-4 py-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center mb-2">
                    <Sparkles className="h-6 w-6 text-blue-500 mr-2" />
                    <CardTitle>Что такое MassaganAI?</CardTitle>
                  </div>
                  <CardDescription>
                    Универсальное Казахстанское ИИ-решение для разработки и эмуляции интерфейсов
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>
                    <strong>MassaganAI</strong> (от казахского "Мәссаған", означающего "Wow!") - это инновационная платформа для
                    разработки и эмуляции интерфейсов с использованием искусственного интеллекта. Система позволяет загружать,
                    анализировать и эмулировать любой код, автоматически создавать дизайн и интерфейс, соединять бэкенд с фронтендом.
                  </p>
                  
                  <h3 className="text-xl font-semibold mt-4">Ключевые возможности:</h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Загрузка и анализ кода из различных источников (GitHub, ZIP-файлы)</li>
                    <li>Автоматическое создание дизайна и интерфейса на основе анализа кода</li>
                    <li>Эмуляция интерфейсов для различных устройств (Android, iPhone, Windows, macOS)</li>
                    <li>Генерация фронтенда на основе бэкенд-кода</li>
                    <li>Поддержка различных языков программирования и фреймворков</li>
                    <li>Мультиязычный интерфейс (7 языков)</li>
                    <li>ИИ-лаборатория для моделирования сценариев и анализа данных</li>
                    <li>Создание презентаций, чертежей и 3D-моделей</li>
                    <li>Генерация и обработка медиаконтента (видео, изображения, аудио)</li>
                    <li>Интеграция с Telegram и социальными сетями</li>
                  </ul>
                  
                  <p className="mt-4">
                    Платформа разработана как полноценная экосистема для разработчиков, дизайнеров и бизнес-аналитиков,
                    объединяющая передовые технологии искусственного интеллекта и удобный пользовательский интерфейс.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Вкладка функций */}
            <TabsContent value="features" className="space-y-4 py-4">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="code-emulation">
                  <AccordionTrigger className="hover:bg-muted/50 px-4 rounded-lg">
                    <div className="flex items-center">
                      <Code className="h-5 w-5 text-blue-500 mr-2" />
                      <span>ИИ-эмулятор кода и интерфейсов</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pt-2 pb-4">
                    <p className="mb-2">
                      ИИ-эмулятор анализирует загруженный код и создает интерактивный интерфейс, эмулирующий функциональность приложения.
                    </p>
                    <ul className="list-disc pl-6 space-y-1">
                      <li>Загрузка кода из GitHub, ZIP-файлов или локальных источников</li>
                      <li>Эмуляция для различных устройств и платформ</li>
                      <li>Автоматическое соединение бэкенда с фронтендом</li>
                      <li>Генерация пользовательского интерфейса на основе анализа кода</li>
                      <li>Возможность редактирования и изменения эмулируемого интерфейса</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="ai-lab">
                  <AccordionTrigger className="hover:bg-muted/50 px-4 rounded-lg">
                    <div className="flex items-center">
                      <BrainCircuit className="h-5 w-5 text-blue-500 mr-2" />
                      <span>ИИ-лаборатория</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pt-2 pb-4">
                    <p className="mb-2">
                      Виртуальная ИИ-лаборатория для моделирования сценариев и анализа различных типов данных.
                    </p>
                    <ul className="list-disc pl-6 space-y-1">
                      <li>Моделирование бизнес, технических, исследовательских и образовательных сценариев</li>
                      <li>Анализ документов различных типов (текст, PDF, изображения, аудио, видео)</li>
                      <li>Анализ кода с предложениями по оптимизации</li>
                      <li>Визуализация результатов моделирования и анализа</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="presentations">
                  <AccordionTrigger className="hover:bg-muted/50 px-4 rounded-lg">
                    <div className="flex items-center">
                      <Presentation className="h-5 w-5 text-blue-500 mr-2" />
                      <span>Создание презентаций</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pt-2 pb-4">
                    <p className="mb-2">
                      Автоматическое создание презентаций по заданной теме с использованием ИИ.
                    </p>
                    <ul className="list-disc pl-6 space-y-1">
                      <li>Генерация слайдов по текстовому запросу</li>
                      <li>Различные стили и темы оформления</li>
                      <li>Возможность редактирования и настройки созданных презентаций</li>
                      <li>Создание аудио-нарратива для презентаций</li>
                      <li>Экспорт в различные форматы</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="blueprints">
                  <AccordionTrigger className="hover:bg-muted/50 px-4 rounded-lg">
                    <div className="flex items-center">
                      <PenTool className="h-5 w-5 text-blue-500 mr-2" />
                      <span>Создание чертежей</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pt-2 pb-4">
                    <p className="mb-2">
                      Генерация чертежей различных типов с использованием ИИ.
                    </p>
                    <ul className="list-disc pl-6 space-y-1">
                      <li>Архитектурные, инженерные, электрические, механические и интерьерные чертежи</li>
                      <li>Настройка размеров, форматов и деталей</li>
                      <li>Создание по текстовому описанию</li>
                      <li>Экспорт в SVG, PDF и PNG форматы</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="models">
                  <AccordionTrigger className="hover:bg-muted/50 px-4 rounded-lg">
                    <div className="flex items-center">
                      <Layers className="h-5 w-5 text-blue-500 mr-2" />
                      <span>3D-моделирование</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pt-2 pb-4">
                    <p className="mb-2">
                      Создание 3D-моделей по текстовому описанию с использованием ИИ.
                    </p>
                    <ul className="list-disc pl-6 space-y-1">
                      <li>Создание архитектурных, промышленных, интерьерных и абстрактных 3D-моделей</li>
                      <li>Настройка деталей, материалов и размеров</li>
                      <li>Предпросмотр и редактирование моделей</li>
                      <li>Экспорт в различные форматы</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="media">
                  <AccordionTrigger className="hover:bg-muted/50 px-4 rounded-lg">
                    <div className="flex items-center">
                      <Film className="h-5 w-5 text-blue-500 mr-2" />
                      <span>Генерация медиаконтента</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pt-2 pb-4">
                    <p className="mb-2">
                      Создание и обработка различных типов медиаконтента с использованием ИИ.
                    </p>
                    <ul className="list-disc pl-6 space-y-1">
                      <li>Генерация изображений по текстовому запросу</li>
                      <li>Создание видеороликов с озвучиванием</li>
                      <li>Озвучивание текста на различных языках</li>
                      <li>Комбинирование видео и аудио</li>
                      <li>Создание логотипов и применение фильтров к изображениям</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="telegram">
                  <AccordionTrigger className="hover:bg-muted/50 px-4 rounded-lg">
                    <div className="flex items-center">
                      <Bot className="h-5 w-5 text-blue-500 mr-2" />
                      <span>Telegram интеграция</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-4 pt-2 pb-4">
                    <p className="mb-2">
                      Интеграция с Telegram для доступа к функциям платформы через мессенджер.
                    </p>
                    <ul className="list-disc pl-6 space-y-1">
                      <li>Создание и настройка Telegram ботов</li>
                      <li>Доступ к функциям ИИ-эмулятора через бота</li>
                      <li>Генерация медиаконтента через команды в Telegram</li>
                      <li>Отслеживание прогресса выполнения задач</li>
                      <li>Временное хранение созданных файлов с автоочисткой через 48 часов</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>

            {/* Вкладка технологий */}
            <TabsContent value="tech" className="space-y-4 py-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center mb-2">
                    <Cpu className="h-6 w-6 text-blue-500 mr-2" />
                    <CardTitle>Технологический стек</CardTitle>
                  </div>
                  <CardDescription>
                    Технологии и инструменты, используемые в MassaganAI
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Фронтенд</h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li>React.js с TypeScript</li>
                        <li>Tailwind CSS для стилизации</li>
                        <li>ShadcnUI для компонентов интерфейса</li>
                        <li>TanStack Query для работы с данными</li>
                        <li>Wouter для маршрутизации</li>
                        <li>Lucide React для иконок</li>
                        <li>Vite для сборки и разработки</li>
                      </ul>

                      <h3 className="text-lg font-semibold mt-4 mb-2">Бэкенд</h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li>Node.js с Express</li>
                        <li>PostgreSQL для хранения данных</li>
                        <li>Drizzle ORM для работы с базой данных</li>
                        <li>Multer для загрузки файлов</li>
                        <li>Simple Git для работы с Git-репозиториями</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Искусственный интеллект</h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li>Perplexity API для анализа кода</li>
                        <li>Anthropic API (Claude) для обработки текста и изображений</li>
                        <li>OpenAI API для генерации контента</li>
                        <li>Python библиотеки для обработки данных и медиа</li>
                      </ul>

                      <h3 className="text-lg font-semibold mt-4 mb-2">Интеграции</h3>
                      <ul className="list-disc pl-6 space-y-1">
                        <li>Firebase для аутентификации</li>
                        <li>Stripe для платежей и подписок</li>
                        <li>Telegram Bot API</li>
                        <li>API социальных сетей</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Вкладка API и интеграций */}
            <TabsContent value="apis" className="space-y-4 py-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center mb-2">
                    <Globe className="h-6 w-6 text-blue-500 mr-2" />
                    <CardTitle>API и интеграции</CardTitle>
                  </div>
                  <CardDescription>
                    Внешние сервисы и API, интегрированные в платформу
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-2">ИИ сервисы и API</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>
                          <strong>Perplexity API</strong> - Используется для анализа кода, генерации интерфейсов и улучшения кода.
                          Основная модель: llama-3.1-sonar-small-128k-online.
                        </li>
                        <li>
                          <strong>Anthropic API (Claude)</strong> - Применяется для анализа изображений, генерации презентаций и документов.
                          Основная модель: claude-3-7-sonnet-20250219.
                        </li>
                        <li>
                          <strong>OpenAI API</strong> - Используется для генерации контента и анализа данных.
                          Основная модель: gpt-4o.
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">Авторизация и данные</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>
                          <strong>Firebase</strong> - Обеспечивает авторизацию с поддержкой Google Sign-In.
                        </li>
                        <li>
                          <strong>PostgreSQL</strong> - База данных для хранения пользовательских данных, проектов и результатов.
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">Платежи и подписки</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>
                          <strong>Stripe API</strong> - Обеспечивает функциональность подписок и платежей.
                          Поддерживает региональную адаптацию цен.
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-2">Мессенджеры и социальные сети</h3>
                      <ul className="list-disc pl-6 space-y-2">
                        <li>
                          <strong>Telegram Bot API</strong> - Интеграция с Telegram для доступа к функциям через бота.
                        </li>
                        <li>
                          <strong>Социальные сети</strong> - Интеграция с Facebook, Twitter, Instagram и LinkedIn.
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {!isExpanded && (
            <div className="text-center mt-8">
              <Button
                variant="outline"
                onClick={() => setIsExpanded(true)}
                className="flex items-center"
              >
                <ChevronDown className="mr-2 h-4 w-4" />
                Показать полную документацию
              </Button>
            </div>
          )}

          {isExpanded && (
            <div className="space-y-8 mt-8">
              <Card>
                <CardHeader>
                  <div className="flex items-center mb-2">
                    <Users className="h-6 w-6 text-blue-500 mr-2" />
                    <CardTitle>Целевая аудитория</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>
                      <strong>Разработчики</strong> - Создание и тестирование интерфейсов, генерация фронтенда на основе бэкенда, анализ и улучшение кода.
                    </li>
                    <li>
                      <strong>Дизайнеры</strong> - Создание макетов, прототипов и визуализаций на основе текстовых запросов.
                    </li>
                    <li>
                      <strong>Продуктовые менеджеры</strong> - Быстрое прототипирование, создание презентаций и документации.
                    </li>
                    <li>
                      <strong>Маркетологи</strong> - Генерация медиаконтента, управление социальными сетями, создание презентаций.
                    </li>
                    <li>
                      <strong>Образовательные учреждения</strong> - Моделирование сценариев, создание обучающих материалов и визуализаций.
                    </li>
                    <li>
                      <strong>Архитекторы и инженеры</strong> - Создание чертежей и 3D-моделей на основе текстовых описаний.
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center mb-2">
                    <FileText className="h-6 w-6 text-blue-500 mr-2" />
                    <CardTitle>Лицензирование и права</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="prose prose-sm max-w-none dark:prose-invert">
                  <p>
                    <strong>MassaganAI</strong> является проприетарным программным обеспечением.
                    Все права на платформу, исходный код, дизайн и функциональность принадлежат
                    Dauirzhan Abdulmazhit, 2025.
                  </p>
                  <p>
                    Система доступна по модели подписки с различными тарифными планами.
                    Использование системы регулируется Условиями использования и Политикой конфиденциальности.
                  </p>
                  <p>
                    Контент, созданный с использованием платформы, принадлежит пользователям в соответствии
                    с выбранным тарифным планом и условиями лицензии.
                  </p>
                </CardContent>
              </Card>

              <div className="text-center mt-8">
                <Button
                  variant="outline"
                  onClick={() => setIsExpanded(false)}
                  className="flex items-center"
                >
                  <ChevronUp className="mr-2 h-4 w-4" />
                  Свернуть документацию
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default DocumentationSection;