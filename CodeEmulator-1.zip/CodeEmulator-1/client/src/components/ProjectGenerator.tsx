import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Code2, FileCode, Server, Github, Archive } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface ProjectGeneratorProps {
  onApplyCode: (code: { 
    backend: Array<{name: string, path: string, code: string}>,
    frontend: Array<{name: string, path: string, code: string}>
  }) => void;
}

export default function ProjectGenerator({ onApplyCode }: ProjectGeneratorProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isImportLoading, setIsImportLoading] = useState(false);
  const [projectDescription, setProjectDescription] = useState("");
  const [generatedProject, setGeneratedProject] = useState<any>(null);
  const [activeTab, setActiveTab] = useState("description");
  const [githubUrl, setGithubUrl] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();

  const handleGenerateProject = async () => {
    if (isLoading) return;
    if (!projectDescription.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите описание проекта",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    setGeneratedProject(null);
    
    try {
      const response = await fetch("/api/ai/generate-project", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          description: projectDescription,
        }),
      });

      if (!response.ok) {
        throw new Error("Ошибка при генерации проекта");
      }

      const data = await response.json();
      setGeneratedProject(data);
      
      toast({
        title: "Проект сгенерирован",
        description: "ИИ успешно сгенерировал проект по вашему описанию",
      });
      
      // Автоматически переключаемся на вкладку с результатом
      setActiveTab("result");
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось сгенерировать проект",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyGeneratedCode = () => {
    if (!generatedProject) return;
    
    // Объединяем маршруты, модели и сервер в массив бэкенд-файлов
    const backendFiles = [
      ...(generatedProject.backend.routes || []),
      ...(generatedProject.backend.models || []),
      generatedProject.backend.server ? [generatedProject.backend.server] : []
    ];
    
    // Объединяем компоненты и страницы в массив фронтенд-файлов
    const frontendFiles = [
      ...(generatedProject.frontend.components || []),
      ...(generatedProject.frontend.pages || []),
    ];
    
    onApplyCode({
      backend: backendFiles,
      frontend: frontendFiles
    });
    
    toast({
      title: "Код применен",
      description: "Сгенерированный проект был успешно применен",
    });
  };
  
  // Импорт из GitHub
  const handleGithubImport = async () => {
    if (isImportLoading || !githubUrl.trim()) return;
    
    setIsImportLoading(true);
    
    try {
      const response = await fetch("/api/import/github", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: githubUrl,
        }),
      });

      if (!response.ok) {
        throw new Error("Ошибка при импорте из GitHub");
      }

      const data = await response.json();
      
      if (data.jsCode) {
        // Используем код из GitHub репозитория как описание проекта
        const projectInfo = `Проанализируйте и улучшите следующий код JavaScript:\n\n${data.jsCode}`;
        setProjectDescription(projectInfo);
        toast({
          title: "Код импортирован",
          description: "Код успешно импортирован из GitHub и добавлен в описание проекта",
        });
      } else {
        toast({
          title: "Предупреждение",
          description: "Не найден JavaScript код в репозитории. Попробуйте другой репозиторий.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось импортировать код из GitHub",
        variant: "destructive",
      });
    } finally {
      setIsImportLoading(false);
    }
  };
  
  // Импорт из ZIP-файла
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      
      if (file.type !== "application/zip" && !file.name.endsWith(".zip")) {
        toast({
          title: "Ошибка",
          description: "Пожалуйста, выберите файл в формате ZIP",
          variant: "destructive",
        });
        return;
      }
      
      const formData = new FormData();
      formData.append("zipfile", file);
      
      setIsImportLoading(true);
      
      fetch("/api/import/zip", {
        method: "POST",
        body: formData,
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Ошибка при импорте из ZIP-файла");
          }
          return response.json();
        })
        .then((data) => {
          if (data.jsCode) {
            // Используем код из ZIP-файла как описание проекта
            const projectInfo = `Проанализируйте и создайте проект на основе следующего кода:\n\n${data.jsCode}`;
            setProjectDescription(projectInfo);
            toast({
              title: "Код импортирован",
              description: "Код успешно импортирован из ZIP-файла и добавлен в описание проекта",
            });
          } else {
            toast({
              title: "Предупреждение", 
              description: "Не найден JavaScript код в ZIP-файле",
              variant: "destructive",
            });
          }
        })
        .catch((error) => {
          toast({
            title: "Ошибка",
            description: error instanceof Error ? error.message : "Не удалось импортировать код из ZIP-файла",
            variant: "destructive",
          });
        })
        .finally(() => {
          setIsImportLoading(false);
          // Сбрасываем input, чтобы можно было загрузить тот же файл повторно
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }
        });
    }
  };

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <div className="bg-gray-50 p-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-medium">Генератор проектов</h3>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="border-b">
          <TabsList className="h-10 bg-gray-50 w-full justify-start rounded-none">
            <TabsTrigger
              value="description"
              className="data-[state=active]:bg-white rounded-none border-r"
            >
              Описание проекта
            </TabsTrigger>
            <TabsTrigger
              value="result"
              className="data-[state=active]:bg-white rounded-none"
            >
              Результат
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="description" className="p-4">
          <div className="space-y-4">
            <div className="flex gap-2 mb-4">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-1/2">
                    <Github className="mr-2 h-4 w-4" />
                    Импорт из GitHub
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Импорт кода из GitHub</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <p className="text-sm text-gray-600">
                      Введите URL GitHub репозитория с кодом проекта
                    </p>
                    <Input 
                      placeholder="https://github.com/username/repo"
                      value={githubUrl}
                      onChange={(e) => setGithubUrl(e.target.value)}
                    />
                    <Button 
                      onClick={handleGithubImport}
                      disabled={isImportLoading || !githubUrl.trim()}
                      className="w-full"
                    >
                      {isImportLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Импорт...
                        </>
                      ) : (
                        <>
                          <Github className="mr-2 h-4 w-4" />
                          Импортировать
                        </>
                      )}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button
                variant="outline"
                className="w-1/2"
                onClick={() => fileInputRef.current?.click()}
                disabled={isImportLoading}
              >
                {isImportLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Импорт...
                  </>
                ) : (
                  <>
                    <Archive className="mr-2 h-4 w-4" />
                    Импорт из ZIP
                  </>
                )}
              </Button>
              
              <input 
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept=".zip"
                onChange={handleFileUpload}
              />
            </div>
          
            <p className="text-gray-700">
              Опишите проект, который вы хотите создать. ИИ сгенерирует полный проект с фронтендом и бэкендом, включая все необходимые файлы и интеграции.
            </p>
            
            <Textarea 
              placeholder="Опишите ваш проект... Например: 'Создайте веб-сайт для онлайн-магазина одежды с каталогом товаров, корзиной, оформлением заказа и административной панелью.'"
              value={projectDescription}
              onChange={(e) => setProjectDescription(e.target.value)}
              rows={10}
              className="resize-none"
            />

            <Button 
              onClick={handleGenerateProject} 
              disabled={isLoading || !projectDescription.trim()}
              className="bg-blue-600 hover:bg-blue-700 w-full"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Генерация проекта...
                </>
              ) : (
                <>
                  <FileCode className="mr-2 h-4 w-4" />
                  Сгенерировать проект
                </>
              )}
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="result" className="min-h-[400px]">
          {generatedProject ? (
            <div className="h-full">
              <div className="p-4">
                <h4 className="font-medium text-lg mb-2">Анализ и план проекта</h4>
                <p className="text-gray-700 mb-4">{generatedProject.analysis}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Server className="h-5 w-5 mr-2 text-blue-600" />
                      <h5 className="font-medium">Backend</h5>
                    </div>
                    <ul className="list-disc pl-5 space-y-1">
                      {generatedProject.backend.server && (
                        <li>Сервер: {generatedProject.backend.server.name}</li>
                      )}
                      <li>Маршруты: {generatedProject.backend.routes?.length || 0}</li>
                      <li>Модели: {generatedProject.backend.models?.length || 0}</li>
                    </ul>
                  </div>
                  
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center mb-2">
                      <Code2 className="h-5 w-5 mr-2 text-green-600" />
                      <h5 className="font-medium">Frontend</h5>
                    </div>
                    <ul className="list-disc pl-5 space-y-1">
                      <li>Компоненты: {generatedProject.frontend.components?.length || 0}</li>
                      <li>Страницы: {generatedProject.frontend.pages?.length || 0}</li>
                      <li>Стили: {generatedProject.frontend.styles ? "Настроены" : "Не настроены"}</li>
                    </ul>
                  </div>
                </div>
                
                <Button 
                  onClick={handleApplyGeneratedCode}
                  className="bg-green-600 hover:bg-green-700 mt-4"
                >
                  <FileCode className="mr-2 h-4 w-4" />
                  Применить сгенерированный проект
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center p-8">
              <FileCode className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium mb-2">Проект не сгенерирован</h3>
              <p className="text-gray-500 mb-4">
                Опишите ваш проект и нажмите "Сгенерировать проект" для создания полноценного веб-приложения.
              </p>
              <Button 
                onClick={() => setActiveTab("description")}
                variant="outline"
              >
                Перейти к описанию проекта
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}