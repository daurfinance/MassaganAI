import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Wand2, Eye, Code2, Sparkles, Bot } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import CodePreview from "./CodePreview";
import { DeviceType } from "./ViewportSelector";
import AIEmulator from "./AIEmulator";
import FrontendGenerator from "./FrontendGenerator";
import ProjectGenerator from "./ProjectGenerator";

interface AIToolsProps {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  onApplyGeneratedCode: (html: string, css: string, js: string) => void;
  onApplyProjectCode: (files: any) => void;
}

export default function AITools({
  htmlCode,
  cssCode,
  jsCode,
  onApplyGeneratedCode,
  onApplyProjectCode
}: AIToolsProps) {
  const [activeTab, setActiveTab] = useState<string>("emulator");
  const { toast } = useToast();
  
  // Обработка генерации фронтенда
  const handleApplyFrontendCode = (code: { 
    components: Array<{name: string, path: string, code: string}>,
    pages: Array<{name: string, path: string, code: string}>
  }) => {
    onApplyProjectCode({
      frontend: {
        components: code.components,
        pages: code.pages
      },
      backend: {
        routes: [],
        models: [],
        server: null
      }
    });
    
    toast({
      title: "Фронтенд применен",
      description: "Сгенерированный фронтенд был успешно применен",
    });
  };
  
  // Обработка генерации полного проекта
  const handleApplyProjectCode = (code: { 
    backend: Array<{name: string, path: string, code: string}>,
    frontend: Array<{name: string, path: string, code: string}>
  }) => {
    onApplyProjectCode({
      frontend: {
        components: code.frontend.filter(f => f.path.includes('/components/')),
        pages: code.frontend.filter(f => f.path.includes('/pages/'))
      },
      backend: {
        routes: code.backend.filter(f => f.path.includes('/routes/')),
        models: code.backend.filter(f => f.path.includes('/models/')),
        server: code.backend.find(f => f.path.includes('/index.ts'))
      }
    });
    
    toast({
      title: "Проект применен",
      description: "Сгенерированный проект был успешно применен",
    });
  };

  return (
    <div>
      <div className="p-4 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white flex justify-between items-center">
        <div className="flex items-center">
          <Sparkles className="h-6 w-6 mr-2" />
          <h2 className="text-xl font-bold">ИИ Инструменты</h2>
        </div>
      </div>
      
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3 h-14 bg-gray-100">
          <TabsTrigger 
            value="emulator" 
            className="flex flex-col items-center justify-center py-2 data-[state=active]:bg-white"
          >
            <Bot className="h-5 w-5 mb-1" />
            <span className="text-xs">ИИ Эмулятор</span>
          </TabsTrigger>
          <TabsTrigger 
            value="frontend" 
            className="flex flex-col items-center justify-center py-2 data-[state=active]:bg-white"
          >
            <Code2 className="h-5 w-5 mb-1" />
            <span className="text-xs">Генератор фронтенда</span>
          </TabsTrigger>
          <TabsTrigger 
            value="project" 
            className="flex flex-col items-center justify-center py-2 data-[state=active]:bg-white"
          >
            <Wand2 className="h-5 w-5 mb-1" />
            <span className="text-xs">Генератор проектов</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="emulator" className="p-0 border-none outline-none">
          <AIEmulator
            htmlCode={htmlCode}
            cssCode={cssCode}
            jsCode={jsCode}
            onApplyGeneratedCode={onApplyGeneratedCode}
          />
        </TabsContent>
        
        <TabsContent value="frontend" className="p-0 border-none outline-none">
          <FrontendGenerator onApplyCode={handleApplyFrontendCode} />
        </TabsContent>
        
        <TabsContent value="project" className="p-0 border-none outline-none">
          <ProjectGenerator onApplyCode={handleApplyProjectCode} />
        </TabsContent>
      </Tabs>
    </div>
  );
}