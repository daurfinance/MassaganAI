import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EditorState, Extension } from "@codemirror/state";
import { EditorView, keymap, lineNumbers, highlightActiveLine } from "@codemirror/view";
import { defaultKeymap, history, historyKeymap } from "@codemirror/commands";
import { syntaxHighlighting, defaultHighlightStyle, bracketMatching, indentOnInput } from "@codemirror/language";
import { html } from "@codemirror/lang-html";
import { css } from "@codemirror/lang-css";
import { javascript } from "@codemirror/lang-javascript";

interface CodeEditorProps {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  onCodeChange: (type: "html" | "css" | "js", code: string) => void;
}

export default function CodeEditor({ htmlCode, cssCode, jsCode, onCodeChange }: CodeEditorProps) {
  const htmlEditorRef = useRef<HTMLDivElement>(null);
  const cssEditorRef = useRef<HTMLDivElement>(null);
  const jsEditorRef = useRef<HTMLDivElement>(null);
  
  const [htmlView, setHtmlView] = useState<EditorView | null>(null);
  const [cssView, setCssView] = useState<EditorView | null>(null);
  const [jsView, setJsView] = useState<EditorView | null>(null);

  // Common editor extensions
  const getExtensions = (language: Extension, onChange: (value: string) => void): Extension[] => [
    lineNumbers(),
    highlightActiveLine(),
    history(),
    keymap.of([...defaultKeymap, ...historyKeymap]),
    syntaxHighlighting(defaultHighlightStyle),
    bracketMatching(),
    indentOnInput(),
    language,
    EditorView.updateListener.of(update => {
      if (update.changes) {
        onChange(update.state.doc.toString());
      }
    })
  ];

  // Setup HTML editor
  useEffect(() => {
    if (htmlEditorRef.current && !htmlView) {
      const startState = EditorState.create({
        doc: htmlCode,
        extensions: getExtensions(html(), (value) => onCodeChange("html", value))
      });

      const view = new EditorView({
        state: startState,
        parent: htmlEditorRef.current
      });

      setHtmlView(view);
      return () => view.destroy();
    }
    return undefined;
  }, [htmlCode, onCodeChange, htmlView]);

  // Setup CSS editor
  useEffect(() => {
    if (cssEditorRef.current && !cssView) {
      const startState = EditorState.create({
        doc: cssCode,
        extensions: getExtensions(css(), (value) => onCodeChange("css", value))
      });

      const view = new EditorView({
        state: startState,
        parent: cssEditorRef.current
      });

      setCssView(view);
      return () => view.destroy();
    }
    return undefined;
  }, [cssCode, onCodeChange, cssView]);

  // Setup JavaScript editor
  useEffect(() => {
    if (jsEditorRef.current && !jsView) {
      const startState = EditorState.create({
        doc: jsCode,
        extensions: getExtensions(javascript(), (value) => onCodeChange("js", value))
      });

      const view = new EditorView({
        state: startState,
        parent: jsEditorRef.current
      });

      setJsView(view);
      return () => view.destroy();
    }
    return undefined;
  }, [jsCode, onCodeChange, jsView]);

  // Update the editor content when props change
  useEffect(() => {
    if (htmlView && htmlView.state.doc.toString() !== htmlCode) {
      htmlView.dispatch({
        changes: {
          from: 0,
          to: htmlView.state.doc.length,
          insert: htmlCode
        }
      });
    }
    if (cssView && cssView.state.doc.toString() !== cssCode) {
      cssView.dispatch({
        changes: {
          from: 0,
          to: cssView.state.doc.length,
          insert: cssCode
        }
      });
    }
    if (jsView && jsView.state.doc.toString() !== jsCode) {
      jsView.dispatch({
        changes: {
          from: 0,
          to: jsView.state.doc.length,
          insert: jsCode
        }
      });
    }
  }, [htmlCode, cssCode, jsCode, htmlView, cssView, jsView]);

  return (
    <Card className="border-0 rounded-none h-full flex flex-col overflow-hidden">
      <Tabs defaultValue="html" className="h-full flex flex-col">
        <div className="bg-gray-100 border-b border-gray-200 px-4">
          <TabsList className="h-10">
            <TabsTrigger value="html" className="text-sm font-medium">HTML</TabsTrigger>
            <TabsTrigger value="css" className="text-sm font-medium">CSS</TabsTrigger>
            <TabsTrigger value="js" className="text-sm font-medium">JavaScript</TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="html" className="flex-1 m-0 p-0 h-full overflow-auto data-[state=active]:flex">
          <div ref={htmlEditorRef} className="w-full h-full" />
        </TabsContent>
        
        <TabsContent value="css" className="flex-1 m-0 p-0 h-full overflow-auto data-[state=active]:flex">
          <div ref={cssEditorRef} className="w-full h-full" />
        </TabsContent>
        
        <TabsContent value="js" className="flex-1 m-0 p-0 h-full overflow-auto data-[state=active]:flex">
          <div ref={jsEditorRef} className="w-full h-full" />
        </TabsContent>
      </Tabs>
    </Card>
  );
}
