import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";

interface ConsoleOutputProps {
  messages: string[];
  onClear: () => void;
}

export default function ConsoleOutput({ messages, onClear }: ConsoleOutputProps) {
  const getMessageClass = (message: string) => {
    if (message.includes("[error]")) return "text-red-500";
    if (message.includes("[warn]")) return "text-yellow-500";
    if (message.includes("[info]")) return "text-blue-500";
    return "text-gray-800";
  };

  return (
    <div className="border-t border-gray-200 bg-gray-50 p-2">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs font-medium text-gray-700">Консоль</span>
        <Button variant="ghost" size="sm" onClick={onClear} className="h-6 p-1">
          <Trash2 className="h-3.5 w-3.5" />
          <span className="ml-1 text-xs">Очистить</span>
        </Button>
      </div>
      <div className="bg-white border border-gray-200 rounded h-24 overflow-y-auto p-2 text-xs font-mono">
        {messages.length === 0 ? (
          <div className="text-gray-400 italic">Консоль пуста</div>
        ) : (
          messages.map((message, index) => (
            <div key={index} className={getMessageClass(message)}>
              {message}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
