import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, Code, Monitor, Edit, Bug, GitBranch, FileIcon, Upload, Github, Cpu, BrainCircuit, Lightbulb, Zap, PenTool, LogIn, UserPlus, User } from "lucide-react";
import ImportFromGithub from "./ImportFromGithub";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/lib/LanguageContext";
import CyberHorseLogoAnimation from "./CyberHorseLogoAnimation";

interface WelcomeScreenProps {
  onUpload: () => void;
  onDrop: (files: FileList) => void;
  onImportCode?: (htmlCode: string, cssCode: string, jsCode: string) => void;
}

export default function WelcomeScreen({ onUpload, onDrop, onImportCode }: WelcomeScreenProps) {
  const { language, t } = useLanguage();
  const [isLoaded, setIsLoaded] = useState(false);
  const [animatedText, setAnimatedText] = useState("");
  const [typingComplete, setTypingComplete] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const textToType = t("app.slogan");
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Эффект для появления страницы
  useEffect(() => {
    setIsLoaded(true);
  }, []);
  
  // Эффект для сброса анимации при изменении языка
  useEffect(() => {
    // При изменении языка сбрасываем анимацию
    setAnimatedText("");
    setTypingComplete(false);
  }, [language]);
  
  // Эффект для анимации печатания
  useEffect(() => {
    if (animatedText.length < textToType.length) {
      const timeout = setTimeout(() => {
        setAnimatedText(textToType.substring(0, animatedText.length + 1));
      }, 100);
      return () => clearTimeout(timeout);
    } else {
      setTypingComplete(true);
    }
  }, [animatedText, textToType]);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.classList.add("border-primary", "bg-primary/10");
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.classList.remove("border-primary", "bg-primary/10");
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.classList.remove("border-primary", "bg-primary/10");
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onDrop(e.dataTransfer.files);
    }
  };
  
  // Функция для демо-входа без регистрации
  const handleDemoAccess = () => {
    setIsLoading(true);
    
    // Имитируем запрос к серверу
    setTimeout(() => {
      // Создаем фиктивного пользователя в локальном хранилище
      localStorage.setItem("demoUser", JSON.stringify({
        uid: "demo-user-id",
        email: "daurfinance@gmail.com",
        displayName: "Демо Пользователь",
        isDemo: true
      }));
      
      toast({
        title: "Успешный вход",
        description: "Вы вошли с использованием демо-аккаунта",
      });
      
      // Перезагружаем страницу, чтобы обновить состояние авторизации
      window.location.reload();
      
      setIsLoading(false);
    }, 1000);
  };

  // Определяем направление текста на основе языка (для арабского языка)
  const textDirection = language === 'ar' ? 'rtl' : 'ltr';

  return (
    <div 
      className={`flex flex-col items-center justify-center min-h-[calc(100vh-57px)] bg-gradient-to-b from-indigo-50 to-white py-10 px-4 transition-opacity duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
      dir={textDirection}
    >
      <div className="w-full max-w-5xl text-center">
        <div className="flex flex-col items-center mb-8 animate-slideInUp">
          {/* Новый анимированный логотип снежного барса в казахской национальной одежде на киборг-лошади */}
          <div className="relative mb-6 max-w-2xl w-full mx-auto">
            <div className="flex justify-center items-center web3-card p-4 rounded-3xl platinum-glow overflow-visible">
              <CyberHorseLogoAnimation size={300} />
            </div>
          </div>
          
          {/* Название с luxury анимированным градиентом */}
          <h1 className="text-5xl md:text-7xl font-bold mb-3 bg-clip-text text-transparent bg-gradient-to-r from-gray-300 via-platinum to-gold animate-gradient-shift mobile-text-xl">
            {t("app.name")}
          </h1>
          <p className="text-xs text-gray-400 mt-0 mb-2">© 2025 Dauirzhan Abdulmazhit. All rights reserved.</p>
          
          {/* Печатаемый подзаголовок */}
          <div className="h-8 mb-2">
            <p className="text-xl text-gray-600 relative">
              {animatedText}
              <span className={`absolute inline-block h-5 w-0.5 ml-1 bg-gray-500 ${typingComplete ? 'animate-blink' : ''}`}></span>
            </p>
          </div>
          
          {/* Эмоциональная подпись */}
          <p className="text-gray-500 mt-4 mb-6 max-w-2xl opacity-90">
            {t("app.description")}
          </p>
          
          {/* Кнопки аутентификации */}
          <div className="flex flex-wrap gap-3 justify-center mb-8">
            <Button
              onClick={() => setLocation("/auth")}
              variant="default"
              size="lg"
              className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 px-6 btn-hover-effect"
            >
              <UserPlus size={18} className="animate-bounce-slow" style={{ animationDelay: "0.5s" }} />
              <span>{t("auth.register")}</span>
            </Button>
            
            <Button
              onClick={() => setLocation("/auth")}
              variant="outline"
              size="lg"
              className="flex items-center gap-2 px-6 btn-hover-effect"
            >
              <LogIn size={18} />
              <span>{t("auth.login")}</span>
            </Button>
            
            <Button
              onClick={handleDemoAccess}
              variant="secondary"
              size="lg"
              className="flex items-center gap-2 px-6 btn-hover-effect"
              disabled={isLoading}
            >
              <span className="flex items-center">
                {isLoading ? (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-purple-700 border-t-transparent mr-2"></span>
                ) : (
                  <span className="mr-2 bg-gradient-to-r from-indigo-400 to-purple-500 p-1 rounded-full">
                    <User className="h-3.5 w-3.5 text-white" />
                  </span>
                )}
                {t("auth.demo")}
              </span>
            </Button>
          </div>
        </div>
        
        {/* Карточка для загрузки с улучшенной анимацией */}
        <div 
          className="mb-10 p-8 border-2 border-dashed border-indigo-300 rounded-2xl bg-white hover:border-indigo-500 transition-all duration-300 cursor-pointer shadow-md hover:shadow-xl transform hover:-translate-y-1 group mobile-p-4"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={onUpload}
        >
          <div className="flex flex-col items-center">
            <div className="text-indigo-400 group-hover:text-indigo-600 transition-colors duration-300 mb-4 relative animate-float">
              <div className="absolute inset-0 -m-4 bg-indigo-100 rounded-full opacity-0 group-hover:opacity-50 scale-0 group-hover:scale-100 transition-all duration-300"></div>
              <Upload size={48} className="relative z-10" />
            </div>
            <p className="text-base text-indigo-600 font-medium mb-2 group-hover:scale-105 transition-transform duration-300">
              {t("welcome.upload.text")}
            </p>
            <p className="text-sm text-gray-400 mb-4">
              {t("welcome.upload.or")}
            </p>
            <Button 
              className="group-hover:bg-indigo-700 transition-colors duration-300 flex items-center gap-2 px-5 py-2 btn-hover-effect"
              variant="default"
              size="lg"
            >
              <FileIcon size={18} />
              <span>{t("welcome.upload.choose")}</span>
            </Button>
          </div>
        </div>
        
        {/* Импорт из GitHub с новым дизайном */}
        {onImportCode && (
          <div className="mb-12 flex justify-center">
            <div className="relative overflow-hidden rounded-xl animate-slideInUp" style={{ animationDelay: "0.2s" }}>
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-pink-600 opacity-50 blur animate-pulse-slow"></div>
              <ImportFromGithub onImportCode={onImportCode} />
            </div>
          </div>
        )}
        
        {/* Казахстанское ИИ решение - промо секция */}
        <div className="mb-12 p-8 rounded-2xl web3-card platinum-glow animate-slideInUp" style={{ animationDelay: "0.3s" }}>
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/3 mb-6 md:mb-0 md:pr-8">
              <img 
                src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjMwMCIgdmlld0JveD0iMCAwIDMwMCAzMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3Qgd2lkdGg9IjMwMCIgaGVpZ2h0PSIzMDAiIGZpbGw9IiMwMDU5QkQiLz4KICA8cGF0aCBkPSJNMTUwIDUwQzgwIDUwIDI1IDEwNSAyNSAxNzVDMjUgMjQ1IDgwIDMwMCAxNTAgMzAwQzIyMCAzMDAgMjc1IDI0NSAyNzUgMTc1QzI3NSAxMDUgMjIwIDUwIDE1MCA1MFoiIGZpbGw9IiNGREQ4MzUiLz4KICA8cGF0aCBkPSJNMTUwIDc1QzkzLjEgNzUgNDcgMTIxLjEgNDcgMTc4QzQ3IDIzNC45IDkzLjEgMjgxIDE1MCAyODFDMjA2LjkgMjgxIDI1MyAyMzQuOSAyNTMgMTc4QzI1MyAxMjEuMSAyMDYuOSA3NSAxNTAgNzVaIiBmaWxsPSIjMDA1OUJEIi8+CiAgPHBhdGggZD0iTTE1MCA5MkMxMDIuNCA5MiA2NCAxMzAuNCA2NCAxNzhDNjQgMjI1LjYgMTAyLjQgMjY0IDE1MCAyNjRDMTk3LjYgMjY0IDIzNiAyMjUuNiAyMzYgMTc4QzIzNiAxMzAuNCAxOTcuNiA5MiAxNTAgOTJaIiBmaWxsPSIjRkRENjAwIi8+CiAgPHBhdGggZD0iTTE1MiAxMjdDMTUyIDEyNyAxNDQgMTYyIDE0NCAxNjlDMTQ0IDE3NiAxNTEgMTkyIDE1MiAxOTlDMTUzIDIwNiAxNDUgMjIwIDE0OCAyMjVDMTUxIDIzMCAxNzAgMjI0IDE3MCAyMTlDMTcwIDIxNCAxNTkgMjAzIDE1OCAyMDFDMTU3IDE5OSAxNjQgMTkzIDE2NiAxODlDMTY4IDE4NSAxNjYgMTgzIDE2NiAxODNDMTY2IDE4MyAxODUgMTk0IDE5MCAxOTdDMTk1IDIwMCAxOTggMjA1IDIwMCAyMDVDMjAyIDIwNSAxOTkgMjExIDE5NyAyMTVDMTk1IDIxOSAxODggMjIzIDE4OCAyMjdDMTg4IDIzMSAyMTAgMjI5IDIxMyAyMjVDMjE2IDIyMSAyMTMgMjExIDIxMCAyMDlDMjA3IDIwNyAyMDYgMjAwIDIwNiAxOTdDMjA2IDE5NCAyMDkgMTk0IDIwOSAxOTFDMjA5IDE4OCAyMDAgMTc3IDIwMCAxNzRDMjAwIDE3MSAyMDQgMTY3IDIwNCAxNjdMMTkzIDE1OUMxOTMgMTU5IDE5NiAxNTMgMTk4IDE1MkMyMDAgMTUxIDIwNiAxNTAgMjA2IDE0N0MyMDYgMTQ0IDE5MyAxMzcgMTkwIDEzN0MxODcgMTM3IDE4MiAxNDAgMTgwIDE0M0MxNzggMTQ2IDE3NiAxNTMgMTc0IDE1NEMxNzIgMTU1IDE2NyAxNTQgMTY3IDE1NEMxNjcgMTU0IDE4MiAxNDEgMTgwIDEzOEMxNzggMTM1IDE3MiAxMzggMTY5IDEzN0MxNjYgMTM2IDE1OCAxMzEgMTU1IDEzMEMxNTIgMTI5IDE1MiAxMjcgMTUyIDEyN1oiIGZpbGw9IiMwMDU5QkQiLz4KPC9zdmc+Cg=="
                alt="Kazakhstan Flag with Digital Elements"
                className="w-48 h-48 object-contain mb-4 rounded-2xl platinum-glow"
              />
            </div>
            <div className="md:w-2/3 text-left">
              <h3 className="text-3xl font-bold mb-4 text-gradient-platinum">Универсальное Казахстанское ИИ Решение</h3>
              <p className="text-gray-300 mb-4">MassaganAI - первое казахстанское универсальное искусственное интеллектуальное решение, разработанное для всех сфер бизнеса и повседневной жизни.</p>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="web3-border p-3 rounded platinum-glow">
                  <h4 className="font-bold text-platinum mb-1">Местная экспертиза</h4>
                  <p className="text-sm text-gray-400">Специализированные знания о казахстанском рынке и культуре</p>
                </div>
                <div className="web3-border p-3 rounded platinum-glow">
                  <h4 className="font-bold text-platinum mb-1">Многоязычная поддержка</h4>
                  <p className="text-sm text-gray-400">Казахский, русский, английский и другие региональные языки</p>
                </div>
                <div className="web3-border p-3 rounded platinum-glow">
                  <h4 className="font-bold text-platinum mb-1">Web и Telegram</h4>
                  <p className="text-sm text-gray-400">Доступ через веб-интерфейс и Telegram бота</p>
                </div>
                <div className="web3-border p-3 rounded platinum-glow">
                  <h4 className="font-bold text-platinum mb-1">Web3 готовый</h4>
                  <p className="text-sm text-gray-400">Интеграция с блокчейн и поддержка смарт-контрактов</p>
                </div>
              </div>
              <p className="text-gray-400 text-sm">Разработано и обслуживается в Казахстане для обеспечения высочайшего уровня локализации и соответствия местным требованиям.</p>
            </div>
          </div>
        </div>
        
        {/* Информация о Telegram боте */}
        <div className="mb-12 p-8 rounded-2xl web3-glass gold-glow animate-slideInUp" style={{ animationDelay: "0.4s" }}>
          <div className="flex flex-col items-center">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-blue-700 mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"></path>
              </svg>
            </div>
            <h3 className="text-2xl font-bold mb-4 text-gradient-gold">MassaganAI Telegram Бот</h3>
            <p className="text-gray-300 mb-6 max-w-2xl text-center">Общайтесь с MassaganAI через нашего Telegram бота для быстрого доступа к искусственному интеллекту прямо в вашем любимом мессенджере.</p>
            <div className="flex flex-wrap gap-4 justify-center">
              <a 
                href="https://t.me/MassaganAIBot" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-700 text-white rounded-lg hover:from-blue-600 hover:to-blue-800 transition-all duration-300 web3-shadow"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"></path>
                </svg>
                <span>Перейти к боту</span>
              </a>
              <button className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-gray-600 to-gray-800 text-white rounded-lg hover:from-gray-700 hover:to-gray-900 transition-all duration-300 web3-shadow">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10"></circle>
                  <line x1="12" y1="16" x2="12" y2="12"></line>
                  <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
                <span>Подробнее</span>
              </button>
            </div>
          </div>
        </div>
        
        {/* Карточки функций с улучшенными анимациями */}
        <h2 className="text-2xl font-bold mb-8 text-gradient-platinum animate-gradient-shift mobile-text-lg">
          {t("welcome.features")}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mobile-stack">
          <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border-0 hover:-translate-y-2 group animate-slideInUp" style={{ animationDelay: "0.1s" }}>
            <div className="absolute h-1 w-full bg-gradient-to-r from-indigo-500 to-blue-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
            <CardContent className="p-6 pt-8">
              <div className="text-indigo-500 mb-4 group-hover:text-indigo-600 transition-colors duration-300 animate-float">
                <Monitor size={28} className="transform group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-lg">{t("welcome.multidevices.title")}</h3>
              <p className="text-gray-500">{t("welcome.multidevices.desc")}</p>
            </CardContent>
          </Card>
          
          <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border-0 hover:-translate-y-2 group animate-slideInUp" style={{ animationDelay: "0.2s" }}>
            <div className="absolute h-1 w-full bg-gradient-to-r from-purple-500 to-pink-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
            <CardContent className="p-6 pt-8">
              <div className="text-purple-500 mb-4 group-hover:text-purple-600 transition-colors duration-300 animate-float">
                <PenTool size={28} className="transform group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-lg">{t("welcome.editor.title")}</h3>
              <p className="text-gray-500">{t("welcome.editor.desc")}</p>
            </CardContent>
          </Card>
          
          <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border-0 hover:-translate-y-2 group animate-slideInUp" style={{ animationDelay: "0.3s" }}>
            <div className="absolute h-1 w-full bg-gradient-to-r from-pink-500 to-red-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
            <CardContent className="p-6 pt-8">
              <div className="text-pink-500 mb-4 group-hover:text-pink-600 transition-colors duration-300 animate-float">
                <Cpu size={28} className="transform group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-lg">{t("welcome.ai.title")}</h3>
              <p className="text-gray-500">{t("welcome.ai.desc")}</p>
            </CardContent>
          </Card>
          
          <Card className="overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 border-0 hover:-translate-y-2 group animate-slideInUp" style={{ animationDelay: "0.4s" }}>
            <div className="absolute h-1 w-full bg-gradient-to-r from-yellow-500 to-orange-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
            <CardContent className="p-6 pt-8">
              <div className="text-yellow-500 mb-4 group-hover:text-yellow-600 transition-colors duration-300 animate-float">
                <Zap size={28} className="transform group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="font-bold text-gray-800 mb-2 text-lg">{t("welcome.projects.title")}</h3>
              <p className="text-gray-500">{t("welcome.projects.desc")}</p>
            </CardContent>
          </Card>
        </div>
        
        {/* Секция подписки Stripe */}
        <div className="mb-12 p-8 rounded-2xl bg-gradient-to-r from-gray-900 to-gray-800 platinum-glow animate-slideInUp" style={{ animationDelay: "0.5s" }}>
          <h2 className="text-3xl font-bold mb-6 text-gradient-platinum text-center">Тарифные планы</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Бесплатный план */}
            <div className="p-6 rounded-xl web3-card hover:platinum-glow transition-all duration-300 transform hover:-translate-y-2">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-platinum">Базовый</h3>
                <span className="px-3 py-1 bg-gradient-to-r from-gray-800 to-gray-700 rounded-full text-xs font-medium text-gray-300">Бесплатно</span>
              </div>
              <div className="mb-4">
                <span className="text-3xl font-bold text-platinum">0₸</span>
                <span className="text-gray-400 text-sm">/месяц</span>
              </div>
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-300 text-sm">Базовое создание HTML/CSS/JS</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-300 text-sm">Эмулятор для Android и iPhone</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-400 text-sm line-through">Telegram бот интеграция</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-400 text-sm line-through">Видео обработка и озвучивание</p>
                </div>
              </div>
              <button className="w-full py-2 rounded-lg neomorphic-button text-platinum hover:text-white transition-colors">
                Текущий план
              </button>
            </div>

            {/* Стандартный план */}
            <div className="p-6 rounded-xl web3-card gold-glow transform hover:-translate-y-3 transition-all duration-300 relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-gold to-platinum-light rounded-full text-xs font-bold text-graphite">
                Популярный
              </div>
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-gold">Премиум</h3>
                <span className="px-3 py-1 bg-gradient-to-r from-gold to-platinum-light rounded-full text-xs font-medium text-graphite">Подписка</span>
              </div>
              <div className="mb-4">
                <span className="text-3xl font-bold text-gold">5000₸</span>
                <span className="text-gray-300 text-sm">/месяц</span>
              </div>
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gold" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-200 text-sm">Все функции базового плана</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gold" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-200 text-sm">Расширенные AI возможности</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gold" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-200 text-sm">Доступ к Telegram боту</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gold" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-200 text-sm">Базовая обработка видео</p>
                </div>
              </div>
              <button 
                className="w-full py-2 rounded-lg bg-gradient-to-r from-gold to-platinum-light text-graphite font-medium transition-all duration-300 hover:shadow-lg hover:from-gold hover:to-gold"
                onClick={() => window.location.href = '/subscribe'}
              >
                Подписаться
              </button>
            </div>

            {/* Бизнес план */}
            <div className="p-6 rounded-xl web3-card hover:platinum-glow transition-all duration-300 transform hover:-translate-y-2">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-platinum">Бизнес</h3>
                <span className="px-3 py-1 bg-gradient-to-r from-gray-800 to-gray-700 rounded-full text-xs font-medium text-gray-300">Корпоративный</span>
              </div>
              <div className="mb-4">
                <span className="text-3xl font-bold text-platinum">15000₸</span>
                <span className="text-gray-400 text-sm">/месяц</span>
              </div>
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-300 text-sm">Все функции премиум плана</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-300 text-sm">Белый лейбл решение</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-300 text-sm">Расширенная обработка видео</p>
                </div>
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-emerald" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <p className="ml-3 text-gray-300 text-sm">Персональная техподдержка</p>
                </div>
              </div>
              <button 
                className="w-full py-2 rounded-lg neomorphic-button text-platinum hover:text-white transition-colors"
                onClick={() => window.location.href = '/contact'}
              >
                Связаться
              </button>
            </div>
          </div>
        </div>
        
        {/* Улучшенный призыв к действию */}
        <div className="mt-16 bg-gradient-to-r from-gray-800 to-gray-900 rounded-2xl p-8 shadow-xl text-white text-center transform hover:scale-[1.02] transition-transform duration-300 animate-slideInUp mobile-p-4" style={{ animationDelay: "0.5s" }}>
          <Sparkles className="inline-block mb-4 h-10 w-10 animate-pulse-slow text-gold" />
          <h3 className="text-2xl font-bold mb-3 mobile-text-lg text-gradient-platinum">{t("welcome.ready")}</h3>
          <p className="opacity-90 mb-6 max-w-2xl mx-auto text-gray-300">
            {t("welcome.ready.desc")}
          </p>
          <Button 
            className="bg-gradient-to-r from-platinum to-platinum-light text-graphite hover:from-gold hover:to-platinum transition-all duration-300 px-8 py-3 text-lg btn-hover-effect font-medium"
            size="lg"
            onClick={onUpload}
          >
            {t("welcome.start")}
          </Button>
        </div>
      </div>
      
      {/* CSS для анимаций */}
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        
        @keyframes blink {
          0%, 100% { opacity: 0; }
          50% { opacity: 1; }
        }
        
        .animate-gradient {
          background-size: 200% auto;
          animation: gradient 4s ease infinite;
        }
        
        .animate-blink {
          animation: blink 1s step-end infinite;
        }
      `}} />
    </div>
  );
}
