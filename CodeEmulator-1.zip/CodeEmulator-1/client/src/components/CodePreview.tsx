import { useRef, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import ConsoleOutput from "./ConsoleOutput";
import { DeviceType } from "./ViewportSelector";

interface CodePreviewProps {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  viewportSize: DeviceType;
  showConsole?: boolean;
  consoleMessages?: string[];
  onClearConsole?: () => void;
}

export default function CodePreview({ 
  htmlCode, 
  cssCode, 
  jsCode, 
  viewportSize,
  showConsole = false,
  consoleMessages = [],
  onClearConsole = () => {}
}: CodePreviewProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (iframeRef.current) {
      const iframe = iframeRef.current;
      const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
      
      if (iframeDoc) {
        iframeDoc.open();
        iframeDoc.write(`
          ${htmlCode}
          <style>${cssCode}</style>
          <script>
            // Capture console messages for display in parent
            (function() {
              const originalConsoleLog = console.log;
              const originalConsoleError = console.error;
              const originalConsoleWarn = console.warn;
              const originalConsoleInfo = console.info;
              
              function postToParent(type, args) {
                window.parent.postMessage({
                  source: 'iframe-console',
                  type: type,
                  message: Array.from(args).map(arg => 
                    typeof arg === 'object' ? JSON.stringify(arg) : arg
                  ).join(' ')
                }, '*');
              }
              
              console.log = function() {
                postToParent('log', arguments);
                originalConsoleLog.apply(console, arguments);
              };
              
              console.error = function() {
                postToParent('error', arguments);
                originalConsoleError.apply(console, arguments);
              };
              
              console.warn = function() {
                postToParent('warn', arguments);
                originalConsoleWarn.apply(console, arguments);
              };
              
              console.info = function() {
                postToParent('info', arguments);
                originalConsoleInfo.apply(console, arguments);
              };
              
              window.onerror = function(message, source, lineno, colno, error) {
                postToParent('error', [\`\${message} at line \${lineno}:\${colno}\`]);
                return false;
              };
            })();
          </script>
          <script>${jsCode}</script>
        `);
        iframeDoc.close();
      }
    }
  }, [htmlCode, cssCode, jsCode]);

  const getDeviceStyle = () => {
    switch (viewportSize) {
      case "mobile-android":
        return { 
          containerClass: "android-device-container",
          frameWidth: "360px", 
          frameHeight: "640px",
          deviceFrame: true,
          deviceType: "android" 
        };
      case "mobile-iphone":
        return { 
          containerClass: "iphone-device-container",
          frameWidth: "375px", 
          frameHeight: "812px", 
          deviceFrame: true,
          deviceType: "iphone" 
        };
      case "tablet":
        return { 
          containerClass: "tablet-device-container",
          frameWidth: "768px", 
          frameHeight: "1024px", 
          deviceFrame: true,
          deviceType: "tablet" 
        };
      case "desktop-windows":
        return { 
          containerClass: "windows-device-container",
          frameWidth: "1280px", 
          frameHeight: "800px", 
          deviceFrame: true,
          deviceType: "windows" 
        };
      case "desktop-macos":
        return { 
          containerClass: "macos-device-container",
          frameWidth: "1280px", 
          frameHeight: "800px", 
          deviceFrame: true,
          deviceType: "macos" 
        };
      case "responsive":
      default:
        return { 
          containerClass: "",
          frameWidth: "100%", 
          frameHeight: "100%", 
          deviceFrame: false,
          deviceType: "responsive" 
        };
    }
  };

  const deviceStyle = getDeviceStyle();
  const centerContent = viewportSize !== "responsive";
  
  const renderDeviceFrame = () => {
    switch (deviceStyle.deviceType) {
      case "android":
        return (
          <div className="android-frame">
            <div className="android-screen">
              <iframe 
                ref={iframeRef}
                style={{ width: "100%", height: "100%", border: "none" }}
                title="Android Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
            <div className="android-home-button"></div>
          </div>
        );
      case "iphone":
        return (
          <div className="iphone-frame">
            <div className="iphone-notch"></div>
            <div className="iphone-screen">
              <iframe 
                ref={iframeRef}
                style={{ width: "100%", height: "100%", border: "none" }}
                title="iPhone Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
            <div className="iphone-home-indicator"></div>
          </div>
        );
      case "tablet":
        return (
          <div className="tablet-frame">
            <div className="tablet-screen">
              <iframe 
                ref={iframeRef}
                style={{ width: "100%", height: "100%", border: "none" }}
                title="Tablet Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
            <div className="tablet-home-button"></div>
          </div>
        );
      case "windows":
        return (
          <div className="windows-frame">
            <div className="windows-title-bar">
              <div className="windows-controls">
                <span className="windows-minimize"></span>
                <span className="windows-maximize"></span>
                <span className="windows-close"></span>
              </div>
            </div>
            <div className="windows-screen">
              <iframe 
                ref={iframeRef}
                style={{ width: "100%", height: "100%", border: "none" }}
                title="Windows Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          </div>
        );
      case "macos":
        return (
          <div className="macos-frame">
            <div className="macos-title-bar">
              <div className="macos-controls">
                <span className="macos-close"></span>
                <span className="macos-minimize"></span>
                <span className="macos-expand"></span>
              </div>
            </div>
            <div className="macos-screen">
              <iframe 
                ref={iframeRef}
                style={{ width: "100%", height: "100%", border: "none" }}
                title="macOS Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          </div>
        );
      case "responsive":
      default:
        return (
          <iframe 
            ref={iframeRef}
            style={{ 
              width: deviceStyle.frameWidth, 
              height: deviceStyle.frameHeight, 
              border: "none", 
              backgroundColor: "white" 
            }}
            title="Code Preview"
            sandbox="allow-scripts allow-same-origin"
          />
        );
    }
  };

  return (
    <Card className="border-0 rounded-none h-full flex flex-col overflow-hidden">
      <div className="h-full flex flex-col">
        <div className="bg-gray-100 border-b border-gray-200 p-2 flex items-center">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="mx-auto text-xs text-gray-500">Просмотр</div>
        </div>
        
        <div 
          ref={containerRef}
          className={`flex-1 overflow-auto p-4 ${centerContent ? 'flex justify-center items-center' : ''} ${deviceStyle.containerClass}`}
        >
          {renderDeviceFrame()}
        </div>
        
        {showConsole && (
          <ConsoleOutput messages={consoleMessages} onClear={onClearConsole} />
        )}
      </div>
    </Card>
  );
}