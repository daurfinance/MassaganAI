import { Button } from "@/components/ui/button";
import { BrainCircuit, Plus, Upload, Zap, Activity, Crown } from "lucide-react";
import ImportFromGithub from "./ImportFromGithub";
import { UserAuth } from "./UserAuth";
import LanguageSelector from "./LanguageSelector";
import { useLanguage } from "@/lib/LanguageContext";
import { Link } from "wouter";
import MassaganLogoWeb3 from "./MassaganLogoWeb3";

interface HeaderProps {
  onNewProject: () => void;
  onUploadCode: () => void;
  onImportCode?: (htmlCode: string, cssCode: string, jsCode: string) => void;
}

export default function Header({ onNewProject, onUploadCode, onImportCode }: HeaderProps) {
  const { language, t } = useLanguage();
  
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          {/* Новый анимированный логотип снежного барса в казахской национальной одежде на ракете */}
          <div className="mr-3 flex items-center">
            <div className="relative">
              <MassaganLogoWeb3 size={48} />
            </div>
          </div>
          
          <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 animate-gradient-shift">
            MassaganAI
          </h1>
          
          <div className="ml-3 hidden md:flex items-center space-x-2">
            <span className="text-xs px-2 py-1 bg-indigo-100 text-indigo-800 rounded-full font-medium">
              {t("header.motto")}
            </span>
            
            {/* Селектор языка */}
            <LanguageSelector onLanguageChange={(lang) => {}} />
          </div>
        </div>
        
        <div className="flex items-center space-x-2 md:space-x-4">
          {/* Компонент аутентификации пользователя */}
          <UserAuth />
          
          {/* На мобильных показываем селектор языка справа */}
          <div className="md:hidden">
            <LanguageSelector onLanguageChange={(lang) => {}} />
          </div>
          
          {/* Кнопка для перехода на страницу подписки */}
          <Button
            variant="outline"
            className="border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100 hover:text-amber-900 hidden md:flex"
            size="sm"
            asChild
          >
            <Link to="/subscribe" className="flex items-center">
              <Crown size={16} className="mr-2 text-amber-500" />
              <span>{t("header.subscribe") || "Подписка"}</span>
            </Link>
          </Button>
          
          {onImportCode && (
            <div className="hidden md:block">
              <ImportFromGithub onImportCode={onImportCode} />
            </div>
          )}
          
          <Button 
            variant="outline" 
            className="border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 hover:text-indigo-900 transition-all duration-200 btn-hover-effect"
            onClick={onNewProject}
            size="sm"
          >
            <Zap size={18} className="mr-1 md:mr-2" />
            <span className="hidden md:inline">{t("header.newProject")}</span>
            <span className="md:hidden">{t("header.newProject").split(" ")[0]}</span>
          </Button>
          
          <Button 
            onClick={onUploadCode}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 text-white btn-hover-effect"
            size="sm"
          >
            <Upload size={18} className="mr-1 md:mr-2" />
            <span className="hidden md:inline">{t("header.uploadCode")}</span>
            <span className="md:hidden">{t("header.uploadCode").split(" ")[0]}</span>
          </Button>
        </div>
      </div>
      
      {/* Декоративный анимированный элемент под хедером */}
      <div className="relative h-1 w-full overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 animate-gradient-shift"></div>
        <div className="absolute inset-0 w-full">
          {Array.from({ length: 20 }).map((_, i) => (
            <div 
              key={i} 
              className="absolute h-full bg-white opacity-30"
              style={{ 
                width: `${Math.random() * 5 + 1}px`, 
                left: `${i * 5}%`, 
                animation: `pulse 2s infinite alternate ${Math.random() * 2}s`
              }}
            ></div>
          ))}
        </div>
      </div>
    </header>
  );
}
