import { useState, useEffect } from "react";
import { User as FirebaseUser } from "firebase/auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LogIn, LogOut, UserPlus, User, Settings, Github } from "lucide-react";
import { signInWithGoogle, logOut, onAuthChange } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";

// Добавляем интерфейс для демо-пользователя
interface DemoUser {
  uid: string;
  email: string;
  displayName: string;
  isDemo: boolean;
  photoURL?: string;
}

export function UserAuth() {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | DemoUser | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [_, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    // Проверка, есть ли демо-пользователь в хранилище
    const checkDemoUser = () => {
      const demoUserStr = localStorage.getItem("demoUser");
      if (demoUserStr) {
        try {
          const demoUser = JSON.parse(demoUserStr) as DemoUser;
          setCurrentUser(demoUser);
        } catch (e) {
          localStorage.removeItem("demoUser");
        }
      }
    };

    // Установка слушателя для изменений состояния аутентификации
    const unsubscribe = onAuthChange((user) => {
      if (user) {
        setCurrentUser(user);
        // Если настоящий пользователь авторизовался, удаляем демо-пользователя
        localStorage.removeItem("demoUser");
      } else {
        // Если нет обычного пользователя, проверяем демо-пользователя
        checkDemoUser();
      }
    });

    // При первом рендере проверяем демо-пользователя
    checkDemoUser();

    // Очистка слушателя при размонтировании компонента
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      setIsLoading(true);
      await signInWithGoogle();
      toast({
        title: "Успешный вход",
        description: "Вы успешно вошли в систему",
      });
    } catch (error) {
      toast({
        title: "Ошибка входа",
        description: "Не удалось войти через Google",
        variant: "destructive",
      });
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      // Проверяем, является ли пользователь демо-пользователем
      if (currentUser && 'isDemo' in currentUser && currentUser.isDemo) {
        // Для демо-пользователя просто удаляем запись из localStorage
        localStorage.removeItem("demoUser");
        setCurrentUser(null);
      } else {
        // Обычный выход через Firebase
        await logOut();
      }
      
      toast({
        title: "Выход из системы",
        description: "Вы успешно вышли из системы",
      });
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось выйти из системы",
        variant: "destructive",
      });
      console.error(error);
    }
  };

  // Если пользователь не авторизован, показываем кнопки для входа
  if (!currentUser) {
    return (
      <div className="flex gap-2">
        <Button
          onClick={() => setLocation("/auth")}
          variant="default"
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
        >
          <UserPlus size={16} />
          <span>Регистрация</span>
        </Button>
        <Button
          onClick={() => setLocation("/auth")}
          variant="outline"
          className="flex items-center gap-2"
        >
          <LogIn size={16} />
          <span>Войти</span>
        </Button>
      </div>
    );
  }

  // Если пользователь авторизован, показываем его аватар и выпадающее меню
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="relative h-10 w-10 rounded-full p-0 hover:bg-indigo-100 hover:text-indigo-700"
        >
          <Avatar className="h-9 w-9 border border-indigo-200">
            {currentUser.photoURL ? (
              <AvatarImage src={currentUser.photoURL} alt={currentUser.displayName || ""} />
            ) : (
              <AvatarFallback className="bg-indigo-100 text-indigo-700">
                {currentUser.displayName
                  ? currentUser.displayName.charAt(0).toUpperCase()
                  : currentUser.email
                  ? currentUser.email.charAt(0).toUpperCase()
                  : "U"}
              </AvatarFallback>
            )}
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel>
          <div className="flex flex-col space-y-1">
            <div className="flex items-center">
              <p className="text-sm font-medium leading-none">{currentUser.displayName}</p>
              {'isDemo' in currentUser && currentUser.isDemo && (
                <span className="ml-2 inline-flex items-center rounded-md bg-purple-50 px-2 py-1 text-xs font-medium text-purple-700 ring-1 ring-inset ring-purple-700/10">
                  Демо
                </span>
              )}
            </div>
            <p className="text-xs leading-none text-muted-foreground">{currentUser.email}</p>
          </div>
        </DropdownMenuLabel>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem className="cursor-pointer">
          <User className="mr-2 h-4 w-4" />
          <span>Профиль</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem className="cursor-pointer">
          <Settings className="mr-2 h-4 w-4" />
          <span>Настройки</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem className="cursor-pointer" onClick={() => setLocation("/my-projects")}>
          <Github className="mr-2 h-4 w-4" />
          <span>Мои проекты</span>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem className="cursor-pointer text-red-600" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Выйти</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}