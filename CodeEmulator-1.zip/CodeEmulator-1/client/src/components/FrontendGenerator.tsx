import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Code2, FileCode, Github, Archive } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface FrontendGeneratorProps {
  onApplyCode: (code: { 
    components: Array<{name: string, path: string, code: string}>,
    pages: Array<{name: string, path: string, code: string}>
  }) => void;
}

export default function FrontendGenerator({ onApplyCode }: FrontendGeneratorProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isImportLoading, setIsImportLoading] = useState(false);
  const [backendCode, setBackendCode] = useState("");
  const [generatedFrontend, setGeneratedFrontend] = useState<any>(null);
  const [activeTab, setActiveTab] = useState("backend");
  const [githubUrl, setGithubUrl] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { toast } = useToast();

  const handleGenerateFrontend = async () => {
    if (isLoading) return;
    if (!backendCode.trim()) {
      toast({
        title: "Ошибка",
        description: "Введите бэкенд код для анализа",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    setGeneratedFrontend(null);
    
    try {
      const response = await fetch("/api/ai/generate-frontend", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          backendCode,
        }),
      });

      if (!response.ok) {
        throw new Error("Ошибка при генерации фронтенда");
      }

      const data = await response.json();
      setGeneratedFrontend(data);
      
      toast({
        title: "Фронтенд сгенерирован",
        description: "ИИ успешно сгенерировал фронтенд для вашего бэкенда",
      });
      
      // Автоматически переключаемся на вкладку с результатом
      setActiveTab("result");
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось сгенерировать фронтенд",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyGeneratedCode = () => {
    if (!generatedFrontend) return;
    
    onApplyCode({
      components: generatedFrontend.components || [],
      pages: generatedFrontend.pages || []
    });
    
    toast({
      title: "Код применен",
      description: "Сгенерированный фронтенд был успешно применен",
    });
  };
  
  // Импорт из GitHub
  const handleGithubImport = async () => {
    if (isImportLoading || !githubUrl.trim()) return;
    
    setIsImportLoading(true);
    
    try {
      const response = await fetch("/api/import/github", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: githubUrl,
        }),
      });

      if (!response.ok) {
        throw new Error("Ошибка при импорте из GitHub");
      }

      const data = await response.json();
      
      if (data.jsCode) {
        setBackendCode(data.jsCode);
        toast({
          title: "Код импортирован",
          description: "Код успешно импортирован из GitHub",
        });
      } else {
        toast({
          title: "Предупреждение",
          description: "Не найден код бэкенда в репозитории. Попробуйте другой репозиторий.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось импортировать код из GitHub",
        variant: "destructive",
      });
    } finally {
      setIsImportLoading(false);
    }
  };
  
  // Импорт из ZIP-файла
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      
      if (file.type !== "application/zip" && !file.name.endsWith(".zip")) {
        toast({
          title: "Ошибка",
          description: "Пожалуйста, выберите файл в формате ZIP",
          variant: "destructive",
        });
        return;
      }
      
      const formData = new FormData();
      formData.append("zipfile", file);
      
      setIsImportLoading(true);
      
      fetch("/api/import/zip", {
        method: "POST",
        body: formData,
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Ошибка при импорте из ZIP-файла");
          }
          return response.json();
        })
        .then((data) => {
          if (data.jsCode) {
            setBackendCode(data.jsCode);
            toast({
              title: "Код импортирован",
              description: "Код успешно импортирован из ZIP-файла",
            });
          } else {
            toast({
              title: "Предупреждение", 
              description: "Не найден код бэкенда в ZIP-файле",
              variant: "destructive",
            });
          }
        })
        .catch((error) => {
          toast({
            title: "Ошибка",
            description: error instanceof Error ? error.message : "Не удалось импортировать код из ZIP-файла",
            variant: "destructive",
          });
        })
        .finally(() => {
          setIsImportLoading(false);
          // Сбрасываем input, чтобы можно было загрузить тот же файл повторно
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }
        });
    }
  };

  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <div className="bg-gray-50 p-4 border-b border-gray-200 flex items-center justify-between">
        <h3 className="text-lg font-medium">Генератор фронтенда</h3>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="border-b">
          <TabsList className="h-10 bg-gray-50 w-full justify-start rounded-none">
            <TabsTrigger
              value="backend"
              className="data-[state=active]:bg-white rounded-none border-r"
            >
              Бэкенд код
            </TabsTrigger>
            <TabsTrigger
              value="result"
              className="data-[state=active]:bg-white rounded-none"
            >
              Результат
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="backend" className="p-4">
          <div className="space-y-4">
            <div className="flex gap-2 mb-4">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-1/2">
                    <Github className="mr-2 h-4 w-4" />
                    Импорт из GitHub
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Импорт кода из GitHub</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <p className="text-sm text-gray-600">
                      Введите URL GitHub репозитория с кодом бэкенда
                    </p>
                    <Input 
                      placeholder="https://github.com/username/repo"
                      value={githubUrl}
                      onChange={(e) => setGithubUrl(e.target.value)}
                    />
                    <Button 
                      onClick={handleGithubImport}
                      disabled={isImportLoading || !githubUrl.trim()}
                      className="w-full"
                    >
                      {isImportLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Импорт...
                        </>
                      ) : (
                        <>
                          <Github className="mr-2 h-4 w-4" />
                          Импортировать
                        </>
                      )}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button
                variant="outline"
                className="w-1/2"
                onClick={() => fileInputRef.current?.click()}
                disabled={isImportLoading}
              >
                {isImportLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Импорт...
                  </>
                ) : (
                  <>
                    <Archive className="mr-2 h-4 w-4" />
                    Импорт из ZIP
                  </>
                )}
              </Button>
              
              <input 
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept=".zip"
                onChange={handleFileUpload}
              />
            </div>
          
            <p className="text-gray-700">
              Вставьте ваш бэкенд код (API маршруты, контроллеры и т.д.), и ИИ сгенерирует подходящий фронтенд с интеграцией.
            </p>
            
            <Textarea 
              placeholder="Вставьте ваш бэкенд код..."
              value={backendCode}
              onChange={(e) => setBackendCode(e.target.value)}
              rows={15}
              className="font-mono text-sm"
            />

            <Button 
              onClick={handleGenerateFrontend} 
              disabled={isLoading || !backendCode.trim()}
              className="bg-blue-600 hover:bg-blue-700 w-full"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Генерация фронтенда...
                </>
              ) : (
                <>
                  <Code2 className="mr-2 h-4 w-4" />
                  Сгенерировать фронтенд
                </>
              )}
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="result" className="min-h-[400px]">
          {generatedFrontend ? (
            <div className="h-full">
              <div className="p-4">
                <h4 className="font-medium text-lg mb-2">Анализ бэкенда</h4>
                <p className="text-gray-700 mb-4">{generatedFrontend.analysis}</p>
                
                <div className="border rounded-lg p-4 mb-4">
                  <div className="flex items-center mb-2">
                    <Code2 className="h-5 w-5 mr-2 text-blue-600" />
                    <h5 className="font-medium">Сгенерированные компоненты</h5>
                  </div>
                  <ul className="list-disc pl-5 space-y-1">
                    {generatedFrontend.components && generatedFrontend.components.map((component: any, index: number) => (
                      <li key={index}>{component.name} ({component.path})</li>
                    ))}
                    {(!generatedFrontend.components || generatedFrontend.components.length === 0) && (
                      <li className="text-gray-500">Нет компонентов</li>
                    )}
                  </ul>
                </div>
                
                <div className="border rounded-lg p-4 mb-4">
                  <div className="flex items-center mb-2">
                    <FileCode className="h-5 w-5 mr-2 text-green-600" />
                    <h5 className="font-medium">Сгенерированные страницы</h5>
                  </div>
                  <ul className="list-disc pl-5 space-y-1">
                    {generatedFrontend.pages && generatedFrontend.pages.map((page: any, index: number) => (
                      <li key={index}>{page.name} ({page.path})</li>
                    ))}
                    {(!generatedFrontend.pages || generatedFrontend.pages.length === 0) && (
                      <li className="text-gray-500">Нет страниц</li>
                    )}
                  </ul>
                </div>
                
                <Button 
                  onClick={handleApplyGeneratedCode}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <FileCode className="mr-2 h-4 w-4" />
                  Применить сгенерированный фронтенд
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center p-8">
              <FileCode className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-medium mb-2">Фронтенд не сгенерирован</h3>
              <p className="text-gray-500 mb-4">
                Вставьте ваш бэкенд код и нажмите "Сгенерировать фронтенд" для создания соответствующего пользовательского интерфейса.
              </p>
              <Button 
                onClick={() => setActiveTab("backend")}
                variant="outline"
              >
                Перейти к вводу бэкенда
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}