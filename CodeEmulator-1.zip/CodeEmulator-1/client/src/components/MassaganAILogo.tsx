/**
 * Современный анимированный Web3 Platinum логотип MassaganAI
 * Интегрирует все функции системы: ИИ-эмулятор, генерация презентаций, 3D моделей и медиаконтента
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React, { useEffect, useRef } from 'react';

interface MassaganAILogoProps {
  size?: number;
  animated?: boolean;
  style?: React.CSSProperties;
  className?: string;
  theme?: 'platinum' | 'dark' | 'gradient';
}

const MassaganAILogo: React.FC<MassaganAILogoProps> = ({
  size = 120,
  animated = true,
  style,
  className,
  theme = 'platinum'
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);
  
  // Основные цвета логотипа
  const getColors = () => {
    if (theme === 'platinum') {
      return {
        primary: '#E5E7E9', // платиновый
        secondary: '#7F8C8D', // графитовый
        accent: '#5D6D7E', // стальной
        glow: '#F5F8FA', // светлое свечение
        background: '#1C2833', // темный фон
        highlight: '#D6EAF8', // голубой акцент
      };
    } else if (theme === 'dark') {
      return {
        primary: '#2C3E50', // темно-синий
        secondary: '#34495E', // серо-синий
        accent: '#5D6D7E', // стальной
        glow: '#85C1E9', // голубое свечение
        background: '#17202A', // почти черный фон
        highlight: '#5DADE2', // яркий голубой
      };
    } else { // gradient
      return {
        primary: '#3498DB', // голубой
        secondary: '#9B59B6', // фиолетовый
        accent: '#1ABC9C', // бирюзовый
        glow: '#ECF0F1', // белое свечение
        background: '#2C3E50', // темно-синий фон
        highlight: '#F39C12', // оранжевый акцент
      };
    }
  };
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const colors = getColors();
    
    // Устанавливаем размеры канваса на основе заданного размера
    canvas.width = size;
    canvas.height = size;
    
    // Рисуем логотип
    const drawLogo = (time: number) => {
      if (!ctx) return;
      
      // Очищаем холст
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Центр канваса
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      
      // Коэффициент масштабирования для всех элементов
      const scale = size / 120;
      
      // Параметры анимации
      const pulseFactor = animated ? Math.sin(time * 0.003) * 0.05 + 0.95 : 1;
      const rotationAngle = animated ? time * 0.0005 : 0;
      const glowIntensity = animated ? Math.sin(time * 0.002) * 0.5 + 0.5 : 0.5;
      
      // Рисуем внешний круг с градиентом
      const outerRadius = 50 * scale * pulseFactor;
      const gradient = ctx.createRadialGradient(
        centerX, centerY, outerRadius * 0.7,
        centerX, centerY, outerRadius
      );
      gradient.addColorStop(0, colors.primary);
      gradient.addColorStop(1, colors.secondary);
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.shadowColor = colors.glow;
      ctx.shadowBlur = 15 * scale * glowIntensity;
      ctx.fill();
      ctx.shadowBlur = 0;
      
      // Рисуем внутренний круг
      const innerRadius = 40 * scale * pulseFactor;
      ctx.beginPath();
      ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
      ctx.fillStyle = colors.background;
      ctx.fill();
      
      // Рисуем элементы MassaganAI
      
      // 1. Мозг (символизирует ИИ)
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rotationAngle);
      
      // Мозг (контуры)
      ctx.beginPath();
      ctx.moveTo(-15 * scale, -10 * scale);
      ctx.bezierCurveTo(
        -20 * scale, -25 * scale,
        20 * scale, -25 * scale,
        15 * scale, -10 * scale
      );
      ctx.strokeStyle = colors.accent;
      ctx.lineWidth = 2 * scale;
      ctx.stroke();
      
      // Нейронные связи
      for (let i = 0; i < 5; i++) {
        const angle = (i / 5) * Math.PI + (time * 0.001);
        const radius = 20 * scale;
        const x1 = Math.cos(angle) * radius;
        const y1 = Math.sin(angle) * radius - 5 * scale;
        const x2 = Math.cos(angle + Math.PI) * radius;
        const y2 = Math.sin(angle + Math.PI) * radius - 5 * scale;
        
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = colors.highlight;
        ctx.lineWidth = 1 * scale;
        ctx.globalAlpha = 0.5 + Math.sin(time * 0.002 + i) * 0.5;
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
      
      // 2. Презентация (символизирует сервис презентаций)
      ctx.beginPath();
      ctx.rect(-25 * scale, 0 * scale, 20 * scale, 15 * scale);
      ctx.fillStyle = colors.accent;
      ctx.fill();
      
      // Линии презентации
      ctx.beginPath();
      ctx.moveTo(-22 * scale, 4 * scale);
      ctx.lineTo(-10 * scale, 4 * scale);
      ctx.moveTo(-22 * scale, 8 * scale);
      ctx.lineTo(-10 * scale, 8 * scale);
      ctx.moveTo(-22 * scale, 12 * scale);
      ctx.lineTo(-15 * scale, 12 * scale);
      ctx.strokeStyle = colors.background;
      ctx.lineWidth = 1.5 * scale;
      ctx.stroke();
      
      // 3. 3D куб (символизирует 3D модели)
      ctx.beginPath();
      ctx.moveTo(5 * scale, 5 * scale);
      ctx.lineTo(20 * scale, 5 * scale);
      ctx.lineTo(25 * scale, 15 * scale);
      ctx.lineTo(10 * scale, 15 * scale);
      ctx.closePath();
      ctx.fillStyle = colors.highlight;
      ctx.fill();
      
      // Верхняя грань куба
      ctx.beginPath();
      ctx.moveTo(5 * scale, 5 * scale);
      ctx.lineTo(10 * scale, -5 * scale);
      ctx.lineTo(25 * scale, -5 * scale);
      ctx.lineTo(20 * scale, 5 * scale);
      ctx.closePath();
      ctx.fillStyle = colors.secondary;
      ctx.fill();
      
      // Боковая грань куба
      ctx.beginPath();
      ctx.moveTo(20 * scale, 5 * scale);
      ctx.lineTo(25 * scale, -5 * scale);
      ctx.lineTo(25 * scale, 15 * scale);
      ctx.closePath();
      ctx.fillStyle = colors.primary;
      ctx.fill();
      
      // 4. Снежный барс (символ Казахстана)
      // Это стилизованное представление барса
      ctx.beginPath();
      ctx.ellipse(0, -15 * scale, 12 * scale, 8 * scale, 0, 0, Math.PI * 2);
      ctx.fillStyle = colors.secondary;
      ctx.fill();
      
      // Уши барса
      ctx.beginPath();
      ctx.moveTo(-8 * scale, -20 * scale);
      ctx.lineTo(-5 * scale, -25 * scale);
      ctx.lineTo(-2 * scale, -20 * scale);
      ctx.fillStyle = colors.primary;
      ctx.fill();
      
      ctx.beginPath();
      ctx.moveTo(8 * scale, -20 * scale);
      ctx.lineTo(5 * scale, -25 * scale);
      ctx.lineTo(2 * scale, -20 * scale);
      ctx.fillStyle = colors.primary;
      ctx.fill();
      
      // Глаза барса
      ctx.beginPath();
      ctx.arc(-4 * scale, -15 * scale, 1.5 * scale, 0, Math.PI * 2);
      ctx.arc(4 * scale, -15 * scale, 1.5 * scale, 0, Math.PI * 2);
      ctx.fillStyle = animated ? 
        `rgba(0, 255, 255, ${0.5 + Math.sin(time * 0.005) * 0.5})` : 
        colors.highlight;
      ctx.fill();
      
      ctx.restore();
      
      // Добавляем радиальное свечение вокруг логотипа
      const glowGradient = ctx.createRadialGradient(
        centerX, centerY, outerRadius * 0.8,
        centerX, centerY, outerRadius * 1.5
      );
      glowGradient.addColorStop(0, `rgba(255, 255, 255, ${0.1 * glowIntensity})`);
      glowGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius * 1.5, 0, Math.PI * 2);
      ctx.fillStyle = glowGradient;
      ctx.fill();
      
      if (animated) {
        animationRef.current = requestAnimationFrame(drawLogo);
      }
    };
    
    // Запускаем анимацию
    if (animated) {
      animationRef.current = requestAnimationFrame(drawLogo);
    } else {
      drawLogo(0);
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [size, animated, theme]);
  
  return (
    <canvas
      ref={canvasRef}
      className={className}
      style={{
        ...style,
        width: `${size}px`,
        height: `${size}px`
      }}
    />
  );
};

export default MassaganAILogo;