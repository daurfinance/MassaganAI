import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { GitBranch, FileIcon, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ImportFromGithubProps {
  onImportCode: (htmlCode: string, cssCode: string, jsCode: string) => void;
}

export default function ImportFromGithub({ onImportCode }: ImportFromGithubProps) {
  const [githubUrl, setGithubUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  const handleImportFromGithub = async () => {
    if (!githubUrl.trim()) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, введите URL репозитория GitHub",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch("/api/import/github", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url: githubUrl }),
      });

      if (!response.ok) {
        throw new Error("Не удалось импортировать код из GitHub");
      }

      const data = await response.json();
      onImportCode(data.html || "", data.css || "", data.js || "");
      
      toast({
        title: "Успешно",
        description: "Код успешно импортирован из GitHub",
      });
      
      setIsOpen(false);
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось импортировать код",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Проверяем, что это zip-файл
    if (!file.name.endsWith('.zip')) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, загрузите ZIP-файл",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    const formData = new FormData();
    formData.append('zipfile', file);

    try {
      const response = await fetch("/api/import/zip", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Не удалось импортировать код из ZIP-файла");
      }

      const data = await response.json();
      onImportCode(data.html || "", data.css || "", data.js || "");
      
      toast({
        title: "Успешно",
        description: "Код успешно импортирован из ZIP-файла",
      });
      
      setIsOpen(false);
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось импортировать код",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      // Сбрасываем значение поля file input
      event.target.value = '';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="mr-2">
          <Download className="h-4 w-4 mr-2" /> Импорт
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Импорт кода</DialogTitle>
          <DialogDescription>
            Импортируйте код из GitHub репозитория или ZIP-файла
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="github-url">GitHub репозиторий</Label>
            <div className="flex gap-2">
              <Input
                id="github-url"
                placeholder="https://github.com/username/repo"
                value={githubUrl}
                onChange={(e) => setGithubUrl(e.target.value)}
              />
              <Button 
                onClick={handleImportFromGithub} 
                disabled={isLoading}
                variant="secondary"
              >
                <GitBranch className="h-4 w-4 mr-2" />
                {isLoading ? "Загрузка..." : "Импорт"}
              </Button>
            </div>
            <p className="text-xs text-gray-500">
              Введите URL репозитория GitHub, который содержит HTML, CSS и JavaScript файлы
            </p>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="zip-file">ZIP-файл</Label>
            <div className="flex gap-2 items-center">
              <Input
                id="zip-file"
                type="file"
                accept=".zip"
                onChange={handleFileUpload}
                disabled={isLoading}
                className="flex-1"
              />
              <FileIcon className="h-5 w-5 text-gray-500" />
            </div>
            <p className="text-xs text-gray-500">
              Загрузите ZIP-файл, содержащий HTML, CSS и JavaScript файлы
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}