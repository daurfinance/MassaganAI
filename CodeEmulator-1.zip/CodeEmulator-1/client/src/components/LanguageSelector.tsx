import { useState, useEffect, useRef } from 'react';
import { Language, languages, getLanguage, saveLanguage } from '@/lib/translations';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Globe } from 'lucide-react';

interface LanguageSelectorProps {
  onLanguageChange: (lang: Language) => void;
}

export function LanguageSelector({ onLanguageChange }: LanguageSelectorProps) {
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(getLanguage());
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Загрузка сохраненного языка
  useEffect(() => {
    const savedLang = getLanguage();
    setSelectedLanguage(savedLang);
    // Вызываем функцию изменения языка при инициализации
    onLanguageChange(savedLang);
  }, [onLanguageChange]);
  
  // Обработчик клика вне выпадающего списка
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Обработчик выбора языка
  const handleLanguageSelect = (lang: Language) => {
    setSelectedLanguage(lang);
    saveLanguage(lang);
    onLanguageChange(lang);
    setIsOpen(false);
    
    // Если выбран арабский язык, добавляем класс RTL для всего документа
    if (lang === 'ar') {
      document.documentElement.dir = 'rtl';
      document.documentElement.classList.add('rtl');
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.classList.remove('rtl');
    }
  };
  
  // Находим информацию о выбранном языке
  const currentLanguage = languages.find(lang => lang.code === selectedLanguage) || languages[0];
  
  return (
    <div ref={dropdownRef}>
      <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="sm"
            className="flex items-center gap-1 px-2 py-1 h-8 hover:bg-indigo-50 hover:text-indigo-700 transition-all duration-300"
          >
            <Globe className="h-4 w-4 mr-1 opacity-80" />
            <span className="text-sm font-medium mr-1">{currentLanguage.flag}</span>
            <span className="text-xs">{currentLanguage.code.toUpperCase()}</span>
          </Button>
        </DropdownMenuTrigger>
        
        <DropdownMenuContent align="end" className="min-w-[160px] p-2 animate-fadeIn">
          <div className="px-2 py-1.5 text-xs font-semibold text-gray-500 border-b mb-1">
            Выберите язык
          </div>
          {languages.map((lang) => (
            <DropdownMenuItem
              key={lang.code}
              className={`flex items-center gap-2 px-3 py-2 cursor-pointer rounded-md ${
                selectedLanguage === lang.code ? 'bg-indigo-50 text-indigo-700' : ''
              } hover:bg-indigo-50 hover:text-indigo-700 transition-all duration-200`}
              onClick={() => handleLanguageSelect(lang.code)}
            >
              <span className="text-base">{lang.flag}</span>
              <span className="text-sm font-medium">{lang.name}</span>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

export default LanguageSelector;