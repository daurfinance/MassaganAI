/**
 * MassaganAI: ИИ-эмулятор кода
 * Компонент для загрузки, анализа и эмуляции кода
 * Поддерживает различные платформы и устройства
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import React, { useState, useEffect, useRef } from 'react';
import { useLanguage } from '@/lib/LanguageContext';
import { useAuth } from '@/hooks/AuthProvider';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

// UI компоненты
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Separator } from './ui/separator';
import { Loader2 } from 'lucide-react';
import { Progress } from './ui/progress';

// Иконки
import { 
  Code, 
  Upload, 
  FileCode, 
  Layout, 
  Terminal, 
  Play, 
  Smartphone, 
  Monitor, 
  Tablet, 
  Save,
  RefreshCw,
  Edit,
  Copy,
  Cpu,
  Github,
  FileUp
} from 'lucide-react';

// Типы устройств для эмулятора
type DeviceType = 'desktop' | 'mobile' | 'tablet';

// Типы систем для эмулятора
type SystemType = 'windows' | 'macos' | 'android' | 'ios';

// Типы языков программирования
type ProgrammingLanguage = 'javascript' | 'typescript' | 'python' | 'java' | 'csharp' | 'php' | 'ruby' | 'go' | 'rust' | 'swift' | 'kotlin';

interface EmulationResult {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  description: string;
  features: string[];
}

const AIEmulator: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Состояние загрузки кода
  const [htmlCode, setHtmlCode] = useState('');
  const [cssCode, setCssCode] = useState('');
  const [jsCode, setJsCode] = useState('');
  const [backendCode, setBackendCode] = useState('');
  
  // Состояние эмулятора
  const [selectedDevice, setSelectedDevice] = useState<DeviceType>('desktop');
  const [selectedSystem, setSelectedSystem] = useState<SystemType>('windows');
  const [selectedLanguage, setSelectedLanguage] = useState<ProgrammingLanguage>('javascript');
  const [githubUrl, setGithubUrl] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzeProgress, setAnalyzeProgress] = useState(0);
  
  // Состояние результата эмуляции
  const [emulationResult, setEmulationResult] = useState<EmulationResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const emulatorIframeRef = useRef<HTMLIFrameElement>(null);
  
  // Эффект прогресса анализа
  useEffect(() => {
    if (isAnalyzing) {
      const interval = setInterval(() => {
        setAnalyzeProgress((prev) => {
          const next = prev + Math.random() * 5;
          return next > 95 ? 95 : next;
        });
      }, 500);
      
      return () => clearInterval(interval);
    } else {
      setAnalyzeProgress(0);
    }
  }, [isAnalyzing]);
  
  // Мутация для анализа кода
  const analyzeCodeMutation = useMutation({
    mutationFn: async () => {
      setIsAnalyzing(true);
      
      try {
        const payload = {
          htmlCode,
          cssCode,
          jsCode,
          backendCode: backendCode || undefined,
          language: selectedLanguage,
          device: selectedDevice,
          system: selectedSystem
        };
        
        const response = await apiRequest('POST', '/api/ai/analyze-code', payload);
        const data = await response.json();
        return data;
      } catch (error) {
        console.error('Error analyzing code:', error);
        throw error;
      } finally {
        setIsAnalyzing(false);
        setAnalyzeProgress(100);
      }
    },
    onSuccess: (data) => {
      setEmulationResult(data);
      toast({
        title: t('AnalysisComplete'),
        description: t('CodeAnalyzedSuccessfully'),
      });
      
      // Обновляем iframe с эмулированным UI
      updateEmulatorIframe(data.htmlCode, data.cssCode, data.jsCode);
    },
    onError: (error: Error) => {
      toast({
        title: t('AnalysisFailed'),
        description: error.message || t('ErrorAnalyzingCode'),
        variant: 'destructive',
      });
    }
  });
  
  // Мутация для загрузки кода из GitHub
  const importFromGithubMutation = useMutation({
    mutationFn: async () => {
      setIsAnalyzing(true);
      
      try {
        const response = await apiRequest('POST', '/api/import/github', { url: githubUrl });
        const data = await response.json();
        return data;
      } catch (error) {
        console.error('Error importing from GitHub:', error);
        throw error;
      } finally {
        setIsAnalyzing(false);
        setAnalyzeProgress(100);
      }
    },
    onSuccess: (data) => {
      setHtmlCode(data.htmlCode || '');
      setCssCode(data.cssCode || '');
      setJsCode(data.jsCode || '');
      setBackendCode(data.backendCode || '');
      
      toast({
        title: t('ImportComplete'),
        description: t('CodeImportedFromGitHub'),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('ImportFailed'),
        description: error.message || t('ErrorImportingFromGitHub'),
        variant: 'destructive',
      });
    }
  });
  
  // Мутация для загрузки файла
  const importFromFileMutation = useMutation({
    mutationFn: async () => {
      if (!uploadedFile) throw new Error('No file selected');
      setIsAnalyzing(true);
      
      const formData = new FormData();
      formData.append('zipfile', uploadedFile);
      
      try {
        const response = await fetch('/api/import/file', {
          method: 'POST',
          body: formData,
        });
        
        if (!response.ok) {
          throw new Error(`Import failed: ${response.statusText}`);
        }
        
        const data = await response.json();
        return data;
      } catch (error) {
        console.error('Error importing from file:', error);
        throw error;
      } finally {
        setIsAnalyzing(false);
        setAnalyzeProgress(100);
      }
    },
    onSuccess: (data) => {
      setHtmlCode(data.htmlCode || '');
      setCssCode(data.cssCode || '');
      setJsCode(data.jsCode || '');
      setBackendCode(data.backendCode || '');
      
      toast({
        title: t('ImportComplete'),
        description: t('CodeImportedFromFile'),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('ImportFailed'),
        description: error.message || t('ErrorImportingFromFile'),
        variant: 'destructive',
      });
    }
  });
  
  // Обновляем iframe с эмулированным интерфейсом
  const updateEmulatorIframe = (html: string, css: string, js: string) => {
    if (!emulatorIframeRef.current) return;
    
    const iframeDocument = emulatorIframeRef.current.contentDocument;
    if (!iframeDocument) return;
    
    iframeDocument.open();
    iframeDocument.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>${css}</style>
        </head>
        <body>
          ${html}
          <script>${js}</script>
        </body>
      </html>
    `);
    iframeDocument.close();
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setUploadedFile(e.target.files[0]);
    }
  };
  
  const handleEmulate = () => {
    analyzeCodeMutation.mutate();
  };
  
  const handleImportFromGithub = () => {
    if (!githubUrl) {
      toast({
        title: t('Error'),
        description: t('PleaseEnterGitHubURL'),
        variant: 'destructive',
      });
      return;
    }
    
    importFromGithubMutation.mutate();
  };
  
  const handleImportFromFile = () => {
    if (!uploadedFile) {
      toast({
        title: t('Error'),
        description: t('PleaseSelectFile'),
        variant: 'destructive',
      });
      return;
    }
    
    importFromFileMutation.mutate();
  };
  
  // Получение размеров для эмулятора в зависимости от выбранного устройства
  const getEmulatorDimensions = (): { width: string, height: string } => {
    switch (selectedDevice) {
      case 'mobile':
        return { width: '375px', height: '667px' };
      case 'tablet':
        return { width: '768px', height: '1024px' };
      case 'desktop':
      default:
        return { width: '100%', height: '600px' };
    }
  };
  
  // Получение класса стилей для эмулятора в зависимости от выбранного устройства
  const getEmulatorFrameClass = (): string => {
    switch (selectedDevice) {
      case 'mobile':
        return 'rounded-[20px] border-[12px] border-gray-800 overflow-hidden shadow-xl mx-auto';
      case 'tablet':
        return 'rounded-[20px] border-[16px] border-gray-800 overflow-hidden shadow-xl mx-auto';
      case 'desktop':
      default:
        return 'rounded-md border border-gray-200 overflow-hidden shadow-lg';
    }
  };
  
  // Системный UI для эмулятора в зависимости от выбранной системы
  const getSystemUI = (): React.ReactNode => {
    switch (selectedSystem) {
      case 'macos':
        return (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-200 dark:bg-gray-800">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <div className="flex-grow text-center text-xs text-gray-600 dark:text-gray-300">
              Emulated macOS
            </div>
          </div>
        );
      case 'windows':
        return (
          <div className="flex items-center justify-between px-3 py-1 bg-blue-600 text-white">
            <div className="text-xs">Emulated Windows</div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3">_</div>
              <div className="w-3 h-3">□</div>
              <div className="w-3 h-3">×</div>
            </div>
          </div>
        );
      case 'android':
        return (
          <div className="flex items-center justify-between px-3 py-1 bg-gray-200 dark:bg-gray-800">
            <div className="text-xs text-gray-600 dark:text-gray-300">◁</div>
            <div className="text-xs text-gray-600 dark:text-gray-300">○</div>
            <div className="text-xs text-gray-600 dark:text-gray-300">□</div>
          </div>
        );
      case 'ios':
        return (
          <div className="relative">
            <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-1/3 h-5 bg-black rounded-b-xl z-10" />
          </div>
        );
      default:
        return null;
    }
  };
  
  const dimensions = getEmulatorDimensions();
  const frameClass = getEmulatorFrameClass();
  
  return (
    <div className="container mx-auto p-4">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Code className="h-5 w-5 text-primary" />
                {t('AICodeEmulator')}
              </CardTitle>
              <CardDescription>{t('AICodeEmulatorDesc')}</CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label>{t('Device')}</Label>
                  <Select value={selectedDevice} onValueChange={(value: DeviceType) => setSelectedDevice(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('SelectDevice')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="desktop">
                        <div className="flex items-center gap-2">
                          <Monitor className="h-4 w-4" />
                          <span>{t('Desktop')}</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="mobile">
                        <div className="flex items-center gap-2">
                          <Smartphone className="h-4 w-4" />
                          <span>{t('Mobile')}</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="tablet">
                        <div className="flex items-center gap-2">
                          <Tablet className="h-4 w-4" />
                          <span>{t('Tablet')}</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>{t('System')}</Label>
                  <Select value={selectedSystem} onValueChange={(value: SystemType) => setSelectedSystem(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('SelectSystem')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="windows">Windows</SelectItem>
                      <SelectItem value="macos">macOS</SelectItem>
                      <SelectItem value="android">Android</SelectItem>
                      <SelectItem value="ios">iOS</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>{t('Language')}</Label>
                  <Select value={selectedLanguage} onValueChange={(value: ProgrammingLanguage) => setSelectedLanguage(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder={t('SelectLanguage')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="javascript">JavaScript</SelectItem>
                      <SelectItem value="typescript">TypeScript</SelectItem>
                      <SelectItem value="python">Python</SelectItem>
                      <SelectItem value="java">Java</SelectItem>
                      <SelectItem value="csharp">C#</SelectItem>
                      <SelectItem value="php">PHP</SelectItem>
                      <SelectItem value="ruby">Ruby</SelectItem>
                      <SelectItem value="go">Go</SelectItem>
                      <SelectItem value="rust">Rust</SelectItem>
                      <SelectItem value="swift">Swift</SelectItem>
                      <SelectItem value="kotlin">Kotlin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Tabs defaultValue="direct" className="w-full">
                <TabsList className="grid grid-cols-3 mb-2">
                  <TabsTrigger value="direct">
                    <div className="flex items-center gap-1">
                      <Code className="h-4 w-4" />
                      <span>{t('DirectInput')}</span>
                    </div>
                  </TabsTrigger>
                  <TabsTrigger value="github">
                    <div className="flex items-center gap-1">
                      <Github className="h-4 w-4" />
                      <span>GitHub</span>
                    </div>
                  </TabsTrigger>
                  <TabsTrigger value="upload">
                    <div className="flex items-center gap-1">
                      <Upload className="h-4 w-4" />
                      <span>{t('Upload')}</span>
                    </div>
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="direct" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="html-code">HTML</Label>
                    <Textarea
                      id="html-code"
                      value={htmlCode}
                      onChange={(e) => setHtmlCode(e.target.value)}
                      placeholder="<div>Your HTML code here...</div>"
                      className="font-mono text-sm h-[120px]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="css-code">CSS</Label>
                    <Textarea
                      id="css-code"
                      value={cssCode}
                      onChange={(e) => setCssCode(e.target.value)}
                      placeholder="body { font-family: sans-serif; }"
                      className="font-mono text-sm h-[120px]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="js-code">JavaScript</Label>
                    <Textarea
                      id="js-code"
                      value={jsCode}
                      onChange={(e) => setJsCode(e.target.value)}
                      placeholder="document.addEventListener('DOMContentLoaded', () => { ... });"
                      className="font-mono text-sm h-[120px]"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="backend-code">{t('BackendCode')} ({t('Optional')})</Label>
                      <span className="text-xs text-muted-foreground">{selectedLanguage}</span>
                    </div>
                    <Textarea
                      id="backend-code"
                      value={backendCode}
                      onChange={(e) => setBackendCode(e.target.value)}
                      placeholder={t('BackendCodePlaceholder')}
                      className="font-mono text-sm h-[150px]"
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="github" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="github-url">GitHub URL</Label>
                    <div className="flex gap-2">
                      <Input
                        id="github-url"
                        value={githubUrl}
                        onChange={(e) => setGithubUrl(e.target.value)}
                        placeholder="https://github.com/username/repository"
                        className="flex-grow"
                      />
                      <Button 
                        onClick={handleImportFromGithub}
                        disabled={importFromGithubMutation.isPending}
                      >
                        {importFromGithubMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Github className="h-4 w-4" />
                        )}
                        <span className="ml-2">{t('Import')}</span>
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">{t('GitHubImportDescription')}</p>
                  </div>
                  
                  {importFromGithubMutation.isPending && (
                    <div className="space-y-2">
                      <Progress value={analyzeProgress} className="w-full" />
                      <p className="text-xs text-center text-muted-foreground">{t('AnalyzingRepository')}</p>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="upload" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="file-upload">{t('UploadZipFile')}</Label>
                    <div className="flex gap-2">
                      <Input
                        id="file-upload"
                        type="file"
                        accept=".zip,.rar,.tar.gz"
                        onChange={handleFileChange}
                        ref={fileInputRef}
                        className="flex-grow"
                      />
                      <Button 
                        onClick={handleImportFromFile}
                        disabled={importFromFileMutation.isPending || !uploadedFile}
                      >
                        {importFromFileMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <FileUp className="h-4 w-4" />
                        )}
                        <span className="ml-2">{t('Upload')}</span>
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">{t('FileUploadDescription')}</p>
                  </div>
                  
                  {importFromFileMutation.isPending && (
                    <div className="space-y-2">
                      <Progress value={analyzeProgress} className="w-full" />
                      <p className="text-xs text-center text-muted-foreground">{t('AnalyzingFile')}</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
            
            <CardFooter>
              <Button 
                onClick={handleEmulate}
                disabled={analyzeCodeMutation.isPending || (!htmlCode && !cssCode && !jsCode && !backendCode)}
                className="w-full"
              >
                {analyzeCodeMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {t('Analyzing')}...
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    {t('EmulateInterface')}
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
          
          {analyzeCodeMutation.isPending && (
            <Card>
              <CardContent className="pt-6 space-y-4">
                <Progress value={analyzeProgress} className="w-full" />
                <div className="text-center text-sm text-muted-foreground">
                  <p>{t('AnalyzingCode')}</p>
                  <p className="text-xs mt-1">{t('ThisMayTakeAMoment')}</p>
                </div>
              </CardContent>
            </Card>
          )}
          
          {emulationResult && (
            <Card>
              <CardHeader>
                <CardTitle>{t('EmulationResult')}</CardTitle>
                <CardDescription>{t('AIGeneratedDescription')}</CardDescription>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">{t('Description')}</h3>
                  <p className="text-sm text-muted-foreground">{emulationResult.description}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">{t('DetectedFeatures')}</h3>
                  <ul className="list-disc list-inside text-sm text-muted-foreground">
                    {emulationResult.features.map((feature, index) => (
                      <li key={index}>{feature}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm">
                    <Copy className="h-4 w-4 mr-1" />
                    {t('CopyCode')}
                  </Button>
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4 mr-1" />
                    {t('EditEmulation')}
                  </Button>
                  <Button variant="outline" size="sm">
                    <Save className="h-4 w-4 mr-1" />
                    {t('SaveProject')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        
        <div className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Cpu className="text-primary h-5 w-5" />
              <h2 className="text-xl font-bold">{t('EmulatorPreview')}</h2>
            </div>
            
            <Button variant="outline" size="sm" onClick={() => updateEmulatorIframe(htmlCode, cssCode, jsCode)}>
              <RefreshCw className="h-4 w-4 mr-1" />
              {t('Refresh')}
            </Button>
          </div>
          
          <div className={frameClass} style={{ width: dimensions.width }}>
            {getSystemUI()}
            
            <div className="w-full h-full bg-white">
              {(!htmlCode && !cssCode && !jsCode && !emulationResult) ? (
                <div className="flex flex-col items-center justify-center h-[600px] text-center p-6 bg-gray-50 dark:bg-gray-900">
                  <Layout className="h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">{t('NoPreviewAvailable')}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 max-w-md mt-2">
                    {t('EnterCodeOrImport')}
                  </p>
                </div>
              ) : (
                <iframe 
                  ref={emulatorIframeRef}
                  title="Emulator Preview"
                  className="w-full"
                  style={{ height: dimensions.height, border: 'none' }}
                  sandbox="allow-scripts allow-same-origin"
                />
              )}
            </div>
          </div>
          
          <p className="text-xs text-center text-muted-foreground">
            {t('EmulatorDisclaimer')}
          </p>
        </div>
      </div>
    </div>
  );
};

export default AIEmulator;