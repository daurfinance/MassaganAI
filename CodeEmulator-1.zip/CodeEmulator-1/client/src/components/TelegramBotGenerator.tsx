import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Check, Copy, Download, Loader2, BotMessageSquare, Bot, Sparkles, Code, Eye } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { User } from "firebase/auth";
import { auth } from "@/lib/firebase";

interface CodePreviewProps {
  code: string;
  language: string;
  title: string;
}

function CodePreview({ code, language, title }: CodePreviewProps) {
  const [copied, setCopied] = useState(false);
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  return (
    <div className="rounded-md border border-gray-200 bg-white">
      <div className="flex items-center justify-between border-b border-gray-200 bg-gray-50 px-3 py-2">
        <div className="font-medium text-sm text-gray-700">{title}</div>
        <div className="flex gap-1">
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 w-7 p-0" 
            onClick={copyToClipboard}
          >
            {copied ? (
              <Check className="h-4 w-4 text-green-500" />
            ) : (
              <Copy className="h-4 w-4 text-gray-500" />
            )}
          </Button>
        </div>
      </div>
      <ScrollArea className="h-[300px] p-4">
        <pre className="text-sm font-mono">
          <code className={`language-${language}`}>{code}</code>
        </pre>
      </ScrollArea>
    </div>
  );
}

export default function TelegramBotGenerator() {
  const [description, setDescription] = useState("");
  const [botName, setBotName] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState<{
    jsCode: string;
    pythonCode: string;
    setupInstructions: string;
  } | null>(null);
  const { toast } = useToast();
  
  const generateBot = async () => {
    if (!auth.currentUser) {
      toast({
        title: "Требуется авторизация",
        description: "Пожалуйста, войдите в систему, чтобы генерировать Telegram ботов",
        variant: "destructive",
      });
      return;
    }
    
    if (!description) {
      toast({
        title: "Необходимо описание",
        description: "Пожалуйста, введите описание для вашего бота",
        variant: "destructive",
      });
      return;
    }
    
    if (!botName) {
      toast({
        title: "Необходимо имя бота",
        description: "Пожалуйста, введите имя для вашего бота",
        variant: "destructive",
      });
      return;
    }
    
    try {
      setIsGenerating(true);
      
      // В реальном приложении здесь будет запрос к вашему API
      // для генерации кода бота на основе Perplexity API
      // Имитация задержки для демонстрации
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Демонстрационные шаблоны кода
      setGeneratedCode({
        jsCode: generateJavaScriptTemplate(botName, description),
        pythonCode: generatePythonTemplate(botName, description),
        setupInstructions: generateInstructions(botName),
      });
      
      toast({
        title: "Бот успешно создан",
        description: "Код для вашего Telegram бота был успешно сгенерирован",
      });
    } catch (error) {
      console.error("Ошибка при генерации бота:", error);
      toast({
        title: "Ошибка генерации",
        description: "Не удалось сгенерировать код для Telegram бота",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  const downloadCodeAsZip = () => {
    if (!generatedCode) return;
    
    toast({
      title: "Загрузка кода",
      description: "Код для вашего Telegram бота скачивается",
    });
    
    // В реальном приложении здесь будет логика для формирования ZIP
    // с использованием библиотеки, например, JSZip
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col space-y-4 mb-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 mb-2">
            Генератор Telegram ботов
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Опишите функциональность для вашего бота, и MassaganAI сгенерирует готовый код на JavaScript или Python
          </p>
        </div>
        
        <Card className="border border-indigo-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center">
              <BotMessageSquare className="mr-2 text-indigo-500" size={20} />
              Настройки бота
            </CardTitle>
            <CardDescription>
              Опишите, что должен делать ваш Telegram бот
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label htmlFor="bot-name">Имя бота</Label>
              <Input
                id="bot-name"
                placeholder="Например: WeatherNotifierBot"
                value={botName}
                onChange={(e) => setBotName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bot-description">Описание функциональности</Label>
              <Textarea
                id="bot-description"
                placeholder="Опишите, что должен делать ваш бот. Например: Бот должен отправлять ежедневный прогноз погоды пользователям и позволять им получать текущую погоду по запросу."
                className="min-h-[120px]"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              onClick={generateBot} 
              disabled={isGenerating}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Генерация кода...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Сгенерировать бота
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
        
        {generatedCode && (
          <div className="mt-6 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold flex items-center text-gray-800">
                <Bot className="mr-2 text-indigo-500" size={20} />
                Сгенерированный код для {botName}
              </h3>
              <Button 
                onClick={downloadCodeAsZip} 
                variant="outline" 
                className="border-indigo-200 flex items-center"
              >
                <Download className="mr-2 h-4 w-4" />
                Скачать как ZIP
              </Button>
            </div>
            
            <Tabs defaultValue="javascript">
              <TabsList className="w-full grid grid-cols-3 mb-4">
                <TabsTrigger value="javascript" className="flex items-center">
                  <Code className="mr-2 h-4 w-4" />
                  JavaScript
                </TabsTrigger>
                <TabsTrigger value="python" className="flex items-center">
                  <Code className="mr-2 h-4 w-4" />
                  Python
                </TabsTrigger>
                <TabsTrigger value="instructions" className="flex items-center">
                  <Eye className="mr-2 h-4 w-4" />
                  Инструкции
                </TabsTrigger>
              </TabsList>
              <TabsContent value="javascript">
                <CodePreview 
                  code={generatedCode.jsCode} 
                  language="javascript"
                  title="bot.js" 
                />
              </TabsContent>
              <TabsContent value="python">
                <CodePreview 
                  code={generatedCode.pythonCode} 
                  language="python"
                  title="bot.py" 
                />
              </TabsContent>
              <TabsContent value="instructions">
                <CodePreview 
                  code={generatedCode.setupInstructions} 
                  language="markdown"
                  title="README.md" 
                />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
}

// Вспомогательные функции для генерации шаблонов

function generateJavaScriptTemplate(botName: string, description: string): string {
  return `// ${botName} - Telegram бот
// ${description}

const { Telegraf } = require('telegraf');
const axios = require('axios');

// Замените на ваш токен от BotFather
const token = 'YOUR_TELEGRAM_BOT_TOKEN';
const bot = new Telegraf(token);

// Обработчик команды /start
bot.start((ctx) => {
  ctx.reply('Привет! Я ${botName}. ${description.split('.')[0]}');
});

// Обработчик команды /help
bot.help((ctx) => {
  ctx.reply('Доступные команды:\\n/start - начать работу с ботом\\n/help - показать справку');
});

// Пример обработки текстовых сообщений
bot.on('text', (ctx) => {
  const message = ctx.message.text.toLowerCase();
  
  if (message.includes('привет')) {
    ctx.reply('Привет! Чем я могу помочь?');
  } else {
    ctx.reply('Я получил ваше сообщение. Используйте /help для справки.');
  }
});

// Запуск бота
bot.launch()
  .then(() => {
    console.log('${botName} запущен!');
  })
  .catch((err) => {
    console.error('Ошибка при запуске бота:', err);
  });

// Корректное завершение работы
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));`;
}

function generatePythonTemplate(botName: string, description: string): string {
  return `# ${botName} - Telegram бот
# ${description}

import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Замените на ваш токен от BotFather
TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"

# Обработчик команды /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(f'Привет! Я {botName}. ${description.split('.')[0]}')

# Обработчик команды /help
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text('Доступные команды:\\n/start - начать работу с ботом\\n/help - показать справку')

# Обработчик текстовых сообщений
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message = update.message.text.lower()
    
    if 'привет' in message:
        await update.message.reply_text('Привет! Чем я могу помочь?')
    else:
        await update.message.reply_text('Я получил ваше сообщение. Используйте /help для справки.')

# Основная функция
def main() -> None:
    # Создаем приложение
    application = Application.builder().token(TOKEN).build()

    # Добавляем обработчики
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Запускаем бота
    logger.info("Бот запущен")
    application.run_polling()

if __name__ == '__main__':
    main()`;
}

function generateInstructions(botName: string): string {
  return `# Инструкция по установке и запуску ${botName}

## Предварительные требования

### Для JavaScript версии:
1. Установите Node.js (версия 14 или выше)
2. Установите npm (обычно идет вместе с Node.js)

### Для Python версии:
1. Установите Python (версия 3.7 или выше)
2. Установите pip (обычно идет вместе с Python)

## Получение токена Telegram бота

1. Откройте Telegram и найдите @BotFather
2. Отправьте команду /newbot
3. Следуйте инструкциям, чтобы создать нового бота
4. После создания вы получите токен бота - сохраните его

## Установка (JavaScript)

1. Создайте новую папку для вашего бота
2. Создайте файл \`bot.js\` и скопируйте в него код из вкладки JavaScript
3. Откройте терминал в этой папке и выполните:

\`\`\`bash
npm init -y
npm install telegraf axios
\`\`\`

4. Замените \`YOUR_TELEGRAM_BOT_TOKEN\` в коде на токен, полученный от BotFather

## Установка (Python)

1. Создайте новую папку для вашего бота
2. Создайте файл \`bot.py\` и скопируйте в него код из вкладки Python
3. Откройте терминал в этой папке и выполните:

\`\`\`bash
pip install python-telegram-bot
\`\`\`

4. Замените \`YOUR_TELEGRAM_BOT_TOKEN\` в коде на токен, полученный от BotFather

## Запуск бота

### JavaScript версия:
\`\`\`bash
node bot.js
\`\`\`

### Python версия:
\`\`\`bash
python bot.py
\`\`\`

## Дополнительная информация

- Документация Telegraf (JavaScript): https://telegraf.js.org/
- Документация python-telegram-bot: https://python-telegram-bot.readthedocs.io/
- Telegram Bot API: https://core.telegram.org/bots/api

## Поддержка

Если у вас возникли проблемы с ботом, обратитесь в поддержку MassaganAI.`;
}