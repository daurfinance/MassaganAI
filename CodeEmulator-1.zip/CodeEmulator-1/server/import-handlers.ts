import { Request, Response } from "express";
import simpleGit, { SimpleGit } from "simple-git";
import AdmZip from "adm-zip";
import axios from "axios";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import * as util from "util";
import multer from "multer";

// Настройка multer для загрузки ZIP-файлов
const upload = multer({ 
  dest: os.tmpdir(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB максимальный размер файла
  }
});

// Обертка multer для Express
export const uploadZipMiddleware = upload.single('zipfile');

// Промисифицируем fs.readFile
const readFile = util.promisify(fs.readFile);
const rm = util.promisify(fs.rm);

/**
 * Функция для поиска файлов определенного типа в директории
 */
async function findFiles(dir: string, extension: string): Promise<string> {
  try {
    const files = fs.readdirSync(dir, { recursive: true, encoding: 'utf-8' });
    const matchingFiles = (files as string[]).filter(file => {
      const filePath = path.join(dir, file);
      const isFile = fs.statSync(filePath).isFile();
      return isFile && file.endsWith(extension);
    });

    if (matchingFiles.length === 0) {
      return "";
    }

    // Приоритет основным файлам - index.html, style.css, main.js и т.д.
    const priorityFileNames = {
      '.html': ["index.html", "main.html", "app.html"],
      '.css': ["style.css", "main.css", "app.css", "index.css"],
      '.js': ["main.js", "app.js", "index.js", "script.js"]
    };

    const priorities = priorityFileNames[extension as keyof typeof priorityFileNames] || [];
    
    let selectedFile = matchingFiles[0]; // По умолчанию берем первый найденный файл
    
    for (const priority of priorities) {
      const found = matchingFiles.find(file => path.basename(file) === priority);
      if (found) {
        selectedFile = found;
        break;
      }
    }

    const filePath = path.join(dir, selectedFile);
    return fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    console.error(`Ошибка при поиске файлов ${extension}:`, error);
    return "";
  }
}

/**
 * Обработчик для импорта из GitHub
 */
export async function handleGithubImport(req: Request, res: Response) {
  const { url } = req.body;

  if (!url) {
    return res.status(400).json({ message: "URL репозитория GitHub не указан" });
  }

  // Проверка, что URL указывает на GitHub
  if (!url.startsWith("https://github.com/")) {
    return res.status(400).json({ message: "Некорректный URL GitHub репозитория" });
  }

  // Создаем временную директорию для клонирования репозитория
  const tmpDir = path.join(os.tmpdir(), `github-import-${Date.now()}`);
  
  try {
    fs.mkdirSync(tmpDir, { recursive: true });
    
    // Клонируем репозиторий
    const git: SimpleGit = simpleGit();
    await git.clone(url, tmpDir, ['--depth=1']);
    
    // Ищем HTML, CSS и JS файлы в клонированном репозитории
    const htmlCode = await findFiles(tmpDir, '.html');
    const cssCode = await findFiles(tmpDir, '.css');
    const jsCode = await findFiles(tmpDir, '.js');
    
    // Удаляем временную директорию
    await rm(tmpDir, { recursive: true, force: true });
    
    res.json({
      html: htmlCode,
      css: cssCode,
      js: jsCode
    });
  } catch (error) {
    console.error("Ошибка при импорте из GitHub:", error);
    
    // Пытаемся удалить временную директорию в случае ошибки
    try {
      await rm(tmpDir, { recursive: true, force: true });
    } catch (e) {
      console.error("Ошибка при удалении временной директории:", e);
    }
    
    res.status(500).json({ 
      message: "Не удалось импортировать код из GitHub", 
      error: error instanceof Error ? error.message : String(error) 
    });
  }
}

/**
 * Обработчик для импорта из ZIP-файла
 */
export async function handleZipImport(req: Request, res: Response) {
  if (!req.file) {
    return res.status(400).json({ message: "ZIP-файл не был загружен" });
  }

  const zipFilePath = req.file.path;
  
  // Создаем временную директорию для извлечения ZIP-файла
  const extractDir = path.join(os.tmpdir(), `zip-import-${Date.now()}`);

  try {
    fs.mkdirSync(extractDir, { recursive: true });
    
    // Извлекаем содержимое ZIP-файла
    const zip = new AdmZip(zipFilePath);
    zip.extractAllTo(extractDir, true);
    
    // Ищем HTML, CSS и JS файлы в извлеченных файлах
    const htmlCode = await findFiles(extractDir, '.html');
    const cssCode = await findFiles(extractDir, '.css');
    const jsCode = await findFiles(extractDir, '.js');
    
    // Удаляем временные файлы
    await rm(zipFilePath, { force: true });
    await rm(extractDir, { recursive: true, force: true });
    
    res.json({
      html: htmlCode,
      css: cssCode,
      js: jsCode
    });
  } catch (error) {
    console.error("Ошибка при импорте из ZIP-файла:", error);
    
    // Пытаемся удалить временные файлы в случае ошибки
    try {
      await rm(zipFilePath, { force: true });
      await rm(extractDir, { recursive: true, force: true });
    } catch (e) {
      console.error("Ошибка при удалении временных файлов:", e);
    }
    
    res.status(500).json({ 
      message: "Не удалось импортировать код из ZIP-файла", 
      error: error instanceof Error ? error.message : String(error) 
    });
  }
}