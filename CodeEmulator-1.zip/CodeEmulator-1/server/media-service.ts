/**
 * MassaganAI: Сервис для генерации и обработки медиаконтента
 * Поддерживает создание и модификацию изображений, видео и озвучивание текста
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import { Request, Response, Express } from 'express';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { exec, spawn } from 'child_process';
import * as util from 'util';
import multer from 'multer';

// ESM модуль не имеет доступа к __dirname, поэтому мы создаем его вручную
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Настройки Multer для загрузки файлов
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const dir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB лимит
});

const execAsync = util.promisify(exec);

// Класс для работы с медиаконтентом
class MediaProcessor {
  private pythonPath: string;
  private tempDir: string;
  private publicDir: string;
  
  constructor() {
    this.pythonPath = 'python3';
    this.tempDir = path.join(__dirname, '../temp');
    this.publicDir = path.join(__dirname, '../public');
    
    // Создаем временную директорию и публичную директорию, если их нет
    if (!fs.existsSync(this.tempDir)) {
      fs.mkdirSync(this.tempDir, { recursive: true });
    }
    if (!fs.existsSync(this.publicDir)) {
      fs.mkdirSync(this.publicDir, { recursive: true });
    }
    
    // Создаем директории для различных типов медиа
    const directories = ['images', 'videos', 'audio'];
    directories.forEach(dir => {
      const dirPath = path.join(this.publicDir, dir);
      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
      }
    });
  }
  
  // Проверяет наличие необходимых Python пакетов
  async checkDependencies(): Promise<boolean> {
    try {
      await execAsync(`${this.pythonPath} -c "import PIL, numpy, matplotlib, cv2, moviepy, pydub, gtts, speech_recognition, skimage"`);
      return true;
    } catch (error) {
      console.error('Missing dependencies:', error);
      return false;
    }
  }
  
  // Создает временный Python скрипт
  private async createPythonScript(scriptContent: string): Promise<string> {
    const timestamp = Date.now();
    const scriptPath = path.join(this.tempDir, `script_${timestamp}.py`);
    fs.writeFileSync(scriptPath, scriptContent);
    return scriptPath;
  }
  
  // Запускает Python скрипт и возвращает результат
  private async runPythonScript(scriptPath: string): Promise<string> {
    try {
      const { stdout, stderr } = await execAsync(`${this.pythonPath} ${scriptPath}`);
      if (stderr) {
        console.warn('Python script warning:', stderr);
      }
      return stdout.trim();
    } catch (error) {
      console.error('Error running Python script:', error);
      throw error;
    } finally {
      // Удаляем временный скрипт после выполнения
      fs.unlinkSync(scriptPath);
    }
  }
  
  // Преобразует текст в речь
  async textToSpeech(text: string, language: string = 'ru'): Promise<string> {
    const scriptContent = `
import os
from gtts import gTTS
import uuid

output_path = os.path.join('${this.publicDir}', 'audio', f'speech_{uuid.uuid4()}.mp3')
tts = gTTS(text='${text.replace(/'/g, "\\'")}', lang='${language}')
tts.save(output_path)
print(os.path.basename(output_path))
`;
    
    const scriptPath = await this.createPythonScript(scriptContent);
    const outputFilename = await this.runPythonScript(scriptPath);
    return `/audio/${outputFilename}`;
  }
  
  // Генерирует изображение на основе текста (используя matplotlib и numpy)
  async generateImage(prompt: string, style: string = 'default'): Promise<string> {
    // Обработка стиля
    let styleCode = '';
    
    switch (style) {
      case 'cyberpunk':
        styleCode = `plt.style.use('dark_background')
                    cmap = 'plasma'`;
        break;
      case 'watercolor':
        styleCode = `plt.style.use('seaborn-whitegrid')
                    cmap = 'cool'`;
        break;
      case 'neon':
        styleCode = `plt.style.use('dark_background')
                    cmap = 'viridis'`;
        break;
      case 'retro':
        styleCode = `plt.style.use('seaborn')
                    cmap = 'autumn'`;
        break;
      default:
        styleCode = `plt.style.use('default')
                    cmap = 'viridis'`;
    }
    
    // Генерируем случайное искусство на основе текста
    const scriptContent = `
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import hashlib
import uuid
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import colorsys

# Используем текст как сид для генерации
seed = int(hashlib.md5('${prompt.replace(/'/g, "\\'")}').hexdigest(), 16) % 10000000
np.random.seed(seed)

# Настройка стиля
${styleCode}

# Создаем случайное искусство на основе текста
def text_to_art(text, style='${style}'):
    # Преобразуем текст в числовые значения
    text_values = [ord(c) for c in text]
    text_sum = sum(text_values)
    
    # Определяем размер и формат холста
    width, height = 800, 800
    img = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Генерируем фон
    if style == 'cyberpunk':
        # Градиентный фон в кибер-стиле
        for y in range(height):
            r = int(255 * (0.5 + 0.5 * np.sin(y / 30)))
            g = int(50 * (0.5 + 0.5 * np.sin(y / 20)))
            b = int(100 + 155 * (0.5 + 0.5 * np.sin(y / 40)))
            for x in range(width):
                offset = int(30 * np.sin(x / 50) * np.cos(y / 50))
                draw.point((x, y), fill=(max(0, r - offset), max(0, g - offset), max(0, b + offset)))
    elif style == 'watercolor':
        # Акварельный эффект
        for _ in range(20):
            x0 = np.random.randint(0, width)
            y0 = np.random.randint(0, height)
            size = np.random.randint(50, 200)
            r = np.random.randint(100, 255)
            g = np.random.randint(100, 255)
            b = np.random.randint(100, 255)
            a = np.random.randint(30, 100)
            draw.ellipse((x0-size, y0-size, x0+size, y0+size), 
                          fill=(r, g, b, a))
    elif style == 'neon':
        # Неоновое свечение
        img = Image.new('RGB', (width, height), (10, 10, 30))
        draw = ImageDraw.Draw(img)
        for _ in range(15):
            x1 = np.random.randint(0, width)
            y1 = np.random.randint(0, height)
            x2 = np.random.randint(0, width)
            y2 = np.random.randint(0, height)
            r = np.random.randint(150, 255)
            g = np.random.randint(150, 255)
            b = np.random.randint(150, 255)
            width_line = np.random.randint(1, 5)
            for i in range(10):
                draw.line((x1, y1, x2, y2), fill=(r, g, b), width=width_line)
    else:  # default или retro
        # Базовый фон с градиентом
        for y in range(height):
            for x in range(width):
                h = (x / width + y / height) / 2
                s = 0.8
                v = 0.8
                r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(h, s, v)]
                draw.point((x, y), fill=(r, g, b))
    
    # Добавляем элементы на основе текста
    num_elements = len(text) * 2
    
    for i in range(num_elements):
        shape_type = i % 5
        
        # Используем символы из текста для определения цвета и позиции
        char_index = i % len(text)
        char_value = ord(text[char_index])
        
        x = (char_value * 17) % width
        y = (char_value * 19) % height
        size = 10 + (char_value % 50)
        
        # Определяем цвет на основе ASCII значения
        r = (char_value * 7) % 255
        g = (char_value * 11) % 255
        b = (char_value * 13) % 255
        
        if shape_type == 0:
            # Прямоугольник
            draw.rectangle((x, y, x + size, y + size), 
                          fill=(r, g, b, 150), 
                          outline=(255-r, 255-g, 255-b, 200))
        elif shape_type == 1:
            # Круг
            draw.ellipse((x, y, x + size, y + size), 
                        fill=(r, g, b, 150), 
                        outline=(255-r, 255-g, 255-b, 200))
        elif shape_type == 2:
            # Линия
            draw.line((x, y, x + size, y + size), 
                     fill=(r, g, b, 200), 
                     width=3)
        elif shape_type == 3:
            # Точки
            for j in range(20):
                point_x = x + np.random.randint(-size, size)
                point_y = y + np.random.randint(-size, size)
                if 0 <= point_x < width and 0 <= point_y < height:
                    draw.point((point_x, point_y), fill=(r, g, b, 200))
        else:
            # Дуга
            draw.arc((x, y, x + size, y + size), 0, 270, 
                    fill=(r, g, b, 200), width=3)
    
    # Добавляем текст промпта
    try:
        # Путь к шрифту (используем стандартный)
        try:
            font = ImageFont.truetype("Arial", 20)
        except:
            font = ImageFont.load_default()
        
        # Добавляем текст
        draw.text((width//2 - 100, height - 30), prompt[:30], fill=(255, 255, 255, 200), font=font)
    except Exception as e:
        print(f"Error rendering text: {e}")
    
    # Применяем эффекты в зависимости от стиля
    if style == 'cyberpunk':
        img = img.filter(ImageFilter.EDGE_ENHANCE_MORE)
    elif style == 'watercolor':
        img = img.filter(ImageFilter.BLUR)
        img = img.filter(ImageFilter.SMOOTH_MORE)
    elif style == 'neon':
        img = img.filter(ImageFilter.BLUR)
        img = img.filter(ImageFilter.EDGE_ENHANCE)
        img = ImageEnhance.Brightness(img).enhance(1.2)
    elif style == 'retro':
        img = img.filter(ImageFilter.CONTOUR)
        img = ImageEnhance.Color(img).enhance(0.7)
    
    return img

# Генерируем изображение
art_image = text_to_art('${prompt.replace(/'/g, "\\'")}')

# Сохраняем результат
output_filename = f'art_{uuid.uuid4()}.png'
output_path = os.path.join('${this.publicDir}', 'images', output_filename)
art_image.save(output_path)

print(output_filename)
`;
    
    const scriptPath = await this.createPythonScript(scriptContent);
    const outputFilename = await this.runPythonScript(scriptPath);
    
    return `/images/${outputFilename}`;
  }
  
  // Генерирует видео с анимированным текстом
  async generateVideoWithText(text: string, duration: number = 10, style: string = 'default'): Promise<string> {
    // Настройки стиля
    let styleCode = '';
    
    switch (style) {
      case 'cyberpunk':
        styleCode = `
        bg_color = (10, 20, 40)
        text_color = (0, 255, 255)
        font_size = 60
        `;
        break;
      case 'minimal':
        styleCode = `
        bg_color = (245, 245, 245)
        text_color = (50, 50, 50)
        font_size = 50
        `;
        break;
      case 'neon':
        styleCode = `
        bg_color = (15, 15, 30)
        text_color = (255, 50, 150)
        font_size = 65
        `;
        break;
      default:
        styleCode = `
        bg_color = (30, 30, 30)
        text_color = (240, 240, 240)
        font_size = 55
        `;
    }
    
    const scriptContent = `
import os
import numpy as np
import cv2
from moviepy.editor import VideoClip, TextClip, CompositeVideoClip, ColorClip
import tempfile
import uuid

# Настройки стиля
${styleCode}

# Размеры видео
width, height = 720, 720

def make_frame(t):
    # Создаем пустое изображение
    frame = np.zeros((height, width, 3), dtype=np.uint8)
    frame[:] = bg_color
    
    # Вычисляем положение текста в зависимости от времени
    words = "${text.replace(/'/g, "\\'")}".split()
    
    if len(words) == 0:
        return frame
        
    # Определяем сколько слов показать в момент времени t
    words_per_sec = max(1, len(words) / ${duration})
    visible_words = int(min(len(words), t * words_per_sec + 1))
    
    text_to_display = " ".join(words[:visible_words])
    
    # Размещаем текст на кадре
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1
    thickness = 2
    
    # Добавляем эффекты в зависимости от стиля
    if "${style}" == "cyberpunk":
        # Добавляем сетку в киберпанк стиле
        for i in range(0, width, 30):
            cv2.line(frame, (i, 0), (i, height), (0, 100, 100), 1)
        for i in range(0, height, 30):
            cv2.line(frame, (0, i), (width, i), (0, 100, 100), 1)
            
        # Пульсирующий эффект для текста
        pulse = abs(np.sin(t * 2))
        text_color_adjusted = (
            int(text_color[0] * (0.8 + 0.2 * pulse)),
            int(text_color[1] * (0.8 + 0.2 * pulse)),
            int(text_color[2] * (0.8 + 0.2 * pulse))
        )
        
        # Рисуем с эффектом свечения
        for offset in range(10, 0, -2):
            # Постепенно уменьшаем яркость для внешних контуров
            glow_color = (
                int(text_color_adjusted[0] * offset / 20),
                int(text_color_adjusted[1] * offset / 20),
                int(text_color_adjusted[2] * offset / 20)
            )
            for line_idx, line in enumerate(text_to_display.split('\\n')):
                text_size = cv2.getTextSize(line, font, font_scale, thickness)[0]
                x = (width - text_size[0]) // 2
                y = (height // 2) + (line_idx - len(text_to_display.split('\\n')) // 2) * 60
                cv2.putText(frame, line, (x, y), font, font_scale, glow_color, thickness + offset)
        
        # Основной текст
        for line_idx, line in enumerate(text_to_display.split('\\n')):
            text_size = cv2.getTextSize(line, font, font_scale, thickness)[0]
            x = (width - text_size[0]) // 2
            y = (height // 2) + (line_idx - len(text_to_display.split('\\n')) // 2) * 60
            cv2.putText(frame, line, (x, y), font, font_scale, text_color_adjusted, thickness)
            
    elif "${style}" == "neon":
        # Неоновый эффект
        pulse = abs(np.sin(t * 3))
        text_color_adjusted = (
            int(text_color[0] * (0.7 + 0.3 * pulse)),
            int(text_color[1] * (0.7 + 0.3 * pulse)),
            int(text_color[2] * (0.7 + 0.3 * pulse))
        )
        
        # Рисуем с неоновым свечением
        for offset in range(15, 0, -3):
            # Свечение
            glow_color = (
                int(text_color_adjusted[0] * offset / 30),
                int(text_color_adjusted[1] * offset / 30),
                int(text_color_adjusted[2] * offset / 30)
            )
            for line_idx, line in enumerate(text_to_display.split('\\n')):
                text_size = cv2.getTextSize(line, font, font_scale, thickness)[0]
                x = (width - text_size[0]) // 2
                y = (height // 2) + (line_idx - len(text_to_display.split('\\n')) // 2) * 60
                cv2.putText(frame, line, (x, y), font, font_scale, glow_color, thickness + offset)
        
        # Основной текст
        for line_idx, line in enumerate(text_to_display.split('\\n')):
            text_size = cv2.getTextSize(line, font, font_scale, thickness)[0]
            x = (width - text_size[0]) // 2
            y = (height // 2) + (line_idx - len(text_to_display.split('\\n')) // 2) * 60
            cv2.putText(frame, line, (x, y), font, font_scale, text_color_adjusted, thickness)
    
    else:  # default или minimal
        # Стандартный текст
        for line_idx, line in enumerate(text_to_display.split('\\n')):
            text_size = cv2.getTextSize(line, font, font_scale, thickness)[0]
            x = (width - text_size[0]) // 2
            y = (height // 2) + (line_idx - len(text_to_display.split('\\n')) // 2) * 60
            cv2.putText(frame, line, (x, y), font, font_scale, text_color, thickness)
    
    return frame

# Создаем видеоклип
clip = VideoClip(make_frame, duration=${duration})

# Сохраняем результат
output_filename = f'text_video_{uuid.uuid4()}.mp4'
output_path = os.path.join('${this.publicDir}', 'videos', output_filename)

# Экспортируем видео
clip.write_videofile(output_path, fps=30, codec='libx264', audio=False)

print(output_filename)
`;
    
    const scriptPath = await this.createPythonScript(scriptContent);
    const outputFilename = await this.runPythonScript(scriptPath);
    
    return `/videos/${outputFilename}`;
  }
  
  // Объединяет видео с аудио (озвучивание)
  async combineVideoWithAudio(videoPath: string, textForAudio: string, language: string = 'ru'): Promise<string> {
    // Сначала генерируем аудиофайл из текста
    const audioUrl = await this.textToSpeech(textForAudio, language);
    const audioPath = path.join(this.publicDir, audioUrl.substring(1)); // Убираем начальный слеш
    
    // Получаем путь к видеофайлу
    const fullVideoPath = path.join(this.publicDir, videoPath.substring(1)); // Убираем начальный слеш
    
    const scriptContent = `
import os
from moviepy.editor import VideoFileClip, AudioFileClip, CompositeAudioClip
import uuid

# Загружаем видео и аудио
video = VideoFileClip('${fullVideoPath.replace(/\\/g, "\\\\")}')
audio = AudioFileClip('${audioPath.replace(/\\/g, "\\\\")}')

# Обрезаем аудио до длительности видео или расширяем видео до длительности аудио
if video.duration < audio.duration:
    # Расширяем видео, зацикливая его
    video = video.loop(duration=audio.duration)
else:
    # Обрезаем аудио до длительности видео
    audio = audio.subclip(0, video.duration)

# Добавляем аудио к видео
video = video.set_audio(audio)

# Сохраняем результат
output_filename = f'combined_{uuid.uuid4()}.mp4'
output_path = os.path.join('${this.publicDir.replace(/\\/g, "\\\\")}', 'videos', output_filename)

# Экспортируем видео с аудио
video.write_videofile(output_path, codec='libx264', audio_codec='aac')

print(output_filename)
`;
    
    const scriptPath = await this.createPythonScript(scriptContent);
    const outputFilename = await this.runPythonScript(scriptPath);
    
    return `/videos/${outputFilename}`;
  }
  
  // Создает стилизованный логотип
  async generateLogo(text: string, style: string = 'minimal'): Promise<string> {
    // Настройки стиля
    let styleCode = '';
    
    switch (style) {
      case 'tech':
        styleCode = `
        bg_color = (15, 25, 40)
        text_color = (220, 240, 255)
        accent_color = (0, 180, 255)
        logo_type = 'tech'
        `;
        break;
      case 'creative':
        styleCode = `
        bg_color = (240, 245, 255)
        text_color = (60, 30, 90)
        accent_color = (190, 80, 220)
        logo_type = 'creative'
        `;
        break;
      case 'bold':
        styleCode = `
        bg_color = (255, 255, 255)
        text_color = (10, 10, 10)
        accent_color = (255, 50, 50)
        logo_type = 'bold'
        `;
        break;
      default: // minimal
        styleCode = `
        bg_color = (255, 255, 255)
        text_color = (40, 40, 40)
        accent_color = (100, 100, 240)
        logo_type = 'minimal'
        `;
    }
    
    const scriptContent = `
import os
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import uuid

# Настройки стиля
${styleCode}

# Размеры логотипа
width, height = 800, 800
center_x, center_y = width // 2, height // 2

# Создаем новое изображение
img = Image.new('RGBA', (width, height), color=(0, 0, 0, 0))
draw = ImageDraw.Draw(img)

# Функция для создания логотипа
def create_logo(text, logo_type):
    if logo_type == 'tech':
        # Технологичный логотип
        # Рисуем геометрический фон
        for i in range(10):
            r = 100 + i * 50
            thickness = max(1, 5 - i // 2)
            draw.ellipse((center_x - r, center_y - r, center_x + r, center_y + r), 
                         outline=(*accent_color, 100 - i * 10), width=thickness)
        
        # Рисуем шестиугольник
        points = []
        for i in range(6):
            angle = i * 2 * np.pi / 6
            x = center_x + 150 * np.cos(angle)
            y = center_y + 150 * np.sin(angle)
            points.append((x, y))
        
        draw.polygon(points, fill=(*bg_color, 230), outline=(*accent_color, 255), width=3)
        
        # Добавляем текст
        try:
            # Попытка использовать системный шрифт
            try:
                font = ImageFont.truetype("Arial Bold", 60)
                small_font = ImageFont.truetype("Arial", 30)
            except:
                font = ImageFont.load_default()
                small_font = ImageFont.load_default()
            
            # Разделяем текст, если в нем есть пробел
            if ' ' in text:
                main_text, sub_text = text.split(' ', 1)
            else:
                main_text, sub_text = text, "TECH"
            
            # Основной текст
            text_w, text_h = draw.textsize(main_text, font=font)
            draw.text((center_x - text_w // 2, center_y - 15), main_text, 
                     fill=(*text_color, 255), font=font)
            
            # Подтекст
            subtext_w, subtext_h = draw.textsize(sub_text, font=small_font)
            draw.text((center_x - subtext_w // 2, center_y + 50), sub_text.upper(), 
                      fill=(*accent_color, 255), font=small_font)
        except Exception as e:
            print(f"Error rendering text: {e}")
            
    elif logo_type == 'creative':
        # Креативный логотип с акварельным эффектом
        # Создаем акварельные пятна
        for _ in range(5):
            x0 = center_x + np.random.randint(-150, 150)
            y0 = center_y + np.random.randint(-150, 150)
            size = np.random.randint(100, 200)
            alpha = np.random.randint(30, 100)
            
            # Смешиваем цвета
            r = accent_color[0] + np.random.randint(-30, 30)
            g = accent_color[1] + np.random.randint(-30, 30)
            b = accent_color[2] + np.random.randint(-30, 30)
            r, g, b = min(255, max(0, r)), min(255, max(0, g)), min(255, max(0, b))
            
            draw.ellipse((x0-size, y0-size, x0+size, y0+size), 
                         fill=(r, g, b, alpha))
        
        # Добавляем текст
        try:
            # Попытка использовать системный шрифт
            try:
                font = ImageFont.truetype("Arial", 80)
            except:
                font = ImageFont.load_default()
            
            # Рисуем текст
            text_w, text_h = draw.textsize(text, font=font)
            draw.text((center_x - text_w // 2, center_y - text_h // 2), text, 
                     fill=(*text_color, 255), font=font)
            
            # Добавляем декоративную линию под текстом
            line_y = center_y + text_h // 2 + 10
            draw.line((center_x - text_w // 2, line_y, center_x + text_w // 2, line_y), 
                      fill=(*accent_color, 200), width=3)
        except Exception as e:
            print(f"Error rendering text: {e}")
    
    elif logo_type == 'bold':
        # Жирный современный логотип
        # Рисуем фоновую форму (круг)
        draw.ellipse((center_x - 200, center_y - 200, center_x + 200, center_y + 200), 
                    fill=(*accent_color, 255))
        
        # Добавляем внутренний круг
        draw.ellipse((center_x - 180, center_y - 180, center_x + 180, center_y + 180), 
                     fill=(*bg_color, 255))
        
        # Добавляем текст
        try:
            # Попытка использовать системный шрифт
            try:
                font = ImageFont.truetype("Arial Bold", 100)
            except:
                font = ImageFont.load_default()
            
            # Разделяем текст, если он длинный
            if len(text) > 10:
                parts = text.split()
                mid = len(parts) // 2
                text1 = ' '.join(parts[:mid])
                text2 = ' '.join(parts[mid:])
                
                text1_w, text1_h = draw.textsize(text1, font=font)
                text2_w, text2_h = draw.textsize(text2, font=font)
                
                draw.text((center_x - text1_w // 2, center_y - text1_h - 10), text1, 
                         fill=(*text_color, 255), font=font)
                draw.text((center_x - text2_w // 2, center_y + 10), text2, 
                         fill=(*text_color, 255), font=font)
            else:
                # Рисуем текст
                text_w, text_h = draw.textsize(text, font=font)
                draw.text((center_x - text_w // 2, center_y - text_h // 2), text, 
                         fill=(*text_color, 255), font=font)
        except Exception as e:
            print(f"Error rendering text: {e}")
    
    else:  # minimal
        # Минималистичный логотип
        # Рисуем простую рамку
        border = 10
        draw.rectangle((border, border, width - border, height - border), 
                      outline=(*accent_color, 200), width=2)
        
        # Добавляем угловой акцент
        corner_size = 50
        draw.rectangle((border, border, border + corner_size, border + corner_size), 
                      fill=(*accent_color, 100))
        draw.rectangle((width - border - corner_size, height - border - corner_size, 
                        width - border, height - border), 
                      fill=(*accent_color, 100))
        
        # Добавляем текст
        try:
            # Попытка использовать системный шрифт
            try:
                font = ImageFont.truetype("Arial", 70)
                small_font = ImageFont.truetype("Arial", 25)
            except:
                font = ImageFont.load_default()
                small_font = ImageFont.load_default()
            
            # Основной текст
            text_w, text_h = draw.textsize(text, font=font)
            draw.text((center_x - text_w // 2, center_y - text_h // 2), text, 
                     fill=(*text_color, 255), font=font)
            
            # Добавляем слоган
            slogan = "ESTABLISHED 2025"
            slogan_w, slogan_h = draw.textsize(slogan, font=small_font)
            draw.text((center_x - slogan_w // 2, center_y + text_h // 2 + 20), slogan, 
                     fill=(*accent_color, 200), font=small_font)
        except Exception as e:
            print(f"Error rendering text: {e}")
    
    return img

# Генерируем логотип
logo = create_logo('${text.replace(/'/g, "\\'")}', logo_type)

# Сохраняем результат
output_filename = f'logo_{uuid.uuid4()}.png'
output_path = os.path.join('${this.publicDir.replace(/\\/g, "\\\\")}', 'images', output_filename)
logo.save(output_path)

print(output_filename)
`;
    
    const scriptPath = await this.createPythonScript(scriptContent);
    const outputFilename = await this.runPythonScript(scriptPath);
    
    return `/images/${outputFilename}`;
  }
  
  // Применяет фильтр к загруженному изображению
  async applyImageFilter(imagePath: string, filter: string = 'enhance'): Promise<string> {
    const fullImagePath = path.join(__dirname, '..', imagePath.startsWith('/') ? imagePath.substring(1) : imagePath);
    
    const scriptContent = `
import os
import numpy as np
import cv2
from PIL import Image, ImageFilter, ImageEnhance, ImageOps
import uuid

# Загружаем изображение
try:
    image = Image.open('${fullImagePath.replace(/\\/g, "\\\\")}')
except Exception as e:
    print(f"Error opening image: {e}")
    exit(1)

# Применяем фильтр
if '${filter}' == 'enhance':
    # Улучшаем контраст и резкость
    image = ImageEnhance.Contrast(image).enhance(1.3)
    image = ImageEnhance.Sharpness(image).enhance(1.5)
    image = ImageEnhance.Color(image).enhance(1.2)
elif '${filter}' == 'blackwhite':
    # Черно-белый эффект
    image = image.convert('L')
    image = ImageOps.autocontrast(image, cutoff=0.5)
    image = ImageOps.colorize(image, black=(0, 0, 0), white=(255, 255, 255))
elif '${filter}' == 'vintage':
    # Винтажный эффект
    image = ImageEnhance.Color(image).enhance(0.6)
    image = ImageEnhance.Contrast(image).enhance(0.8)
    image = ImageOps.colorize(image.convert('L'), 
                              black=(60, 30, 15), 
                              white=(210, 200, 180))
elif '${filter}' == 'cyberpunk':
    # Киберпанк эффект
    # Конвертируем в numpy для обработки OpenCV
    img_array = np.array(image)
    
    # Разделяем каналы
    b, g, r = cv2.split(img_array)
    
    # Увеличиваем синий и пурпурный цвета
    b = cv2.add(b, 30)
    r = cv2.add(r, 20)
    
    # Объединяем каналы
    img_array = cv2.merge((b, g, r))
    
    # Повышаем контраст
    img_array = cv2.addWeighted(img_array, 1.2, img_array, 0, 10)
    
    # Возвращаем в формат PIL
    image = Image.fromarray(img_array)
    
    # Добавляем эффекты постобработки
    image = image.filter(ImageFilter.EDGE_ENHANCE_MORE)
    image = ImageEnhance.Contrast(image).enhance(1.1)
elif '${filter}' == 'blur':
    # Эффект размытия
    image = image.filter(ImageFilter.GaussianBlur(radius=5))
elif '${filter}' == 'sharpen':
    # Эффект повышения резкости
    image = image.filter(ImageFilter.SHARPEN)
    image = image.filter(ImageFilter.SHARPEN)
else:
    # Базовые улучшения по умолчанию
    image = ImageEnhance.Contrast(image).enhance(1.1)
    image = ImageEnhance.Brightness(image).enhance(1.05)

# Сохраняем результат
output_filename = f'filtered_{uuid.uuid4()}.png'
output_path = os.path.join('${this.publicDir.replace(/\\/g, "\\\\")}', 'images', output_filename)
image.save(output_path)

print(output_filename)
`;
    
    const scriptPath = await this.createPythonScript(scriptContent);
    const outputFilename = await this.runPythonScript(scriptPath);
    
    return `/images/${outputFilename}`;
  }
}

// Создаем экземпляр процессора медиаконтента
const mediaProcessor = new MediaProcessor();

// Настройка маршрутов для медиа-сервиса
export async function setupMediaRoutes(app: Express) {
  // Создаем директории, если их нет
  const publicDir = path.join(__dirname, '../public');
  const directories = ['images', 'videos', 'audio', 'uploads'];
  
  directories.forEach(dir => {
    const dirPath = path.join(publicDir, dir);
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
  });
  
  // Статические файлы (примечание: основные статические пути определены в routes.ts)
  
  // Проверяем наличие Python зависимостей
  app.get('/api/media/check-dependencies', async (req: Request, res: Response) => {
    try {
      const result = await mediaProcessor.checkDependencies();
      res.json({ success: result });
    } catch (error) {
      res.status(500).json({ error: 'Failed to check dependencies' });
    }
  });
  
  // Генерация речи из текста
  app.post('/api/media/text-to-speech', async (req: Request, res: Response) => {
    try {
      const { text, language } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }
      
      const audioUrl = await mediaProcessor.textToSpeech(text, language || 'ru');
      res.json({ url: audioUrl });
    } catch (error) {
      console.error('Error in text-to-speech:', error);
      res.status(500).json({ error: 'Failed to generate speech' });
    }
  });
  
  // Генерация изображения на основе текста
  app.post('/api/media/generate-image', async (req: Request, res: Response) => {
    try {
      const { prompt, style } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }
      
      const imageUrl = await mediaProcessor.generateImage(prompt, style);
      res.json({ url: imageUrl });
    } catch (error) {
      console.error('Error in generate-image:', error);
      res.status(500).json({ error: 'Failed to generate image' });
    }
  });
  
  // Генерация видео с текстом
  app.post('/api/media/generate-video', async (req: Request, res: Response) => {
    try {
      const { text, duration, style } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }
      
      const videoUrl = await mediaProcessor.generateVideoWithText(
        text, 
        duration || 10, 
        style || 'default'
      );
      
      res.json({ url: videoUrl });
    } catch (error) {
      console.error('Error in generate-video:', error);
      res.status(500).json({ error: 'Failed to generate video' });
    }
  });
  
  // Добавление аудио к видео
  app.post('/api/media/combine-video-audio', async (req: Request, res: Response) => {
    try {
      const { videoUrl, text, language } = req.body;
      
      if (!videoUrl || !text) {
        return res.status(400).json({ error: 'Video URL and text are required' });
      }
      
      const combinedUrl = await mediaProcessor.combineVideoWithAudio(
        videoUrl, 
        text, 
        language || 'ru'
      );
      
      res.json({ url: combinedUrl });
    } catch (error) {
      console.error('Error in combine-video-audio:', error);
      res.status(500).json({ error: 'Failed to combine video and audio' });
    }
  });
  
  // Генерация логотипа
  app.post('/api/media/generate-logo', async (req: Request, res: Response) => {
    try {
      const { text, style } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: 'Text is required' });
      }
      
      const logoUrl = await mediaProcessor.generateLogo(text, style);
      res.json({ url: logoUrl });
    } catch (error) {
      console.error('Error in generate-logo:', error);
      res.status(500).json({ error: 'Failed to generate logo' });
    }
  });
  
  // Применение фильтра к изображению
  app.post('/api/media/apply-filter', upload.single('image'), async (req: Request, res: Response) => {
    try {
      let imagePath: string;
      
      if (req.file) {
        // Если загружен файл
        imagePath = path.relative(__dirname, req.file.path);
      } else if (req.body.imageUrl) {
        // Если передан URL
        imagePath = req.body.imageUrl;
      } else {
        return res.status(400).json({ error: 'Image file or URL is required' });
      }
      
      const filter = req.body.filter || 'enhance';
      
      const filteredUrl = await mediaProcessor.applyImageFilter(imagePath, filter);
      res.json({ url: filteredUrl });
    } catch (error) {
      console.error('Error in apply-filter:', error);
      res.status(500).json({ error: 'Failed to apply filter' });
    }
  });
}