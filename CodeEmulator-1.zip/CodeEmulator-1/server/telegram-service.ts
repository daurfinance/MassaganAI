/**
 * MassaganAI: Сервис для интеграции с Telegram ботом
 * Поддерживает отправку медиаконтента и получение сообщений от пользователей
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import TelegramBot from 'node-telegram-bot-api';
import { Express } from 'express';
import * as fs from 'fs';
import * as path from 'path';
import * as url from 'url';
import { fileURLToPath } from 'url';
import fetch from 'node-fetch';

// ESM модуль не имеет доступа к __dirname, поэтому мы создаем его вручную
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Интервал очистки файлов в миллисекундах (по умолчанию 24 часа)
const CLEANUP_INTERVAL = 24 * 60 * 60 * 1000;

// Срок жизни файлов в миллисекундах (по умолчанию 48 часов)
const FILE_TTL = 48 * 60 * 60 * 1000;

// Получаем токен бота из переменных окружения
const token = process.env.TELEGRAM_BOT_TOKEN;

// Создаем экземпляр бота
let bot: TelegramBot | null = null;

// Статус задачи
type TaskStatus = 'pending' | 'processing' | 'completed' | 'failed';

// Тип задачи
type TaskType = 'image' | 'video' | 'audio' | 'logo' | 'code' | 'ai';

// Интерфейс задачи для отслеживания прогресса
interface TaskProgress {
  id: string;
  chatId: number;
  taskType: TaskType;
  prompt: string;
  status: TaskStatus;
  progress: number; // от 0 до 100
  startTime: Date;
  estimatedCompletionTime: Date;
  completionTime?: Date;
  messageId?: number; // ID сообщения с прогрессом
  resultMessageId?: number; // ID сообщения с результатом
  resultPath?: string; // Путь к результату
}

// Храним информацию о чатах для отправки уведомлений
interface TelegramChat {
  id: number;
  username?: string;
  firstName?: string;
  lastName?: string;
  registeredAt: Date;
  lastActive: Date;
  userRequests?: string[]; // История запросов пользователя для самообучения
  aiPreferences?: {
    preferredStyle?: string;
    preferredLanguage?: string;
    preferredTopics?: string[];
    favorite_models?: string[];
  }; // Предпочтения пользователя для самообучения
  activeTasks?: Map<string, TaskProgress>; // Активные задачи пользователя
}

// Локальное хранилище чатов, впоследствии можно перенести в базу данных
const activeChats: Map<number, TelegramChat> = new Map();

/**
 * Инициализирует Telegram бота
 */
function initTelegramBot() {
  if (!token) {
    console.warn('TELEGRAM_BOT_TOKEN not set, Telegram bot is disabled');
    return null;
  }

  try {
    // Создаем бота с поддержкой polling для получения сообщений
    const newBot = new TelegramBot(token, { polling: true });
    
    console.log('Telegram bot started successfully');
    
    // Обработчик команды /start
    newBot.onText(/\/start/, (msg) => {
      const chatId = msg.chat.id;
      const username = msg.from?.username;
      const firstName = msg.from?.first_name;
      const lastName = msg.from?.last_name;
      
      // Добавляем чат в список активных
      activeChats.set(chatId, {
        id: chatId,
        username,
        firstName,
        lastName,
        registeredAt: new Date(),
        lastActive: new Date()
      });
      
      const welcomeMessage = `👋 Привет${firstName ? ", " + firstName : ""}! Я MassaganAI бот.

🚀 Я могу помочь Вам с:
• Генерацией изображений по текстовому описанию
• Созданием анимированных видео из текста
• Озвучиванием текста реалистичным голосом
• Созданием логотипов
• Обработкой фото и видео с различными эффектами

💡 Выберите действие с помощью кнопок ниже или опишите, что вы хотите сделать в обычном сообщении.
      
🔄 Для получения справки введите команду /help`;
      
      // Создаем клавиатуру с кнопками - убедимся, что она всегда доступна
      const keyboard = {
        reply_markup: {
          keyboard: [
            ['🖼️ Создать изображение', '🎬 Создать видео'],
            ['🔊 Озвучить текст', '🎨 Создать логотип'],
            ['🧠 ИИ-эмулятор', '💻 Улучшить код'],
            ['📊 Статус сервиса', '❓ Помощь']
          ],
          resize_keyboard: true,
          persistent: true, // Указываем, что клавиатура должна быть постоянной
          one_time_keyboard: false // Отключаем одноразовую клавиатуру
        }
      };
      
      newBot.sendMessage(chatId, welcomeMessage, keyboard);
    });
    
    // Обработчик команды /help
    newBot.onText(/\/help/, (msg) => {
      const chatId = msg.chat.id;
      updateLastActive(chatId);
      
      const helpMessage = `📚 Справка по командам MassaganAI:

🖼️ Генерация изображений:
• Отправьте текст: "Создай изображение: [описание]"
• Например: "Создай изображение: снежный барс на фоне гор Алматы в стиле Cyberpunk"

🎬 Создание видео:
• Отправьте текст: "Создай видео: [текст для видео]"
• Например: "Создай видео: История Казахстана кратко"

🔊 Озвучивание текста:
• Отправьте текст: "Озвучь: [текст для озвучивания]"
• Например: "Озвучь: Добро пожаловать в Казахстан, страну великих степей"

🎨 Создание логотипа:
• Отправьте текст: "Создай логотип: [название]"
• Например: "Создай логотип: TechNomad"

⚙️ Обработка изображений:
• Отправьте изображение с текстом: "[эффект]"
• Доступные эффекты: enhance, blackwhite, vintage, cyberpunk, blur, sharpen

📋 Общая информация:
• /start - начало работы с ботом
• /help - эта справка
• /status - проверить статус сервиса`;
      
      newBot.sendMessage(chatId, helpMessage);
    });
    
    // Обработчик команды /status
    newBot.onText(/\/status/, (msg) => {
      const chatId = msg.chat.id;
      updateLastActive(chatId);
      
      const statusMessage = `✅ Сервис MassaganAI работает нормально

📊 Статистика:
• 🌐 Активных пользователей: ${activeChats.size}
• 🏅 Версия: 1.0.0
• 🔧 Статус сервера: Online

⚙️ Доступные сервисы:
• ✅ Генерация изображений
• ✅ Создание видео
• ✅ Озвучивание текста
• ✅ Создание логотипов
• ✅ Обработка изображений`;
      
      newBot.sendMessage(chatId, statusMessage);
    });
    
    // Обработчик текстовых сообщений для определения типа запроса
    newBot.on('message', (msg) => {
      if (!msg.text || msg.text.startsWith('/')) return;
      
      const chatId = msg.chat.id;
      updateLastActive(chatId);
      
      // Сохраняем запрос пользователя для самообучения, если это не команда кнопки
      const chat = activeChats.get(chatId);
      if (chat && !msg.text.startsWith('🖼️') && !msg.text.startsWith('🎬') && 
          !msg.text.startsWith('🔊') && !msg.text.startsWith('🎨') && 
          !msg.text.startsWith('🧠') && !msg.text.startsWith('💻') && 
          !msg.text.startsWith('📊') && !msg.text.startsWith('❓')) {
        
        // Инициализируем массив запросов, если его еще нет
        if (!chat.userRequests) {
          chat.userRequests = [];
        }
        
        // Добавляем текущий запрос в историю
        chat.userRequests.push(msg.text);
        
        // Ограничиваем историю последними 10 запросами
        if (chat.userRequests.length > 10) {
          chat.userRequests = chat.userRequests.slice(-10);
        }
        
        // Обновляем информацию в хранилище
        activeChats.set(chatId, chat);
      }
      
      // Обработка кнопок главного меню
      if (msg.text === '🖼️ Создать изображение') {
        // Отправляем сообщение с запросом на ввод описания
        const replyMarkup = {
          reply_markup: {
            force_reply: true,
            input_field_placeholder: 'Опишите изображение, которое хотите создать'
          }
        };
        newBot.sendMessage(chatId, '✏️ Опишите изображение, которое вы хотите создать:', replyMarkup);
        return;
      }
      
      if (msg.text === '🎬 Создать видео') {
        // Отправляем сообщение с запросом на ввод текста для видео
        const replyMarkup = {
          reply_markup: {
            force_reply: true,
            input_field_placeholder: 'Введите текст для создания видео'
          }
        };
        newBot.sendMessage(chatId, '✏️ Введите текст для создания видео:', replyMarkup);
        return;
      }
      
      if (msg.text === '🔊 Озвучить текст') {
        // Отправляем сообщение с запросом на ввод текста для озвучивания
        const replyMarkup = {
          reply_markup: {
            force_reply: true,
            input_field_placeholder: 'Введите текст для озвучивания'
          }
        };
        newBot.sendMessage(chatId, '✏️ Введите текст для озвучивания:', replyMarkup);
        return;
      }
      
      if (msg.text === '🎨 Создать логотип') {
        // Отправляем сообщение с запросом на ввод названия для логотипа
        const replyMarkup = {
          reply_markup: {
            force_reply: true,
            input_field_placeholder: 'Введите название для логотипа'
          }
        };
        newBot.sendMessage(chatId, '✏️ Введите название для создания логотипа:', replyMarkup);
        return;
      }
      
      if (msg.text === '🧠 ИИ-эмулятор') {
        // Отправляем сообщение для ИИ-эмулятора
        const inlineKeyboard = {
          reply_markup: {
            inline_keyboard: [
              [
                { text: '🤖 GPT-4o', callback_data: 'model_gpt4o' },
                { text: '🦙 Claude 3.5', callback_data: 'model_claude35' }
              ],
              [
                { text: '🧙‍♂️ Смарт-ассистент', callback_data: 'model_perplexity' },
                { text: '🌐 Веб-поиск', callback_data: 'model_webSearch' }
              ]
            ]
          }
        };
        
        newBot.sendMessage(chatId, '🧠 Выберите модель ИИ для взаимодействия:', inlineKeyboard);
        return;
      }
      
      if (msg.text === '💻 Улучшить код') {
        // Отправляем сообщение для улучшения кода
        const replyMarkup = {
          reply_markup: {
            force_reply: true,
            input_field_placeholder: 'Вставьте код для улучшения'
          }
        };
        newBot.sendMessage(chatId, '💻 Пожалуйста, отправьте код, который нужно улучшить:', replyMarkup);
        return;
      }
      
      if (msg.text === '📊 Статус сервиса') {
        // Вызываем команду статуса
        const statusMessage = `✅ Сервис MassaganAI работает нормально

📊 Статистика:
• 🌐 Активных пользователей: ${activeChats.size}
• 🏅 Версия: 1.0.0
• 🔧 Статус сервера: Online

⚙️ Доступные сервисы:
• ✅ Генерация изображений 
• ✅ Создание видео
• ✅ Озвучивание текста
• ✅ Создание логотипов
• ✅ Обработка изображений
• ✅ ИИ-эмулятор
• ✅ Улучшение кода`;
        
        newBot.sendMessage(chatId, statusMessage);
        return;
      }
      
      if (msg.text === '❓ Помощь') {
        // Вызываем команду помощи
        const helpMessage = `📚 Справка по командам MassaganAI:

🖼️ Генерация изображений:
• Нажмите кнопку "🖼️ Создать изображение" или введите "Создай изображение: [описание]"
• Например: "Создай изображение: снежный барс на фоне гор Алматы в стиле Cyberpunk"

🎬 Создание видео:
• Нажмите кнопку "🎬 Создать видео" или введите "Создай видео: [текст для видео]"
• Например: "Создай видео: История Казахстана кратко"

🔊 Озвучивание текста:
• Нажмите кнопку "🔊 Озвучить текст" или введите "Озвучь: [текст для озвучивания]"
• Например: "Озвучь: Добро пожаловать в Казахстан, страну великих степей"

🎨 Создание логотипа:
• Нажмите кнопку "🎨 Создать логотип" или введите "Создай логотип: [название]"
• Например: "Создай логотип: TechNomad"

🧠 ИИ-эмулятор:
• Нажмите кнопку "🧠 ИИ-эмулятор" и выберите модель для взаимодействия
• В режиме ИИ-эмулятора вы можете общаться с выбранной моделью напрямую

💻 Улучшение кода:
• Нажмите кнопку "💻 Улучшить код" и отправьте код для анализа и улучшения

⚙️ Обработка изображений:
• Отправьте изображение с подписью, указав желаемый эффект
• Доступные эффекты: enhance, blackwhite, vintage, cyberpunk, blur, sharpen

📋 Общая информация:
• /start - начало работы с ботом
• /help - эта справка
• /status - проверить статус сервиса`;
        
        newBot.sendMessage(chatId, helpMessage);
        return;
      }
      
      // Обрабатываем запрос на генерацию изображения
      if (msg.text.toLowerCase().startsWith('создай изображение:') || 
          msg.text.toLowerCase().startsWith('сгенерируй изображение:') ||
          msg.text.toLowerCase().startsWith('сгенерируй картинку:') ||
          msg.text.toLowerCase().startsWith('создай картинку:')) {
        const prompt = msg.text.split(':', 2)[1].trim();
        
        // Отправляем подтверждение
        newBot.sendMessage(chatId, `🖼️ Генерирую изображение по запросу: "${prompt}"... Пожалуйста, подождите.`);
        
        // Сообщаем в консоль для отладки
        console.log(`Received image generation request from ${chatId}: ${prompt}`);
        
        // Создаем запрос к API для генерации изображения
        fetch('http://localhost:5000/api/media/generate-image', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            prompt: prompt,
            style: 'default'
          })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success && data.imagePath) {
            // Отправляем изображение пользователю в Telegram
            sendImageToTelegram(chatId, data.imagePath, `🖼️ Изображение по запросу: "${prompt}"`);
          } else {
            newBot.sendMessage(chatId, `❌ Не удалось сгенерировать изображение. Пожалуйста, попробуйте другой запрос.`);
          }
        })
        .catch(error => {
          console.error('Error generating image:', error);
          newBot.sendMessage(chatId, `❌ Произошла ошибка при генерации изображения. Пожалуйста, попробуйте позже.`);
        });
      }
      
      // Обрабатываем запрос на создание видео
      else if (msg.text.toLowerCase().startsWith('создай видео:') || 
               msg.text.toLowerCase().startsWith('сгенерируй видео:')) {
        const prompt = msg.text.split(':', 2)[1].trim();
        
        // Отправляем подтверждение
        newBot.sendMessage(chatId, `🎬 Создаю видео с текстом: "${prompt}"... Пожалуйста, подождите, это может занять некоторое время.`);
        
        // Сообщаем в консоль для отладки
        console.log(`Received video generation request from ${chatId}: ${prompt}`);
        
        // Создаем запрос к API для генерации видео
        fetch('http://localhost:5000/api/media/generate-video', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text: prompt,
            duration: 10, // 10 секунд по умолчанию
            style: 'default'
          })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success && data.videoPath) {
            // Отправляем видео пользователю в Telegram
            sendVideoToTelegram(chatId, data.videoPath, `🎬 Видео по запросу: "${prompt}"`);
          } else {
            newBot.sendMessage(chatId, `❌ Не удалось сгенерировать видео. Пожалуйста, попробуйте другой запрос.`);
          }
        })
        .catch(error => {
          console.error('Error generating video:', error);
          newBot.sendMessage(chatId, `❌ Произошла ошибка при генерации видео. Пожалуйста, попробуйте позже.`);
        });
      }
      
      // Обрабатываем запрос на озвучивание текста
      else if (msg.text.toLowerCase().startsWith('озвучь:')) {
        const text = msg.text.split(':', 2)[1].trim();
        
        // Отправляем подтверждение
        newBot.sendMessage(chatId, `🔊 Озвучиваю текст: "${text}"... Пожалуйста, подождите.`);
        
        // Сообщаем в консоль для отладки
        console.log(`Received text-to-speech request from ${chatId}: ${text}`);
        
        // Создаем запрос к API для озвучивания текста
        fetch('http://localhost:5000/api/media/text-to-speech', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text: text,
            language: 'ru'
          })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success && data.audioPath) {
            // Отправляем аудиофайл пользователю в Telegram
            sendAudioToTelegram(chatId, data.audioPath, `🔊 Озвучка текста: "${text}"`);
          } else {
            newBot.sendMessage(chatId, `❌ Не удалось озвучить текст. Пожалуйста, попробуйте другой текст.`);
          }
        })
        .catch(error => {
          console.error('Error generating speech:', error);
          newBot.sendMessage(chatId, `❌ Произошла ошибка при озвучивании текста. Пожалуйста, попробуйте позже.`);
        });
      }
      
      // Обрабатываем запрос на создание логотипа
      else if (msg.text.toLowerCase().startsWith('создай логотип:') || 
               msg.text.toLowerCase().startsWith('сгенерируй логотип:')) {
        const name = msg.text.split(':', 2)[1].trim();
        
        // Отправляем подтверждение
        newBot.sendMessage(chatId, `🎨 Создаю логотип для: "${name}"... Пожалуйста, подождите.`);
        
        // Сообщаем в консоль для отладки
        console.log(`Received logo generation request from ${chatId}: ${name}`);
        
        // Создаем запрос к API для генерации логотипа
        fetch('http://localhost:5000/api/media/generate-logo', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text: name,
            style: 'minimal'
          })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success && data.logoPath) {
            // Отправляем изображение логотипа пользователю в Telegram
            sendImageToTelegram(chatId, data.logoPath, `🎨 Логотип для: "${name}"`);
          } else {
            newBot.sendMessage(chatId, `❌ Не удалось создать логотип. Пожалуйста, попробуйте другое название.`);
          }
        })
        .catch(error => {
          console.error('Error generating logo:', error);
          newBot.sendMessage(chatId, `❌ Произошла ошибка при создании логотипа. Пожалуйста, попробуйте позже.`);
        });
      }
      
      // Анализируем контекст предыдущих сообщений для умного ответа
      else if (chat && chat.userRequests && chat.userRequests.length > 0) {
        // Проверяем, если это ответ на предыдущий запрос
        if (msg.reply_to_message) {
          const originalMessage = msg.reply_to_message.text;
          
          if (originalMessage?.includes('Опишите изображение')) {
            // Запрос на создание изображения
            const prompt = msg.text;
            newBot.sendMessage(chatId, `🖼️ Генерирую изображение по запросу: "${prompt}"... Пожалуйста, подождите.`);
            console.log(`Received image generation request from ${chatId}: ${prompt}`);
            
            // Отправляем запрос на генерацию
            fetch('http://localhost:5000/api/media/generate-image', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                prompt: prompt,
                style: 'default'
              })
            })
            .then(response => response.json())
            .then(data => {
              if (data.success && data.imagePath) {
                // Отправляем изображение пользователю в Telegram
                sendImageToTelegram(chatId, data.imagePath, `🖼️ Изображение по запросу: "${prompt}"`);
              } else {
                newBot.sendMessage(chatId, `❌ Не удалось сгенерировать изображение. Пожалуйста, попробуйте другой запрос.`);
              }
            })
            .catch(error => {
              console.error('Error generating image:', error);
              newBot.sendMessage(chatId, `❌ Произошла ошибка при генерации изображения. Пожалуйста, попробуйте позже.`);
            });
          }
          else if (originalMessage?.includes('Введите текст для создания видео')) {
            // Запрос на создание видео
            const prompt = msg.text;
            newBot.sendMessage(chatId, `🎬 Создаю видео с текстом: "${prompt}"... Пожалуйста, подождите, это может занять некоторое время.`);
            console.log(`Received video generation request from ${chatId}: ${prompt}`);
            
            // Отправляем запрос на генерацию
            fetch('http://localhost:5000/api/media/generate-video', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                text: prompt,
                duration: 10, // 10 секунд по умолчанию
                style: 'default'
              })
            })
            .then(response => response.json())
            .then(data => {
              if (data.success && data.videoPath) {
                // Отправляем видео пользователю в Telegram
                sendVideoToTelegram(chatId, data.videoPath, `🎬 Видео по запросу: "${prompt}"`);
              } else {
                newBot.sendMessage(chatId, `❌ Не удалось сгенерировать видео. Пожалуйста, попробуйте другой запрос.`);
              }
            })
            .catch(error => {
              console.error('Error generating video:', error);
              newBot.sendMessage(chatId, `❌ Произошла ошибка при генерации видео. Пожалуйста, попробуйте позже.`);
            });
          }
          else if (originalMessage?.includes('Введите текст для озвучивания')) {
            // Запрос на озвучивание текста
            const text = msg.text;
            newBot.sendMessage(chatId, `🔊 Озвучиваю текст: "${text}"... Пожалуйста, подождите.`);
            console.log(`Received text-to-speech request from ${chatId}: ${text}`);
            
            // Отправляем запрос на озвучивание
            fetch('http://localhost:5000/api/media/text-to-speech', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                text: text,
                language: 'ru'
              })
            })
            .then(response => response.json())
            .then(data => {
              if (data.success && data.audioPath) {
                // Отправляем аудиофайл пользователю в Telegram
                sendAudioToTelegram(chatId, data.audioPath, `🔊 Озвучка текста: "${text}"`);
              } else {
                newBot.sendMessage(chatId, `❌ Не удалось озвучить текст. Пожалуйста, попробуйте другой текст.`);
              }
            })
            .catch(error => {
              console.error('Error generating speech:', error);
              newBot.sendMessage(chatId, `❌ Произошла ошибка при озвучивании текста. Пожалуйста, попробуйте позже.`);
            });
          }
          else if (originalMessage?.includes('Введите название для создания логотипа')) {
            // Запрос на создание логотипа
            const name = msg.text;
            newBot.sendMessage(chatId, `🎨 Создаю логотип для: "${name}"... Пожалуйста, подождите.`);
            console.log(`Received logo generation request from ${chatId}: ${name}`);
            
            // Отправляем запрос на генерацию логотипа
            fetch('http://localhost:5000/api/media/generate-logo', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                text: name,
                style: 'minimal'
              })
            })
            .then(response => response.json())
            .then(data => {
              if (data.success && data.logoPath) {
                // Отправляем изображение логотипа пользователю в Telegram
                sendImageToTelegram(chatId, data.logoPath, `🎨 Логотип для: "${name}"`);
              } else {
                newBot.sendMessage(chatId, `❌ Не удалось создать логотип. Пожалуйста, попробуйте другое название.`);
              }
            })
            .catch(error => {
              console.error('Error generating logo:', error);
              newBot.sendMessage(chatId, `❌ Произошла ошибка при создании логотипа. Пожалуйста, попробуйте позже.`);
            });
          }
          else if (originalMessage?.includes('отправьте код')) {
            // Улучшение кода
            const code = msg.text;
            newBot.sendMessage(chatId, `💻 Анализирую код и ищу возможности для улучшения... Пожалуйста, подождите.`);
            console.log(`Received code improvement request from ${chatId}: ${code.substring(0, 50)}...`);
            
            // Отправляем запрос на улучшение кода
            fetch('http://localhost:5000/api/ai/analyze', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                jsCode: code
              })
            })
            .then(response => response.json())
            .then(data => {
              if (data && data.improved_code) {
                // Отправляем улучшенный код и анализ
                newBot.sendMessage(chatId, `✅ Результат анализа кода:\n\n${data.analysis}`, { parse_mode: 'Markdown' });
                // Отправляем улучшенный код как документ
                const tempFilePath = path.join(__dirname, '..', 'temp', `improved_code_${chatId}_${Date.now()}.js`);
                fs.writeFileSync(tempFilePath, data.improved_code);
                bot.sendDocument(chatId, tempFilePath, { caption: '💻 Улучшенный код' });
              } else {
                newBot.sendMessage(chatId, `❌ Не удалось улучшить код. Возможно, код не требует улучшений или используется неподдерживаемый язык.`);
              }
            })
            .catch(error => {
              console.error('Error improving code:', error);
              newBot.sendMessage(chatId, `❌ Произошла ошибка при анализе кода. Пожалуйста, попробуйте позже.`);
            });
          }
          else if (originalMessage?.includes('Задайте вопрос для')) {
            // Обработка запроса к ИИ-модели
            const aiQuestion = msg.text;
            const modelMatch = originalMessage.match(/Вы выбрали модель \*(.*?)\*/);
            const modelName = modelMatch ? modelMatch[1] : 'AI';
            
            newBot.sendMessage(chatId, `🧠 Обрабатываю ваш запрос в ${modelName}... Пожалуйста, подождите.`);
            
            // Определяем, какой API использовать на основе выбранной модели
            let apiEndpoint = '';
            let requestBody = {};
            
            // Настраиваем запрос в зависимости от модели
            if (modelName.includes('GPT') || modelName.includes('Openai')) {
              apiEndpoint = 'http://localhost:5000/api/ai/openai-query';
              requestBody = {
                prompt: aiQuestion,
                model: 'gpt-4o'
              };
            } else if (modelName.includes('Claude')) {
              apiEndpoint = 'http://localhost:5000/api/ai/anthropic-query';
              requestBody = {
                prompt: aiQuestion,
                model: 'claude-3.5-sonnet'
              };
            } else if (modelName.includes('Perplexity')) {
              apiEndpoint = 'http://localhost:5000/api/ai/perplexity-query';
              requestBody = {
                prompt: aiQuestion,
                model: 'llama-3.1-sonar-small-128k-online'
              };
            } else {
              // Если модель не определена, используем Perplexity по умолчанию
              apiEndpoint = 'http://localhost:5000/api/ai/perplexity-query';
              requestBody = {
                prompt: aiQuestion,
                model: 'llama-3.1-sonar-small-128k-online'
              };
            }
            
            // Отправляем запрос к выбранной модели ИИ
            fetch(apiEndpoint, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(requestBody)
            })
            .then(response => response.json())
            .then(data => {
              if (data && data.response) {
                // Отправляем ответ от ИИ с разбивкой на сообщения, если он слишком длинный
                const maxLength = 4000; // Максимальная длина сообщения в Telegram
                const response = data.response;
                
                if (response.length <= maxLength) {
                  newBot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
                } else {
                  // Разбиваем длинный ответ на части
                  for (let i = 0; i < response.length; i += maxLength) {
                    const part = response.substring(i, i + maxLength);
                    newBot.sendMessage(chatId, part, { parse_mode: 'Markdown' });
                  }
                }
              } else {
                newBot.sendMessage(chatId, `❌ Не удалось получить ответ от модели ${modelName}. Пожалуйста, попробуйте другой вопрос.`);
              }
            })
            .catch(error => {
              console.error(`Error getting response from ${modelName}:`, error);
              newBot.sendMessage(chatId, `❌ Произошла ошибка при обработке запроса в ${modelName}. Пожалуйста, попробуйте позже.`);
            });
          }
          return;
        }
        
        // Иначе даем интеллектуальный ответ на основе истории запросов
        newBot.sendMessage(chatId, 
          `Я получил ваше сообщение. Выберите действие с помощью кнопок или используйте один из следующих форматов команд:
          
🖼️ "Создай изображение: [описание]"
🎬 "Создай видео: [текст для видео]"
🔊 "Озвучь: [текст для озвучивания]"
🎨 "Создай логотип: [название]"

Или нажмите "❓ Помощь" для получения справки.`);
      }
      
      // Общий запрос
      else {
        newBot.sendMessage(chatId, 
          `Я получил ваше сообщение. Выберите действие с помощью кнопок или используйте один из следующих форматов команд:
          
🖼️ "Создай изображение: [описание]"
🎬 "Создай видео: [текст для видео]"
🔊 "Озвучь: [текст для озвучивания]"
🎨 "Создай логотип: [название]"

Или нажмите "❓ Помощь" для получения справки.`);
      }
    });
    
    // Обработчик фото с подписью для применения фильтров
    newBot.on('photo', (msg) => {
      if (!msg.caption) {
        newBot.sendMessage(msg.chat.id, 'Пожалуйста, добавьте подпись к фотографии, указав желаемый эффект: enhance, blackwhite, vintage, cyberpunk, blur, sharpen');
        return;
      }
      
      const chatId = msg.chat.id;
      updateLastActive(chatId);
      
      const effect = msg.caption.toLowerCase().trim();
      const validEffects = ['enhance', 'blackwhite', 'vintage', 'cyberpunk', 'blur', 'sharpen'];
      
      if (!validEffects.includes(effect)) {
        newBot.sendMessage(chatId, `Неизвестный эффект: "${effect}". Доступные эффекты: enhance, blackwhite, vintage, cyberpunk, blur, sharpen`);
        return;
      }
      
      newBot.sendMessage(chatId, `🖌️ Применяю фильтр "${effect}" к изображению... Пожалуйста, подождите.`);
      
      // Сообщаем в консоль для отладки
      console.log(`Received image filter request from ${chatId}: ${effect}`);
      
      // Здесь в будущем добавить интеграцию с applyImageFilter из media-service
    });
    
    // Обработчик callback-запросов для inline-кнопок
    newBot.on('callback_query', async (query) => {
      const chatId = query.message?.chat.id;
      if (!chatId) return;
      
      updateLastActive(chatId);
      
      // Обработка выбора модели ИИ
      if (query.data?.startsWith('model_')) {
        const modelName = query.data.replace('model_', '');
        let modelDisplayName = '';
        
        switch (modelName) {
          case 'gpt4o':
            modelDisplayName = 'GPT-4o';
            break;
          case 'claude35':
            modelDisplayName = 'Claude 3.5';
            break;
          case 'perplexity':
            modelDisplayName = 'Perplexity AI';
            break;
          case 'webSearch':
            modelDisplayName = 'Web Search AI';
            break;
          default:
            modelDisplayName = 'Unknown Model';
        }
        
        // Отвечаем на callback запрос, чтобы убрать "часики" на кнопке
        await newBot.answerCallbackQuery(query.id);
        
        // Устанавливаем модель для чата
        const chat = activeChats.get(chatId);
        if (chat) {
          if (!chat.aiPreferences) {
            chat.aiPreferences = {};
          }
          chat.aiPreferences.favorite_models = [modelName];
          activeChats.set(chatId, chat);
        }
        
        // Отправляем сообщение о выборе модели
        const replyMarkup = {
          reply_markup: {
            force_reply: true,
            input_field_placeholder: `Задайте вопрос для ${modelDisplayName}`
          }
        };
        
        await newBot.sendMessage(
          chatId, 
          `🧠 Вы выбрали модель *${modelDisplayName}*\n\nТеперь вы можете задать ваш вопрос или описать задачу. Пожалуйста, будьте конкретны для получения наилучшего результата.`, 
          { parse_mode: 'Markdown', ...replyMarkup }
        );
      }
    });
    
    return newBot;
  } catch (error) {
    console.error('Failed to initialize Telegram bot:', error);
    return null;
  }
}

/**
 * Обновляет время последней активности пользователя
 */
function updateLastActive(chatId: number) {
  if (activeChats.has(chatId)) {
    const chat = activeChats.get(chatId)!;
    chat.lastActive = new Date();
    activeChats.set(chatId, chat);
  }
}

/**
 * Отправляет изображение в Telegram чат
 */
export async function sendImageToTelegram(
  chatId: number, 
  imagePath: string, 
  caption: string = ''
): Promise<boolean> {
  if (!bot) return false;
  
  try {
    const fullPath = path.resolve(__dirname, '..', 'public', imagePath.replace(/^\//, ''));
    
    if (!fs.existsSync(fullPath)) {
      console.error(`File not found: ${fullPath}`);
      return false;
    }
    
    await bot.sendPhoto(chatId, fullPath, { caption });
    console.log(`Sent image to chat ${chatId}: ${imagePath}`);
    return true;
  } catch (error) {
    console.error(`Failed to send image to Telegram chat ${chatId}:`, error);
    return false;
  }
}

/**
 * Отправляет видео в Telegram чат
 */
export async function sendVideoToTelegram(
  chatId: number, 
  videoPath: string, 
  caption: string = ''
): Promise<boolean> {
  if (!bot) return false;
  
  try {
    const fullPath = path.resolve(__dirname, '..', 'public', videoPath.replace(/^\//, ''));
    
    if (!fs.existsSync(fullPath)) {
      console.error(`File not found: ${fullPath}`);
      return false;
    }
    
    await bot.sendVideo(chatId, fullPath, { caption });
    console.log(`Sent video to chat ${chatId}: ${videoPath}`);
    return true;
  } catch (error) {
    console.error(`Failed to send video to Telegram chat ${chatId}:`, error);
    return false;
  }
}

/**
 * Отправляет аудиофайл в Telegram чат
 */
export async function sendAudioToTelegram(
  chatId: number, 
  audioPath: string, 
  caption: string = ''
): Promise<boolean> {
  if (!bot) return false;
  
  try {
    const fullPath = path.resolve(__dirname, '..', 'public', audioPath.replace(/^\//, ''));
    
    if (!fs.existsSync(fullPath)) {
      console.error(`File not found: ${fullPath}`);
      return false;
    }
    
    await bot.sendAudio(chatId, fullPath, { caption });
    console.log(`Sent audio to chat ${chatId}: ${audioPath}`);
    return true;
  } catch (error) {
    console.error(`Failed to send audio to Telegram chat ${chatId}:`, error);
    return false;
  }
}

/**
 * Отправляет документ в Telegram чат
 */
export async function sendDocumentToTelegram(
  chatId: number, 
  filePath: string, 
  caption: string = ''
): Promise<boolean> {
  if (!bot) return false;
  
  try {
    const fullPath = path.resolve(__dirname, '..', 'public', filePath.replace(/^\//, ''));
    
    if (!fs.existsSync(fullPath)) {
      console.error(`File not found: ${fullPath}`);
      return false;
    }
    
    await bot.sendDocument(chatId, fullPath, { caption });
    console.log(`Sent document to chat ${chatId}: ${filePath}`);
    return true;
  } catch (error) {
    console.error(`Failed to send document to Telegram chat ${chatId}:`, error);
    return false;
  }
}

/**
 * Функция очистки старых файлов
 */
export function cleanupOldFiles() {
  const now = Date.now();
  const publicDir = path.resolve(__dirname, '..', 'public');
  const mediaDirs = ['images', 'videos', 'audio'];
  
  // Перебираем все директории с медиафайлами
  mediaDirs.forEach(dir => {
    const dirPath = path.join(publicDir, dir);
    
    if (!fs.existsSync(dirPath)) return;
    
    try {
      const files = fs.readdirSync(dirPath);
      
      files.forEach(file => {
        const filePath = path.join(dirPath, file);
        
        // Получаем статистику файла
        const stats = fs.statSync(filePath);
        
        // Если файл старше заданного срока - удаляем
        if (now - stats.mtimeMs > FILE_TTL) {
          try {
            fs.unlinkSync(filePath);
            console.log(`Removed old file: ${filePath}`);
          } catch (err) {
            console.error(`Failed to remove old file ${filePath}:`, err);
          }
        }
      });
    } catch (err) {
      console.error(`Error reading directory ${dirPath}:`, err);
    }
  });
  
  console.log('File cleanup completed');
}

/**
 * Получает информацию о всех активных чатах
 */
export function getActiveChats(): TelegramChat[] {
  return Array.from(activeChats.values());
}

/**
 * Инициализирует сервис Telegram и задачи автоочистки
 */
export function setupTelegramService() {
  // Инициализируем бота
  bot = initTelegramBot();
  
  // Запускаем задачу очистки старых файлов
  console.log('Setting up file cleanup task with interval:', CLEANUP_INTERVAL / (60 * 60 * 1000), 'hours');
  setInterval(cleanupOldFiles, CLEANUP_INTERVAL);
  
  // Запускаем первую очистку сразу
  cleanupOldFiles();
  
  return bot;
}

/**
 * Настройка маршрутов API для Telegram интеграции
 */
export function setupTelegramRoutes(app: Express) {
  // Получение списка активных чатов
  app.get('/api/telegram/chats', (req, res) => {
    const chats = getActiveChats();
    res.json({ chats });
  });
  
  // Отправка сообщения в чат
  app.post('/api/telegram/send-message', (req, res) => {
    const { chatId, message } = req.body;
    
    if (!chatId || !message) {
      return res.status(400).json({ error: 'Chat ID and message are required' });
    }
    
    if (!bot) {
      return res.status(503).json({ error: 'Telegram bot is not initialized' });
    }
    
    bot.sendMessage(chatId, message)
      .then(() => {
        res.json({ success: true });
      })
      .catch(error => {
        console.error('Error sending message:', error);
        res.status(500).json({ error: 'Failed to send message' });
      });
  });
  
  // Отправка медиафайла в чат
  app.post('/api/telegram/send-media', async (req, res) => {
    const { chatId, mediaType, mediaPath, caption } = req.body;
    
    if (!chatId || !mediaType || !mediaPath) {
      return res.status(400).json({ error: 'Chat ID, media type, and media path are required' });
    }
    
    if (!bot) {
      return res.status(503).json({ error: 'Telegram bot is not initialized' });
    }
    
    let success = false;
    
    switch (mediaType) {
      case 'photo':
      case 'image':
        success = await sendImageToTelegram(chatId, mediaPath, caption);
        break;
      case 'video':
        success = await sendVideoToTelegram(chatId, mediaPath, caption);
        break;
      case 'audio':
        success = await sendAudioToTelegram(chatId, mediaPath, caption);
        break;
      case 'document':
      case 'file':
        success = await sendDocumentToTelegram(chatId, mediaPath, caption);
        break;
      default:
        return res.status(400).json({ error: 'Invalid media type. Use "photo", "video", "audio", or "document"' });
    }
    
    if (success) {
      res.json({ success: true });
    } else {
      res.status(500).json({ error: 'Failed to send media' });
    }
  });
  
  // Запуск ручной очистки файлов
  app.post('/api/telegram/cleanup-files', (req, res) => {
    try {
      cleanupOldFiles();
      res.json({ success: true });
    } catch (error) {
      console.error('Error during manual cleanup:', error);
      res.status(500).json({ error: 'Failed to cleanup files' });
    }
  });
}