/**
 * MassaganAI: Сервис для обработки и озвучивания видео
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 * 
 * Сервис использует Python библиотеки для обработки видео:
 * - moviepy: для редактирования видео, добавления текста, эффектов
 * - pydub: для работы с аудио
 * - gTTS (Google Text to Speech): для озвучивания текста
 * - SpeechRecognition: для распознавания речи
 * - OpenCV: для обработки изображений и видео
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { Express, Request, Response } from 'express';

const execAsync = promisify(exec);
const writeFileAsync = promisify(fs.writeFile);
const mkdirAsync = promisify(fs.mkdir);
const readFileAsync = promisify(fs.readFile);
const unlinkAsync = promisify(fs.unlink);

/**
 * Класс для взаимодействия с Python скриптами обработки видео
 */
class VideoProcessor {
  private pythonPath: string;
  private tempDir: string;

  constructor() {
    // В production используем Python из системы
    this.pythonPath = 'python3';
    this.tempDir = path.join(os.tmpdir(), 'massagan_video_temp');
    
    // Создаем временную директорию, если она не существует
    this.ensureTempDir();
  }

  /**
   * Создает временную директорию для обработки файлов
   */
  private async ensureTempDir(): Promise<void> {
    try {
      await mkdirAsync(this.tempDir, { recursive: true });
    } catch (error) {
      console.error('Ошибка при создании временной директории:', error);
    }
  }

  /**
   * Проверяет установку необходимых Python пакетов
   */
  public async checkDependencies(): Promise<boolean> {
    try {
      const { stdout } = await execAsync(`${this.pythonPath} -c "import moviepy, pydub, gtts, speech_recognition, cv2; print('OK')"`, { timeout: 10000 });
      return stdout.trim() === 'OK';
    } catch (error) {
      console.error('Ошибка при проверке зависимостей Python:', error);
      return false;
    }
  }

  /**
   * Устанавливает необходимые пакеты Python
   */
  public async installDependencies(): Promise<boolean> {
    try {
      await execAsync(`${this.pythonPath} -m pip install moviepy pydub gtts SpeechRecognition opencv-python`, { timeout: 300000 });
      return true;
    } catch (error) {
      console.error('Ошибка при установке зависимостей Python:', error);
      return false;
    }
  }

  /**
   * Создает временный Python скрипт
   */
  private async createPythonScript(scriptContent: string): Promise<string> {
    const scriptPath = path.join(this.tempDir, `script_${Date.now()}.py`);
    await writeFileAsync(scriptPath, scriptContent);
    return scriptPath;
  }

  /**
   * Преобразует текст в речь
   * @param text Текст для озвучивания
   * @param language Код языка для озвучивания (по умолчанию 'ru')
   * @returns Путь к аудиофайлу
   */
  public async textToSpeech(text: string, language: string = 'ru'): Promise<string> {
    // Python скрипт для преобразования текста в речь
    const scriptContent = `
import os
from gtts import gTTS

text = """${text.replace(/"/g, '\\"')}"""
language = "${language}"

output_file = os.path.join("${this.tempDir}", "audio_output.mp3")
tts = gTTS(text=text, lang=language, slow=False)
tts.save(output_file)
print(output_file)
`;

    try {
      const scriptPath = await this.createPythonScript(scriptContent);
      const { stdout } = await execAsync(`${this.pythonPath} "${scriptPath}"`, { timeout: 30000 });
      await unlinkAsync(scriptPath);
      return stdout.trim();
    } catch (error) {
      console.error('Ошибка при преобразовании текста в речь:', error);
      throw new Error('Не удалось преобразовать текст в речь');
    }
  }

  /**
   * Создает видео с субтитрами
   * @param videoPath Путь к видеофайлу
   * @param subtitleText Текст субтитров
   * @returns Путь к новому видеофайлу
   */
  public async addSubtitlesToVideo(videoPath: string, subtitleText: string): Promise<string> {
    // Python скрипт для добавления субтитров
    const scriptContent = `
import os
from moviepy.editor import VideoFileClip, TextClip, CompositeVideoClip

video_path = "${videoPath.replace(/\\/g, '\\\\')}"
subtitle_text = """${subtitleText.replace(/"/g, '\\"')}"""

output_file = os.path.join("${this.tempDir}", "video_with_subtitles.mp4")

# Загрузка видео
video = VideoFileClip(video_path)

# Создание текстового клипа
txt_clip = TextClip(subtitle_text, fontsize=24, color='white')
txt_clip = txt_clip.set_position(('center', 'bottom')).set_duration(video.duration)

# Объединение с видео
final_clip = CompositeVideoClip([video, txt_clip])
final_clip.write_videofile(output_file, codec='libx264')

print(output_file)
`;

    try {
      const scriptPath = await this.createPythonScript(scriptContent);
      const { stdout } = await execAsync(`${this.pythonPath} "${scriptPath}"`, { timeout: 300000 });
      await unlinkAsync(scriptPath);
      return stdout.trim();
    } catch (error) {
      console.error('Ошибка при добавлении субтитров к видео:', error);
      throw new Error('Не удалось добавить субтитры к видео');
    }
  }

  /**
   * Озвучивает видео
   * @param videoPath Путь к видеофайлу
   * @param audioPath Путь к аудиофайлу
   * @returns Путь к новому видеофайлу
   */
  public async addAudioToVideo(videoPath: string, audioPath: string): Promise<string> {
    // Python скрипт для добавления аудио к видео
    const scriptContent = `
import os
from moviepy.editor import VideoFileClip, AudioFileClip, CompositeAudioClip

video_path = "${videoPath.replace(/\\/g, '\\\\')}"
audio_path = "${audioPath.replace(/\\/g, '\\\\')}"

output_file = os.path.join("${this.tempDir}", "video_with_audio.mp4")

# Загрузка видео и аудио
video = VideoFileClip(video_path)
audio = AudioFileClip(audio_path)

# Если аудио длиннее видео, обрезаем его
if audio.duration > video.duration:
    audio = audio.subclip(0, video.duration)
# Если видео длиннее аудио, зацикливаем аудио
elif audio.duration < video.duration:
    repeats = int(video.duration / audio.duration) + 1
    audio = CompositeAudioClip([audio] * repeats).subclip(0, video.duration)

# Добавление аудио к видео
video = video.set_audio(audio)
video.write_videofile(output_file, codec='libx264')

print(output_file)
`;

    try {
      const scriptPath = await this.createPythonScript(scriptContent);
      const { stdout } = await execAsync(`${this.pythonPath} "${scriptPath}"`, { timeout: 300000 });
      await unlinkAsync(scriptPath);
      return stdout.trim();
    } catch (error) {
      console.error('Ошибка при добавлении аудио к видео:', error);
      throw new Error('Не удалось добавить аудио к видео');
    }
  }

  /**
   * Применяет эффекты к видео
   * @param videoPath Путь к видеофайлу
   * @param effect Название эффекта ('blackwhite', 'blur', 'mirror', 'speedup', 'slowdown')
   * @returns Путь к новому видеофайлу
   */
  public async applyEffectToVideo(videoPath: string, effect: string): Promise<string> {
    // Python скрипт для применения эффектов
    const scriptContent = `
import os
import numpy as np
from moviepy.editor import VideoFileClip, vfx

video_path = "${videoPath.replace(/\\/g, '\\\\')}"
effect = "${effect}"

output_file = os.path.join("${this.tempDir}", f"video_with_{effect}.mp4")

# Загрузка видео
video = VideoFileClip(video_path)

# Применение эффекта
if effect == 'blackwhite':
    video = video.fx(vfx.blackwhite)
elif effect == 'blur':
    video = video.fx(vfx.blur, 2)
elif effect == 'mirror':
    video = video.fx(vfx.mirror_x)
elif effect == 'speedup':
    video = video.fx(vfx.speedx, 1.5)
elif effect == 'slowdown':
    video = video.fx(vfx.speedx, 0.5)

video.write_videofile(output_file, codec='libx264')

print(output_file)
`;

    try {
      const scriptPath = await this.createPythonScript(scriptContent);
      const { stdout } = await execAsync(`${this.pythonPath} "${scriptPath}"`, { timeout: 300000 });
      await unlinkAsync(scriptPath);
      return stdout.trim();
    } catch (error) {
      console.error('Ошибка при применении эффекта к видео:', error);
      throw new Error('Не удалось применить эффект к видео');
    }
  }

  /**
   * Создает видео из изображений
   * @param imagePaths Массив путей к изображениям
   * @param duration Длительность показа каждого изображения в секундах
   * @returns Путь к созданному видеофайлу
   */
  public async createVideoFromImages(imagePaths: string[], duration: number = 3): Promise<string> {
    // Python скрипт для создания видео из изображений
    const scriptContent = `
import os
from moviepy.editor import ImageClip, concatenate_videoclips

image_paths = ${JSON.stringify(imagePaths).replace(/\\/g, '\\\\')}
duration = ${duration}

output_file = os.path.join("${this.tempDir}", "video_from_images.mp4")

# Создание клипов из изображений
clips = [ImageClip(img_path).set_duration(duration) for img_path in image_paths]

# Создание видео
final_clip = concatenate_videoclips(clips, method="compose")
final_clip.write_videofile(output_file, fps=24, codec='libx264')

print(output_file)
`;

    try {
      const scriptPath = await this.createPythonScript(scriptContent);
      const { stdout } = await execAsync(`${this.pythonPath} "${scriptPath}"`, { timeout: 300000 });
      await unlinkAsync(scriptPath);
      return stdout.trim();
    } catch (error) {
      console.error('Ошибка при создании видео из изображений:', error);
      throw new Error('Не удалось создать видео из изображений');
    }
  }

  /**
   * Извлекает аудио из видео
   * @param videoPath Путь к видеофайлу
   * @returns Путь к аудиофайлу
   */
  public async extractAudioFromVideo(videoPath: string): Promise<string> {
    // Python скрипт для извлечения аудио
    const scriptContent = `
import os
from moviepy.editor import VideoFileClip

video_path = "${videoPath.replace(/\\/g, '\\\\')}"

output_file = os.path.join("${this.tempDir}", "extracted_audio.mp3")

# Загрузка видео и извлечение аудио
video = VideoFileClip(video_path)
audio = video.audio
audio.write_audiofile(output_file)

print(output_file)
`;

    try {
      const scriptPath = await this.createPythonScript(scriptContent);
      const { stdout } = await execAsync(`${this.pythonPath} "${scriptPath}"`, { timeout: 300000 });
      await unlinkAsync(scriptPath);
      return stdout.trim();
    } catch (error) {
      console.error('Ошибка при извлечении аудио из видео:', error);
      throw new Error('Не удалось извлечь аудио из видео');
    }
  }

  /**
   * Распознает речь из аудиофайла
   * @param audioPath Путь к аудиофайлу
   * @param language Код языка (по умолчанию 'ru-RU')
   * @returns Распознанный текст
   */
  public async speechToText(audioPath: string, language: string = 'ru-RU'): Promise<string> {
    // Python скрипт для распознавания речи
    const scriptContent = `
import speech_recognition as sr
import os

audio_path = "${audioPath.replace(/\\/g, '\\\\')}"
language = "${language}"

output_file = os.path.join("${this.tempDir}", "recognized_text.txt")

recognizer = sr.Recognizer()

with sr.AudioFile(audio_path) as source:
    audio_data = recognizer.record(source)

    try:
        text = recognizer.recognize_google(audio_data, language=language)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(text)
        print(output_file)
    except sr.UnknownValueError:
        print("Не удалось распознать речь")
    except sr.RequestError as e:
        print(f"Ошибка сервиса распознавания: {e}")
`;

    try {
      const scriptPath = await this.createPythonScript(scriptContent);
      const { stdout } = await execAsync(`${this.pythonPath} "${scriptPath}"`, { timeout: 30000 });
      await unlinkAsync(scriptPath);
      
      if (stdout.includes("Не удалось распознать речь") || stdout.includes("Ошибка сервиса распознавания")) {
        throw new Error(stdout.trim());
      }
      
      const textFilePath = stdout.trim();
      const recognizedText = await readFileAsync(textFilePath, 'utf-8');
      return recognizedText;
    } catch (error) {
      console.error('Ошибка при распознавании речи:', error);
      throw new Error('Не удалось распознать речь из аудиофайла');
    }
  }
}

// Экземпляр класса для использования в API
export const videoProcessor = new VideoProcessor();

// API routes
export async function setupVideoRoutes(app: Express) {
  // Проверка установки зависимостей
  app.get('/api/video/check-dependencies', async (req: Request, res: Response) => {
    try {
      const dependenciesInstalled = await videoProcessor.checkDependencies();
      res.json({ dependenciesInstalled });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при проверке зависимостей' });
    }
  });

  // Установка зависимостей
  app.post('/api/video/install-dependencies', async (req: Request, res: Response) => {
    try {
      const success = await videoProcessor.installDependencies();
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при установке зависимостей' });
    }
  });

  // Преобразование текста в речь
  app.post('/api/video/text-to-speech', async (req: Request, res: Response) => {
    try {
      const { text, language } = req.body;
      const audioPath = await videoProcessor.textToSpeech(text, language);
      res.json({ audioPath });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при преобразовании текста в речь' });
    }
  });

  // Добавление субтитров к видео
  app.post('/api/video/add-subtitles', async (req: Request, res: Response) => {
    try {
      const { videoPath, subtitleText } = req.body;
      const outputPath = await videoProcessor.addSubtitlesToVideo(videoPath, subtitleText);
      res.json({ outputPath });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при добавлении субтитров к видео' });
    }
  });

  // Добавление аудио к видео
  app.post('/api/video/add-audio', async (req: Request, res: Response) => {
    try {
      const { videoPath, audioPath } = req.body;
      const outputPath = await videoProcessor.addAudioToVideo(videoPath, audioPath);
      res.json({ outputPath });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при добавлении аудио к видео' });
    }
  });

  // Применение эффектов к видео
  app.post('/api/video/apply-effect', async (req: Request, res: Response) => {
    try {
      const { videoPath, effect } = req.body;
      const outputPath = await videoProcessor.applyEffectToVideo(videoPath, effect);
      res.json({ outputPath });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при применении эффекта к видео' });
    }
  });

  // Создание видео из изображений
  app.post('/api/video/create-from-images', async (req: Request, res: Response) => {
    try {
      const { imagePaths, duration } = req.body;
      const outputPath = await videoProcessor.createVideoFromImages(imagePaths, duration);
      res.json({ outputPath });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при создании видео из изображений' });
    }
  });

  // Извлечение аудио из видео
  app.post('/api/video/extract-audio', async (req, res) => {
    try {
      const { videoPath } = req.body;
      const audioPath = await videoProcessor.extractAudioFromVideo(videoPath);
      res.json({ audioPath });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при извлечении аудио из видео' });
    }
  });

  // Распознавание речи из аудио
  app.post('/api/video/speech-to-text', async (req, res) => {
    try {
      const { audioPath, language } = req.body;
      const text = await videoProcessor.speechToText(audioPath, language);
      res.json({ text });
    } catch (error) {
      res.status(500).json({ error: 'Ошибка при распознавании речи' });
    }
  });
}