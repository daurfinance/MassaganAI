/**
 * MassaganAI: Сервис для работы со Stripe платежами и подписками
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import Stripe from 'stripe';
import { Request, Response, Express } from 'express';
import { storage } from './storage';

// Проверка наличия API ключа
if (!process.env.STRIPE_SECRET_KEY) {
  console.error('Missing STRIPE_SECRET_KEY environment variable');
  process.exit(1);
}

// Инициализация Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2023-10-16',
});

// ID продуктов и цен в Stripe
// Эти ID нужно получить после создания продуктов в панели Stripe
interface PlanPrices {
  premium: {
    [region: string]: string;
  };
  business: {
    [region: string]: string;
  };
}

// Цены в различных регионах (ID продуктов в Stripe)
// Эти значения должны быть заменены на реальные ID продуктов после их создания в Stripe
const planPrices: PlanPrices = {
  premium: {
    // Basic план (5000 тенге)
    'KZ': 'price_KZ_premium', // Казахстан
    'RU': 'price_RU_premium', // Россия
    'TR': 'price_TR_premium', // Турция
    'AE': 'price_AE_premium', // ОАЭ
    'US': 'price_US_premium', // США
    'default': 'price_DEFAULT_premium' // По умолчанию
  },
  business: {
    // Pro план (15000 тенге)
    'KZ': 'price_KZ_business', // Казахстан
    'RU': 'price_RU_business', // Россия
    'TR': 'price_TR_business', // Турция
    'AE': 'price_AE_business', // ОАЭ
    'US': 'price_US_business', // США
    'default': 'price_DEFAULT_business' // По умолчанию
  }
};

// Курсы валют относительно тенге (примерные значения)
const exchangeRates = {
  'KZT': 1,      // Казахстанский тенге (базовый)
  'RUB': 0.2,    // Российский рубль
  'TRY': 0.04,   // Турецкая лира
  'AED': 0.01,   // Дирхам ОАЭ
  'USD': 0.002,  // Доллар США
  'EUR': 0.0019  // Евро
};

// Базовые цены в тенге
const basePrices = {
  premium: 5000,  // 5000 тенге/месяц
  business: 15000 // 15000 тенге/месяц
};

// Функция для получения цены в зависимости от региона
function getPriceForRegion(planType: 'premium' | 'business', regionCode: string): number {
  const basePrice = basePrices[planType];
  let currencyCode: keyof typeof exchangeRates = 'KZT';
  
  // Определяем валюту по региону
  switch(regionCode) {
    case 'KZ':
      currencyCode = 'KZT';
      break;
    case 'RU':
      currencyCode = 'RUB';
      break;
    case 'TR':
      currencyCode = 'TRY';
      break;
    case 'AE':
      currencyCode = 'AED';
      break;
    case 'US':
      currencyCode = 'USD';
      break;
    default:
      currencyCode = 'USD';
  }
  
  // Конвертируем цену в нужную валюту
  return Math.round(basePrice * exchangeRates[currencyCode]);
}

// Функция для определения ID продукта по региону
function getPriceIdForRegion(planType: 'premium' | 'business', regionCode: string): string {
  const prices = planPrices[planType];
  return prices[regionCode] || prices['default'];
}

// Создание подписки
async function createSubscription(customerId: string, priceId: string) {
  try {
    // Создаем подписку
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
    });
    
    return {
      subscriptionId: subscription.id,
      clientSecret: subscription.latest_invoice.payment_intent.client_secret,
      status: subscription.status
    };
  } catch (error) {
    console.error('Error creating subscription:', error);
    throw error;
  }
}

// Получение или создание нового клиента Stripe
async function getOrCreateCustomer(userId: number, email: string, name: string) {
  try {
    // Сначала ищем пользователя по ID в нашей базе
    const user = await storage.getUser(userId);
    
    if (user && user.stripeCustomerId) {
      // Если у пользователя уже есть ID клиента Stripe, используем его
      try {
        const customer = await stripe.customers.retrieve(user.stripeCustomerId);
        return customer.id;
      } catch (error) {
        console.error('Error retrieving Stripe customer, creating new one:', error);
        // Если произошла ошибка (например, клиент был удален в Stripe), создаем нового
      }
    }
    
    // Создаем нового клиента Stripe
    const customer = await stripe.customers.create({
      email,
      name,
      metadata: {
        userId: userId.toString()
      }
    });
    
    // Обновляем ID клиента Stripe в нашей базе
    await storage.updateStripeCustomerId(userId, customer.id);
    
    return customer.id;
  } catch (error) {
    console.error('Error in getOrCreateCustomer:', error);
    throw error;
  }
}

// Настройка маршрутов для работы с платежами и подписками
export async function setupStripeRoutes(app: Express) {
  // Создание платежа для разовой покупки
  app.post('/api/create-payment-intent', async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
      
      const { amount, description } = req.body;
      
      // Валидация данных
      if (!amount || amount <= 0) {
        return res.status(400).json({ error: 'Invalid amount' });
      }
      
      // Создаем платеж
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Переводим в центы
        currency: 'kzt', // Можно адаптировать в зависимости от региона
        description: description || 'MassaganAI Purchase',
        metadata: {
          userId: req.user.id.toString()
        }
      });
      
      res.json({
        clientSecret: paymentIntent.client_secret
      });
    } catch (error) {
      console.error('Error creating payment intent:', error);
      res.status(500).json({ error: 'Failed to create payment' });
    }
  });

  // Создание подписки
  app.post('/api/create-subscription', async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
      
      const { planType, regionCode = 'KZ' } = req.body;
      
      // Валидация данных
      if (!planType || !['premium', 'business'].includes(planType)) {
        return res.status(400).json({ error: 'Invalid plan type' });
      }
      
      // Получаем ID пользователя из сессии
      const userId = req.user.id;
      const email = req.user.email || 'no-email@example.com';
      const name = req.user.username || 'Unknown User';
      
      // Получаем или создаем клиента Stripe
      const customerId = await getOrCreateCustomer(userId, email, name);
      
      // Получаем ID цены для выбранного плана и региона
      const priceId = getPriceIdForRegion(planType as 'premium' | 'business', regionCode);
      
      // Создаем подписку
      const subscription = await createSubscription(customerId, priceId);
      
      // Сохраняем информацию о подписке в нашей базе
      await storage.createSubscription({
        userId,
        stripeSubscriptionId: subscription.subscriptionId,
        planType: planType as 'premium' | 'business',
        status: subscription.status,
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // +30 дней примерно
        createdAt: new Date()
      });
      
      res.json({
        subscriptionId: subscription.subscriptionId,
        clientSecret: subscription.clientSecret
      });
    } catch (error) {
      console.error('Error creating subscription:', error);
      res.status(500).json({ error: 'Failed to create subscription' });
    }
  });

  // Обработка вебхуков от Stripe
  app.post('/api/webhook/stripe', async (req: Request, res: Response) => {
    let event;
    
    try {
      // Проверяем подпись webhook если есть секрет
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
      
      if (webhookSecret) {
        const signature = req.headers['stripe-signature'] as string;
        event = stripe.webhooks.constructEvent(
          req.body,
          signature,
          webhookSecret
        );
      } else {
        // Если секрета нет, просто используем тело запроса как событие
        event = req.body;
      }
      
      // Обрабатываем различные события от Stripe
      switch (event.type) {
        case 'customer.subscription.created':
          // Новая подписка создана
          const subscription = event.data.object;
          await handleSuccessfulSubscription(
            subscription.customer,
            subscription.id
          );
          break;
          
        case 'invoice.payment_succeeded':
          // Успешная оплата счета (может быть первичная или повторная оплата подписки)
          const invoice = event.data.object;
          if (invoice.subscription) {
            await handleSuccessfulSubscriptionPayment(
              invoice.customer,
              invoice.subscription
            );
          }
          break;
          
        case 'customer.subscription.updated':
        case 'customer.subscription.deleted':
          // Обновление или удаление подписки
          const updatedSubscription = event.data.object;
          await updateSubscriptionStatus(
            updatedSubscription.customer,
            updatedSubscription.id,
            updatedSubscription.status
          );
          break;
          
        default:
          // Неизвестное событие, просто логируем
          console.log(`Unhandled event type: ${event.type}`);
      }
      
      res.json({ received: true });
    } catch (error) {
      console.error('Error handling Stripe webhook:', error);
      res.status(400).send(`Webhook Error: ${error.message}`);
    }
  });

  // Получение текущей подписки пользователя
  app.get('/api/subscription', async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
      
      const userId = req.user.id;
      
      // Получаем подписку из нашей базы
      const subscription = await storage.getUserSubscription(userId);
      
      if (!subscription) {
        return res.json({ subscription: null });
      }
      
      // Если есть подписка в базе, проверяем ее актуальность в Stripe
      try {
        const stripeSubscription = await stripe.subscriptions.retrieve(subscription.stripeSubscriptionId);
        
        // Обновляем статус в нашей базе, если он изменился
        if (subscription.status !== stripeSubscription.status) {
          await storage.updateSubscriptionStatus(
            subscription.stripeSubscriptionId,
            stripeSubscription.status
          );
          
          subscription.status = stripeSubscription.status;
        }
        
        // Возвращаем информацию о подписке клиенту
        res.json({
          subscription: {
            id: subscription.id,
            planType: subscription.planType,
            status: subscription.status,
            currentPeriodEnd: subscription.currentPeriodEnd,
            stripeStatus: stripeSubscription.status,
            cancelAtPeriodEnd: stripeSubscription.cancel_at_period_end
          }
        });
      } catch (error) {
        console.error('Error retrieving subscription from Stripe:', error);
        
        // Если подписки нет в Stripe, возвращаем данные из нашей базы
        res.json({
          subscription: {
            id: subscription.id,
            planType: subscription.planType,
            status: subscription.status,
            currentPeriodEnd: subscription.currentPeriodEnd,
            stripeStatus: 'unknown',
            cancelAtPeriodEnd: false
          }
        });
      }
    } catch (error) {
      console.error('Error getting subscription:', error);
      res.status(500).json({ error: 'Failed to get subscription' });
    }
  });

  // Отмена подписки
  app.post('/api/cancel-subscription', async (req: Request, res: Response) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: 'Unauthorized' });
      }
      
      const userId = req.user.id;
      
      // Получаем подписку из нашей базы
      const subscription = await storage.getUserSubscription(userId);
      
      if (!subscription) {
        return res.status(404).json({ error: 'Subscription not found' });
      }
      
      // Отменяем подписку в Stripe (в конце текущего периода)
      await stripe.subscriptions.update(subscription.stripeSubscriptionId, {
        cancel_at_period_end: true
      });
      
      // Обновляем статус в нашей базе
      await storage.updateSubscriptionStatus(
        subscription.stripeSubscriptionId,
        'active_until_period_end'
      );
      
      res.json({ success: true });
    } catch (error) {
      console.error('Error canceling subscription:', error);
      res.status(500).json({ error: 'Failed to cancel subscription' });
    }
  });
}

// Обработчик успешной подписки
async function handleSuccessfulSubscription(customerId: string, subscriptionId: string) {
  try {
    // Находим пользователя по ID клиента Stripe
    const user = await storage.getUserByStripeCustomerId(customerId);
    
    if (!user) {
      console.error(`User not found for Stripe customer ID: ${customerId}`);
      return;
    }
    
    // Получаем подписку из Stripe
    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    
    // Обновляем статус подписки в нашей базе
    await storage.updateSubscriptionStatus(subscriptionId, subscription.status);
  } catch (error) {
    console.error('Error handling successful subscription:', error);
  }
}

// Обработчик успешной оплаты подписки
async function handleSuccessfulSubscriptionPayment(customerId: string, subscriptionId: string) {
  try {
    // Находим пользователя по ID клиента Stripe
    const user = await storage.getUserByStripeCustomerId(customerId);
    
    if (!user) {
      console.error(`User not found for Stripe customer ID: ${customerId}`);
      return;
    }
    
    // Получаем подписку из Stripe для получения деталей
    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    
    // Получаем дату окончания текущего периода
    const currentPeriodEnd = new Date(subscription.current_period_end * 1000);
    
    // Обновляем статус и дату окончания подписки в нашей базе
    const userSubscription = await storage.getUserSubscription(user.id);
    
    if (userSubscription) {
      // Обновляем существующую подписку
      await storage.updateSubscriptionStatus(subscriptionId, subscription.status);
    } else {
      // Если по какой-то причине подписки нет в нашей базе, создаем новую
      // Определяем тип плана по первому элементу в items
      const planType = subscription.items.data[0].price.lookup_key === 'business' ? 'business' : 'premium';
      
      await storage.createSubscription({
        userId: user.id,
        stripeSubscriptionId: subscriptionId,
        planType,
        status: subscription.status,
        currentPeriodEnd,
        createdAt: new Date()
      });
    }
  } catch (error) {
    console.error('Error handling successful subscription payment:', error);
  }
}

// Обновление статуса подписки
async function updateSubscriptionStatus(customerId: string, subscriptionId: string, status: string) {
  try {
    // Находим пользователя по ID клиента Stripe
    const user = await storage.getUserByStripeCustomerId(customerId);
    
    if (!user) {
      console.error(`User not found for Stripe customer ID: ${customerId}`);
      return;
    }
    
    // Обновляем статус подписки в нашей базе
    await storage.updateSubscriptionStatus(subscriptionId, status);
  } catch (error) {
    console.error('Error updating subscription status:', error);
  }
}