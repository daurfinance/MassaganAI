/**
 * MassaganAI: Сервис для взаимодействия с Anthropic API (Claude)
 * Используется для анализа кода, документов и генерации контента
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import Anthropic from '@anthropic-ai/sdk';
import { Express, Request, Response } from 'express';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

// Инициализация Anthropic SDK
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || '',
});

// Директория для временных файлов
const tempDir = path.join(process.cwd(), 'temp');
if (!fs.existsSync(tempDir)) {
  fs.mkdirSync(tempDir, { recursive: true });
}

/**
 * Генерирует случайное имя файла
 */
function generateRandomFilename(extension: string): string {
  const randomBytes = crypto.randomBytes(16).toString('hex');
  return `${randomBytes}.${extension}`;
}

/**
 * Анализирует код с использованием Claude
 * @param code Исходный код для анализа
 * @param language Язык программирования
 * @returns Результат анализа кода
 */
export async function analyzeCodeWithClaude(code: string, language: string): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219', // Новейшая модель Claude от Anthropic
      max_tokens: 4000,
      system: `Вы эксперт по разработке программного обеспечения, специализирующийся на анализе кода.
      Проанализируйте предоставленный код ${language} и предоставьте следующую информацию:
      1. Краткое описание функционала
      2. Структурный обзор
      3. Выявленные проблемы и уязвимости
      4. Рекомендации по улучшению производительности и читаемости
      5. Оценка качества кода по шкале от 1 до 10
      
      Будьте конкретны и используйте примеры кода в рекомендациях.`,
      messages: [
        { role: 'user', content: code }
      ],
    });

    return response.content[0].text;
  } catch (error: any) {
    console.error('Ошибка при анализе кода с Claude:', error.message);
    throw new Error(`Не удалось проанализировать код: ${error.message}`);
  }
}

/**
 * Генерирует улучшенную версию кода с использованием Claude
 * @param code Исходный код
 * @param language Язык программирования
 * @param instructions Дополнительные инструкции по улучшению
 * @returns Улучшенная версия кода
 */
export async function generateImprovedCode(code: string, language: string, instructions: string = ''): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 8000,
      system: `Вы эксперт по разработке программного обеспечения, специализирующийся на улучшении кода.
      Перепишите предоставленный код ${language}, чтобы он был более эффективным, читаемым и современным.
      
      ${instructions ? `При улучшении учтите следующие инструкции: ${instructions}` : ''}
      
      Не меняйте основную функциональность. Сохраните структуру и логику кода, но улучшите:
      1. Производительность
      2. Читаемость
      3. Безопасность
      4. Использование современных возможностей языка
      5. Следование лучшим практикам и стандартам
      
      Верните ТОЛЬКО улучшенную версию кода, без комментариев или объяснений.`,
      messages: [
        { role: 'user', content: code }
      ],
    });

    return response.content[0].text;
  } catch (error: any) {
    console.error('Ошибка при генерации улучшенного кода с Claude:', error.message);
    throw new Error(`Не удалось улучшить код: ${error.message}`);
  }
}

/**
 * Анализирует изображение с использованием Claude Vision
 * @param imagePath Путь к изображению или base64-строка изображения
 * @param query Вопрос или инструкции по анализу изображения
 * @returns Результат анализа изображения
 */
export async function analyzeImageWithClaude(imagePath: string, query: string): Promise<string> {
  try {
    // Проверяем, является ли это путем к файлу или base64
    let imageData: string;
    
    if (imagePath.startsWith('data:image/')) {
      // Это уже base64
      imageData = imagePath.split(',')[1];
    } else if (fs.existsSync(imagePath)) {
      // Это путь к файлу
      const fileBuffer = fs.readFileSync(imagePath);
      imageData = fileBuffer.toString('base64');
    } else {
      throw new Error('Недопустимый путь к изображению или формат данных');
    }

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 4000,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: query || 'Детально проанализируйте это изображение и опишите его содержимое.'
            },
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: 'image/jpeg',
                data: imageData
              }
            }
          ]
        }
      ],
    });

    return response.content[0].text;
  } catch (error: any) {
    console.error('Ошибка при анализе изображения с Claude:', error.message);
    throw new Error(`Не удалось проанализировать изображение: ${error.message}`);
  }
}

/**
 * Анализирует документ и генерирует его резюме
 * @param text Текст документа
 * @param instructions Инструкции по анализу документа
 * @returns Результат анализа документа
 */
export async function analyzeDocumentWithClaude(
  text: string, 
  instructions: string = 'Составьте подробное резюме документа'
): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 4000,
      system: `Вы эксперт по анализу документов и извлечению информации.
      Проанализируйте предоставленный документ и следуйте инструкциям: ${instructions}`,
      messages: [
        { role: 'user', content: text }
      ],
    });

    return response.content[0].text;
  } catch (error: any) {
    console.error('Ошибка при анализе документа с Claude:', error.message);
    throw new Error(`Не удалось проанализировать документ: ${error.message}`);
  }
}

/**
 * Создает презентацию по заданной теме
 * @param topic Тема презентации
 * @param numSlides Количество слайдов
 * @returns Содержимое презентации
 */
export async function generatePresentationWithClaude(topic: string, numSlides: number = 5): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 8000,
      system: `Вы эксперт по созданию презентаций.
      Создайте структуру презентации на тему "${topic}" состоящую из ${numSlides} слайдов.
      
      Для каждого слайда предоставьте:
      1. Заголовок слайда
      2. Основные пункты или текст
      3. Описание визуальных элементов (если необходимо)
      4. Примечания для докладчика (если необходимо)
      
      Следуйте принципам эффективных презентаций: ясность, краткость, визуализация и рассказывание истории.`,
      messages: [
        { role: 'user', content: `Создайте презентацию на тему "${topic}" из ${numSlides} слайдов.` }
      ],
    });

    return response.content[0].text;
  } catch (error: any) {
    console.error('Ошибка при генерации презентации с Claude:', error.message);
    throw new Error(`Не удалось создать презентацию: ${error.message}`);
  }
}

/**
 * Настраивает маршруты API для работы с Anthropic
 * @param app Express приложение
 */
export function setupAnthropicRoutes(app: Express) {
  // Маршрут для анализа кода
  app.post('/api/ai/analyze-code', async (req: Request, res: Response) => {
    try {
      const { code, language } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ error: 'Код и язык программирования обязательны' });
      }
      
      const analysis = await analyzeCodeWithClaude(code, language);
      res.json({ analysis });
    } catch (error: any) {
      console.error('Ошибка в маршруте /api/ai/analyze-code:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Маршрут для улучшения кода
  app.post('/api/ai/improve-code', async (req: Request, res: Response) => {
    try {
      const { code, language, instructions } = req.body;
      
      if (!code || !language) {
        return res.status(400).json({ error: 'Код и язык программирования обязательны' });
      }
      
      const improvedCode = await generateImprovedCode(code, language, instructions);
      res.json({ improvedCode });
    } catch (error: any) {
      console.error('Ошибка в маршруте /api/ai/improve-code:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Маршрут для анализа изображения
  app.post('/api/ai/analyze-image', async (req: Request, res: Response) => {
    try {
      const { imageBase64, query } = req.body;
      
      if (!imageBase64) {
        return res.status(400).json({ error: 'Изображение обязательно' });
      }
      
      const analysis = await analyzeImageWithClaude(imageBase64, query || '');
      res.json({ analysis });
    } catch (error: any) {
      console.error('Ошибка в маршруте /api/ai/analyze-image:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Маршрут для анализа документа
  app.post('/api/ai/analyze-document', async (req: Request, res: Response) => {
    try {
      const { text, instructions } = req.body;
      
      if (!text) {
        return res.status(400).json({ error: 'Текст документа обязателен' });
      }
      
      const analysis = await analyzeDocumentWithClaude(text, instructions);
      res.json({ analysis });
    } catch (error: any) {
      console.error('Ошибка в маршруте /api/ai/analyze-document:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Маршрут для генерации презентации
  app.post('/api/ai/generate-presentation', async (req: Request, res: Response) => {
    try {
      const { topic, numSlides } = req.body;
      
      if (!topic) {
        return res.status(400).json({ error: 'Тема презентации обязательна' });
      }
      
      const presentation = await generatePresentationWithClaude(topic, numSlides || 5);
      res.json({ presentation });
    } catch (error: any) {
      console.error('Ошибка в маршруте /api/ai/generate-presentation:', error);
      res.status(500).json({ error: error.message });
    }
  });
}