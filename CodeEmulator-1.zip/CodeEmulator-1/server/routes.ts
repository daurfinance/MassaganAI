import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { 
  handleGithubImport, 
  handleZipImport, 
  uploadZipMiddleware 
} from "./import-handlers";
import { 
  analyzeCodeAndGenerateUI, 
  generateUIPreview, 
  generateFrontendFromBackend,
  generateFullProject
} from "./ai-service";
import { setupStripeRoutes } from "./stripe-service";
import { setupMediaRoutes } from "./media-service";
import { setupTelegramRoutes, setupTelegramService } from "./telegram-service";
import { setupSocialMediaRoutes } from "./social-media-service";
import { setupPresentationRoutes } from "./presentation-service";
import { setupAILabRoutes } from "./ai-lab-service";
import { setupAnthropicRoutes } from "./anthropic-service-fixed";
import { setupStorageRoutes } from "./google-drive-service";
import express from "express";

export async function registerRoutes(app: Express): Promise<Server> {
  // Статические файлы
  app.use('/public', express.static('public'));
  
  // Инициализируем Telegram бота
  setupTelegramService();
  
  // Настройка маршрутов
  await setupStripeRoutes(app); // Stripe платежи
  await setupMediaRoutes(app);   // Медиа сервис
  setupTelegramRoutes(app);      // Telegram интеграция
  setupSocialMediaRoutes(app);   // Сервис социальных медиа
  setupPresentationRoutes(app);  // Презентации, чертежи и 3D модели
  setupAnthropicRoutes(app);     // Сервис Anthropic AI (Claude)
  setupAILabRoutes(app);         // ИИ-лаборатория
  setupStorageRoutes(app); // Google Drive для работы с файлами
  
  // ИИ-эмулятор маршруты
  app.post("/api/ai/analyze-code", async (req: Request, res: Response) => {
    try {
      const { htmlCode, cssCode, jsCode, backendCode, language, device, system } = req.body;
      
      // Проверка правильности запроса
      if (!htmlCode && !cssCode && !jsCode && !backendCode) {
        return res.status(400).json({ error: "At least one of htmlCode, cssCode, jsCode, or backendCode is required" });
      }
      
      // Если есть код бэкенда, обрабатываем его для получения фронтенда
      let generatedFrontend = null;
      if (backendCode) {
        try {
          generatedFrontend = await generateFrontendFromBackend(backendCode);
        } catch (error) {
          console.error("Error generating frontend from backend:", error);
        }
      }
      
      // Анализируем HTML, CSS и JS код для создания эмуляции
      const result = await analyzeCodeAndGenerateUI(
        htmlCode || (generatedFrontend?.htmlCode || ""),
        cssCode || (generatedFrontend?.cssCode || ""),
        jsCode || (generatedFrontend?.jsCode || ""),
        backendCode,
        language,
        device,
        system
      );
      
      // Формируем адаптированный ответ для различных устройств и систем
      const adaptedResult = {
        htmlCode: result.htmlCode,
        cssCode: result.cssCode,
        jsCode: result.jsCode,
        description: result.description,
        features: result.features,
        device,
        system,
        language
      };
      
      return res.json(adaptedResult);
    } catch (error: any) {
      console.error("Error analyzing code:", error);
      return res.status(500).json({ error: error.message || "Error analyzing code" });
    }
  });
  
  app.post("/api/import/github", async (req: Request, res: Response) => {
    try {
      const { url } = req.body;
      
      if (!url) {
        return res.status(400).json({ error: "GitHub URL is required" });
      }
      
      const result = await handleGithubImport(req, res);
      return result;
    } catch (error: any) {
      console.error("Error importing from GitHub:", error);
      return res.status(500).json({ error: error.message || "Error importing from GitHub" });
    }
  });
  
  app.post("/api/import/file", uploadZipMiddleware, async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "File is required" });
      }
      
      const result = await handleZipImport(req, res);
      return result;
    } catch (error: any) {
      console.error("Error importing from file:", error);
      return res.status(500).json({ error: error.message || "Error importing from file" });
    }
  });
  
  // API Routes
  
  // Get all projects
  app.get("/api/projects", async (req: Request, res: Response) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  // Get a single project
  app.get("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(project);
    } catch (error: any) {
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  // Create a new project
  app.post("/api/projects", async (req: Request, res: Response) => {
    try {
      const validatedData = insertProjectSchema.parse(req.body);
      const newProject = await storage.createProject(validatedData);
      res.status(201).json(newProject);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  // Update a project
  app.put("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const validatedData = insertProjectSchema.parse(req.body);
      const updatedProject = await storage.updateProject(id, validatedData);
      
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.json(updatedProject);
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid project data", errors: fromZodError(error).message });
      }
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  // Delete a project
  app.delete("/api/projects/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid project ID" });
      }
      
      const success = await storage.deleteProject(id);
      if (!success) {
        return res.status(404).json({ message: "Project not found" });
      }
      
      res.status(204).send();
    } catch (error: any) {
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Эти маршруты уже определены выше
  // Импорт из GitHub и ZIP-файла

  // ИИ анализ кода и генерация интерфейса
  app.post("/api/ai/analyze", async (req: Request, res: Response) => {
    try {
      const { htmlCode, cssCode, jsCode, backendCode, language, device, system } = req.body;
      
      if (!htmlCode && !cssCode && !jsCode && !backendCode) {
        return res.status(400).json({ message: "Необходимо предоставить код для анализа" });
      }
      
      const result = await analyzeCodeAndGenerateUI(
        htmlCode || "", 
        cssCode || "", 
        jsCode || "",
        backendCode,
        language,
        device,
        system
      );
      
      res.json(result);
    } catch (error: any) {
      console.error("Ошибка при анализе кода:", error);
      res.status(500).json({ 
        message: "Не удалось проанализировать код", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Генерация превью интерфейса
  app.post("/api/ai/preview", async (req: Request, res: Response) => {
    try {
      const { htmlCode, cssCode, jsCode } = req.body;
      
      if (!htmlCode && !cssCode && !jsCode) {
        return res.status(400).json({ message: "Необходимо предоставить код для превью" });
      }
      
      const result = await generateUIPreview(
        htmlCode || "", 
        cssCode || "", 
        jsCode || ""
      );
      
      res.json(result);
    } catch (error: any) {
      console.error("Ошибка при генерации превью:", error);
      res.status(500).json({ 
        message: "Не удалось создать превью интерфейса", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Генерация фронтенда из бэкенд кода
  app.post("/api/ai/generate-frontend", async (req: Request, res: Response) => {
    try {
      const { backendCode } = req.body;
      
      if (!backendCode) {
        return res.status(400).json({ message: "Необходимо предоставить бэкенд код" });
      }
      
      const result = await generateFrontendFromBackend(backendCode);
      res.json(result);
    } catch (error: any) {
      console.error("Ошибка при генерации фронтенда:", error);
      res.status(500).json({ 
        message: "Не удалось сгенерировать фронтенд из бэкенд кода", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Генерация полного проекта из описания
  app.post("/api/ai/generate-project", async (req: Request, res: Response) => {
    try {
      const { description } = req.body;
      
      if (!description) {
        return res.status(400).json({ message: "Необходимо предоставить описание проекта" });
      }
      
      const result = await generateFullProject(description);
      res.json(result);
    } catch (error: any) {
      console.error("Ошибка при генерации проекта:", error);
      res.status(500).json({ 
        message: "Не удалось сгенерировать проект по описанию", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
