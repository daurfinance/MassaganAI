/**
 * MassaganAI: Сервис для создания презентаций, чертежей и 3D моделей
 * Поддерживает генерацию моков, анимированных презентаций и озвучивание по промптам
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import { Express, Request, Response } from 'express';
import * as fs from 'fs';
import * as path from 'path';
import { spawn } from 'child_process';
import { v4 as uuidv4 } from 'uuid';
import { fileURLToPath } from 'url';

// ESM модуль не имеет доступа к __dirname, поэтому мы создаем его вручную
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Путь к директории с python скриптами
const PYTHON_SCRIPTS_DIR = path.join(__dirname, '../scripts');
// Путь к директории для сохранения временных файлов
const TEMP_DIR = path.join(__dirname, '../temp');
// Путь к директории для сохранения готовых презентаций
const PRESENTATIONS_DIR = path.join(__dirname, '../public/presentations');
// Путь к директории для сохранения чертежей
const BLUEPRINTS_DIR = path.join(__dirname, '../public/blueprints');
// Путь к директории для сохранения 3D моделей
const MODELS_DIR = path.join(__dirname, '../public/models');

// Типы генерируемых презентаций
type PresentationType = 'standard' | 'animated' | 'infographic' | 'pitch' | 'mockup';
// Типы генерируемых чертежей
type BlueprintType = 'architecture' | 'engineering' | 'electrical' | 'mechanical' | 'interior';
// Типы генерируемых 3D моделей
type ModelType = 'simple' | 'detailed' | 'animation' | 'product' | 'scene';

// Структура запроса на создание презентации
interface PresentationRequest {
  prompt: string;
  type: PresentationType;
  slides?: number;
  audioEnabled?: boolean;
  language?: string;
  theme?: string;
  style?: string;
}

// Структура запроса на создание чертежа
interface BlueprintRequest {
  prompt: string;
  type: BlueprintType;
  dimensions?: string;
  details?: string;
  format?: 'svg' | 'pdf' | 'png';
  scale?: string;
}

// Структура запроса на создание 3D модели
interface ModelRequest {
  prompt: string;
  type: ModelType;
  format?: 'obj' | 'stl' | 'glb' | 'fbx';
  complexity?: 'low' | 'medium' | 'high';
  textures?: boolean;
  animation?: boolean;
}

// Результат создания презентации
interface PresentationResult {
  id: string;
  prompt: string;
  type: PresentationType;
  pptxPath?: string;
  pdfPath?: string;
  videoPath?: string;
  audioPath?: string;
  thumbnailPath?: string;
  slidesCount: number;
  createdAt: Date;
}

// Результат создания чертежа
interface BlueprintResult {
  id: string;
  prompt: string;
  type: BlueprintType;
  filePath: string;
  thumbnailPath?: string;
  dimensions?: string;
  createdAt: Date;
}

// Результат создания 3D модели
interface ModelResult {
  id: string;
  prompt: string;
  type: ModelType;
  filePath: string;
  thumbnailPath?: string;
  format: string;
  createdAt: Date;
}

/**
 * Инициализирует директории для хранения файлов
 */
function initializeDirectories() {
  const directories = [
    PYTHON_SCRIPTS_DIR,
    TEMP_DIR,
    PRESENTATIONS_DIR,
    BLUEPRINTS_DIR,
    MODELS_DIR
  ];

  directories.forEach(dir => {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`Created directory: ${dir}`);
    }
  });
}

/**
 * Выполняет Python скрипт с заданными параметрами
 * @param scriptPath Путь к скрипту
 * @param args Аргументы командной строки
 * @returns Вывод скрипта
 */
async function executePythonScript(scriptPath: string, args: string[] = []): Promise<string> {
  return new Promise((resolve, reject) => {
    const process = spawn('python', [scriptPath, ...args]);
    
    let output = '';
    let error = '';
    
    process.stdout.on('data', (data) => {
      output += data.toString();
    });
    
    process.stderr.on('data', (data) => {
      error += data.toString();
    });
    
    process.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Python script exited with code ${code}: ${error}`));
      } else {
        resolve(output.trim());
      }
    });
  });
}

/**
 * Создает Python скрипт для генерации презентации
 * @returns Путь к созданному скрипту
 */
function createPresentationScript(): string {
  const scriptPath = path.join(PYTHON_SCRIPTS_DIR, 'generate_presentation.py');
  
  // Проверяем, существует ли скрипт
  if (fs.existsSync(scriptPath)) {
    return scriptPath;
  }
  
  // Создаем скрипт для генерации презентаций
  const scriptContent = `
import sys
import os
import json
import time
import random
from pathlib import Path
from gtts import gTTS
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image, ImageDraw, ImageFont

def create_slide_content(prs, prompt, slide_count, theme):
    """Generate slide content based on prompt"""
    # In a real implementation, this would use AI to generate content
    # For now, we'll create basic slides with placeholder text
    
    # First slide (title)
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    
    title.text = f"Presentation: {prompt}"
    subtitle.text = "Generated by MassaganAI"
    
    # Content slides
    for i in range(1, slide_count):
        content_slide_layout = prs.slide_layouts[1]
        slide = prs.slides.add_slide(content_slide_layout)
        title = slide.shapes.title
        content = slide.placeholders[1]
        
        title.text = f"Slide {i}"
        content.text = f"This is placeholder content for {prompt} - slide {i}"
        
        # Add a simple shape to the slide for visual interest
        left = Inches(random.uniform(1, 8))
        top = Inches(random.uniform(3, 5))
        width = Inches(random.uniform(1, 2))
        height = Inches(random.uniform(1, 2))
        
        shape_type = random.choice([1, 2, 3, 4])  # Different shape types
        shape = slide.shapes.add_shape(shape_type, left, top, width, height)
        
        # Random color
        r, g, b = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor(r, g, b)
    
    return prs

def create_presentation(prompt, slide_count=5, output_dir=".", theme="modern"):
    """Create a PowerPoint presentation"""
    prs = Presentation()
    
    # Set slide size to widescreen (16:9)
    prs.slide_width = Inches(16)
    prs.slide_height = Inches(9)
    
    # Generate content
    prs = create_slide_content(prs, prompt, slide_count, theme)
    
    # Save the presentation
    output_path = os.path.join(output_dir, "presentation.pptx")
    prs.save(output_path)
    
    return output_path

def create_mockup(prompt, output_dir="."):
    """Create a mockup image of the presentation"""
    width, height = 1600, 900
    img = Image.new('RGB', (width, height), color=(255, 255, 255))
    d = ImageDraw.Draw(img)
    
    # Try to use a fancy font if available, otherwise use default
    try:
        font_title = ImageFont.truetype("Arial", 60)
        font_text = ImageFont.truetype("Arial", 40)
    except:
        font_title = ImageFont.load_default()
        font_text = ImageFont.load_default()
    
    # Draw title
    d.rectangle([(0, 0), (width, 120)], fill=(52, 152, 219))
    d.text((width//2, 60), f"Mockup: {prompt}", font=font_title, fill=(255, 255, 255), anchor="mm")
    
    # Draw slide area with content
    d.rectangle([(50, 170), (width-50, height-50)], outline=(200, 200, 200), width=2)
    
    # Draw some placeholder elements
    d.rectangle([(100, 220), (width-100, 320)], fill=(240, 240, 240))
    d.text((width//2, 270), "Slide Content Area", font=font_text, fill=(100, 100, 100), anchor="mm")
    
    # Draw some bullets
    bullet_y = 400
    for i in range(4):
        d.ellipse([(100, bullet_y-10), (120, bullet_y+10)], fill=(52, 152, 219))
        d.text((150, bullet_y), f"Bullet point {i+1}", font=font_text, fill=(0, 0, 0), anchor="lm")
        bullet_y += 80
    
    # Save the mockup
    output_path = os.path.join(output_dir, "mockup.png")
    img.save(output_path)
    
    # Generate a thumbnail
    thumb = img.resize((400, 225))
    thumb_path = os.path.join(output_dir, "thumbnail.png")
    thumb.save(thumb_path)
    
    return output_path, thumb_path

def create_audio_narration(prompt, language="en", output_dir="."):
    """Create audio narration for the presentation"""
    # Create a simple script based on the prompt
    script = f"Welcome to this presentation about {prompt}. This is an example of text-to-speech narration generated by MassaganAI."
    
    # Generate TTS audio
    tts = gTTS(text=script, lang=language, slow=False)
    output_path = os.path.join(output_dir, "narration.mp3")
    tts.save(output_path)
    
    return output_path

def main():
    # Parse command line arguments
    if len(sys.argv) < 3:
        print("Usage: python generate_presentation.py <prompt> <type> [slides] [audio] [language] [theme] [output_dir]")
        sys.exit(1)
    
    prompt = sys.argv[1]
    pres_type = sys.argv[2]
    slides = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    audio_enabled = sys.argv[4].lower() == "true" if len(sys.argv) > 4 else False
    language = sys.argv[5] if len(sys.argv) > 5 else "en"
    theme = sys.argv[6] if len(sys.argv) > 6 else "modern"
    output_dir = sys.argv[7] if len(sys.argv) > 7 else "."
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    result = {
        "prompt": prompt,
        "type": pres_type,
        "slides": slides
    }
    
    # Create based on type
    if pres_type == "mockup":
        mockup_path, thumbnail_path = create_mockup(prompt, output_dir)
        result["mockupPath"] = mockup_path
        result["thumbnailPath"] = thumbnail_path
    else:
        # Create standard presentation
        pptx_path = create_presentation(prompt, slides, output_dir, theme)
        result["pptxPath"] = pptx_path
        
        # Create audio if enabled
        if audio_enabled:
            audio_path = create_audio_narration(prompt, language, output_dir)
            result["audioPath"] = audio_path
    
    # Output result as JSON
    print(json.dumps(result))

if __name__ == "__main__":
    main()
`;

  // Записываем скрипт в файл
  fs.writeFileSync(scriptPath, scriptContent);
  console.log(`Created presentation script at: ${scriptPath}`);
  
  return scriptPath;
}

/**
 * Создает Python скрипт для генерации чертежей
 * @returns Путь к созданному скрипту
 */
function createBlueprintScript(): string {
  const scriptPath = path.join(PYTHON_SCRIPTS_DIR, 'generate_blueprint.py');
  
  // Проверяем, существует ли скрипт
  if (fs.existsSync(scriptPath)) {
    return scriptPath;
  }
  
  // Создаем скрипт для генерации чертежей
  const scriptContent = `
import sys
import os
import json
import time
import random
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

def create_architecture_blueprint(prompt, dimensions, output_dir="."):
    """Create an architectural blueprint"""
    # Create a figure
    fig, ax = plt.subplots(figsize=(12, 8), facecolor='white')
    
    # Set background to light blue like a blueprint
    ax.set_facecolor('#DFEEFF')
    
    # Draw walls (rectangles)
    ax.add_patch(plt.Rectangle((1, 1), 8, 6, fill=False, edgecolor='blue', linewidth=2))
    ax.add_patch(plt.Rectangle((1, 1), 3, 4, fill=False, edgecolor='blue', linewidth=2))
    ax.add_patch(plt.Rectangle((4, 1), 5, 3, fill=False, edgecolor='blue', linewidth=2))
    
    # Draw doors
    ax.add_patch(plt.Rectangle((4, 1), 1, 0.1, fill=True, edgecolor='blue', linewidth=1))
    ax.add_patch(plt.Rectangle((4, 4), 0.1, 1, fill=True, edgecolor='blue', linewidth=1))
    
    # Draw windows
    ax.add_patch(plt.Rectangle((2, 1), 1, 0.1, fill=True, edgecolor='blue', linewidth=1))
    ax.add_patch(plt.Rectangle((6, 1), 1, 0.1, fill=True, edgecolor='blue', linewidth=1))
    
    # Draw some furniture
    ax.add_patch(plt.Rectangle((1.5, 1.5), 2, 1, fill=True, edgecolor='blue', alpha=0.3, linewidth=1))
    ax.add_patch(plt.Rectangle((5, 2), 2, 1, fill=True, edgecolor='blue', alpha=0.3, linewidth=1))
    ax.add_patch(plt.Circle((7, 5), 0.5, fill=True, alpha=0.3, edgecolor='blue', linewidth=1))
    
    # Add measurements
    ax.text(5, 0.7, "8m", horizontalalignment='center')
    ax.text(0.7, 4, "6m", rotation=90, verticalalignment='center')
    
    # Add prompt as title
    ax.set_title(f"Blueprint: {prompt}\\nDimensions: {dimensions}", fontsize=14)
    
    # Remove axis ticks
    ax.set_xticks([])
    ax.set_yticks([])
    
    # Add grid for blueprint effect
    ax.grid(True, linestyle='-', color='#9CC0E5', alpha=0.3)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save the blueprint
    output_path = os.path.join(output_dir, "blueprint.svg")
    plt.savefig(output_path, format='svg', dpi=300, bbox_inches='tight')
    
    # Also save a PNG version for thumbnail
    thumb_path = os.path.join(output_dir, "thumbnail.png")
    plt.savefig(thumb_path, format='png', dpi=150, bbox_inches='tight')
    
    plt.close()
    
    return output_path, thumb_path

def create_engineering_blueprint(prompt, details, output_dir="."):
    """Create an engineering technical drawing"""
    # Create a figure
    fig, ax = plt.subplots(figsize=(12, 8), facecolor='white')
    
    # Set background to light brown like an old engineering drawing
    ax.set_facecolor('#F5F0E6')
    
    # Draw a technical part
    # Main body
    ax.add_patch(plt.Rectangle((3, 3), 4, 2, fill=False, edgecolor='black', linewidth=2))
    
    # Circles for holes
    ax.add_patch(plt.Circle((4, 4), 0.3, fill=False, edgecolor='black', linewidth=1))
    ax.add_patch(plt.Circle((6, 4), 0.3, fill=False, edgecolor='black', linewidth=1))
    
    # Dimension lines
    ax.arrow(3, 2.5, 4, 0, head_width=0.1, head_length=0.1, fc='black', ec='black')
    ax.arrow(7, 2.5, -4, 0, head_width=0.1, head_length=0.1, fc='black', ec='black')
    ax.text(5, 2.3, "4.00", horizontalalignment='center')
    
    ax.arrow(2.5, 3, 0, 2, head_width=0.1, head_length=0.1, fc='black', ec='black')
    ax.arrow(2.5, 5, 0, -2, head_width=0.1, head_length=0.1, fc='black', ec='black')
    ax.text(2.3, 4, "2.00", verticalalignment='center', rotation=90)
    
    # Crosshatch pattern for cut surface
    # Draw diagonal lines
    for i in np.arange(2.7, 7.3, 0.2):
        ax.plot([i, i+1], [5.3, 4.3], 'k-', linewidth=0.5, alpha=0.5)
    
    # Add details as annotations
    ax.text(5, 6, f"Details: {details}", horizontalalignment='center')
    
    # Add prompt as title
    ax.set_title(f"Engineering Drawing: {prompt}", fontsize=14)
    
    # Remove axis ticks
    ax.set_xticks([])
    ax.set_yticks([])
    
    # Add grid for drawing effect
    ax.grid(True, linestyle='-', color='#CCCCCC', alpha=0.2)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save the blueprint
    output_path = os.path.join(output_dir, "engineering.svg")
    plt.savefig(output_path, format='svg', dpi=300, bbox_inches='tight')
    
    # Also save a PNG version for thumbnail
    thumb_path = os.path.join(output_dir, "thumbnail.png")
    plt.savefig(thumb_path, format='png', dpi=150, bbox_inches='tight')
    
    plt.close()
    
    return output_path, thumb_path

def main():
    # Parse command line arguments
    if len(sys.argv) < 3:
        print("Usage: python generate_blueprint.py <prompt> <type> [dimensions/details] [format] [output_dir]")
        sys.exit(1)
    
    prompt = sys.argv[1]
    blueprint_type = sys.argv[2]
    details = sys.argv[3] if len(sys.argv) > 3 else "10m x 8m"
    output_format = sys.argv[4] if len(sys.argv) > 4 else "svg"
    output_dir = sys.argv[5] if len(sys.argv) > 5 else "."
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    result = {
        "prompt": prompt,
        "type": blueprint_type,
        "details": details
    }
    
    # Create based on type
    if blueprint_type == "architecture":
        output_path, thumbnail_path = create_architecture_blueprint(prompt, details, output_dir)
    else:  # engineering, electrical, mechanical, interior
        output_path, thumbnail_path = create_engineering_blueprint(prompt, details, output_dir)
    
    result["filePath"] = output_path
    result["thumbnailPath"] = thumbnail_path
    
    # Output result as JSON
    print(json.dumps(result))

if __name__ == "__main__":
    main()
`;

  // Записываем скрипт в файл
  fs.writeFileSync(scriptPath, scriptContent);
  console.log(`Created blueprint script at: ${scriptPath}`);
  
  return scriptPath;
}

/**
 * Создает Python скрипт для генерации 3D моделей
 * @returns Путь к созданному скрипту
 */
function create3DModelScript(): string {
  const scriptPath = path.join(PYTHON_SCRIPTS_DIR, 'generate_3d_model.py');
  
  // Проверяем, существует ли скрипт
  if (fs.existsSync(scriptPath)) {
    return scriptPath;
  }
  
  // Создаем скрипт для генерации 3D моделей
  const scriptContent = `
import sys
import os
import json
import time
import random
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from PIL import Image

def create_simple_model(prompt, output_dir="."):
    """Create a simple 3D model visualization"""
    # Create a figure and 3D axis
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # Create a basic shape based on the 'type'
    # For a cube
    vertices = np.array([
        [0, 0, 0],
        [1, 0, 0],
        [1, 1, 0],
        [0, 1, 0],
        [0, 0, 1],
        [1, 0, 1],
        [1, 1, 1],
        [0, 1, 1]
    ])
    
    # Define the edges of the cube
    edges = [
        (0, 1), (1, 2), (2, 3), (3, 0),  # bottom face
        (4, 5), (5, 6), (6, 7), (7, 4),  # top face
        (0, 4), (1, 5), (2, 6), (3, 7)   # connecting edges
    ]
    
    # Plot the vertices
    ax.scatter(vertices[:, 0], vertices[:, 1], vertices[:, 2], color='b')
    
    # Plot the edges
    for edge in edges:
        xs = [vertices[edge[0], 0], vertices[edge[1], 0]]
        ys = [vertices[edge[0], 1], vertices[edge[1], 1]]
        zs = [vertices[edge[0], 2], vertices[edge[1], 2]]
        ax.plot(xs, ys, zs, color='black')
    
    # Add some faces with transparency
    # Bottom face
    x = [vertices[0, 0], vertices[1, 0], vertices[2, 0], vertices[3, 0]]
    y = [vertices[0, 1], vertices[1, 1], vertices[2, 1], vertices[3, 1]]
    z = [vertices[0, 2], vertices[1, 2], vertices[2, 2], vertices[3, 2]]
    ax.plot_trisurf(x, y, z, color='red', alpha=0.6)
    
    # Top face
    x = [vertices[4, 0], vertices[5, 0], vertices[6, 0], vertices[7, 0]]
    y = [vertices[4, 1], vertices[5, 1], vertices[6, 1], vertices[7, 1]]
    z = [vertices[4, 2], vertices[5, 2], vertices[6, 2], vertices[7, 2]]
    ax.plot_trisurf(x, y, z, color='blue', alpha=0.6)
    
    # Add title
    ax.set_title(f"3D Model: {prompt}", fontsize=14)
    
    # Set labels
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    
    # Set aspect ratio to be equal
    ax.set_box_aspect([1, 1, 1])
    
    # Save the visualization
    output_path = os.path.join(output_dir, "model.png")
    plt.savefig(output_path, format='png', dpi=300, bbox_inches='tight')
    
    # Create a mock STL file (in a real system, this would be an actual 3D model file)
    stl_path = os.path.join(output_dir, "model.stl")
    with open(stl_path, 'w') as f:
        f.write(f"solid {prompt}\\n")
        f.write("  facet normal 0 0 0\\n")
        f.write("    outer loop\\n")
        f.write("      vertex 0 0 0\\n")
        f.write("      vertex 1 0 0\\n")
        f.write("      vertex 1 1 0\\n")
        f.write("    endloop\\n")
        f.write("  endfacet\\n")
        f.write(f"endsolid {prompt}\\n")
    
    # Create thumbnail
    thumb_path = os.path.join(output_dir, "thumbnail.png")
    img = Image.open(output_path)
    img.thumbnail((400, 400))
    img.save(thumb_path)
    
    plt.close()
    
    return stl_path, output_path, thumb_path

def create_complex_model(prompt, complexity, output_dir="."):
    """Create a more complex 3D model visualization"""
    # Create a figure and 3D axis
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    
    # Create a more complex shape based on complexity
    if complexity == "low":
        points = 20
    elif complexity == "medium":
        points = 50
    else:  # high
        points = 100
    
    # Create a more complex shape - a twisted torus
    u = np.linspace(0, 2 * np.pi, points)
    v = np.linspace(0, 2 * np.pi, points)
    u, v = np.meshgrid(u, v)
    
    # Major and minor radii
    R, r = 1.5, 0.5
    
    # Compute the coordinates
    x = (R + r * np.cos(v)) * np.cos(u)
    y = (R + r * np.cos(v)) * np.sin(u)
    z = r * np.sin(v) + 0.1 * np.sin(3*u)  # Add a twist
    
    # Plot the surface
    surf = ax.plot_surface(x, y, z, cmap='viridis', alpha=0.8)
    
    # Add a color bar
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5)
    
    # Add title
    ax.set_title(f"3D Model ({complexity} complexity): {prompt}", fontsize=14)
    
    # Set labels
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    
    # Set aspect ratio to be equal
    ax.set_box_aspect([1, 1, 1])
    
    # Save the visualization
    output_path = os.path.join(output_dir, "model.png")
    plt.savefig(output_path, format='png', dpi=300, bbox_inches='tight')
    
    # Create a mock OBJ file (in a real system, this would be an actual 3D model file)
    obj_path = os.path.join(output_dir, "model.obj")
    with open(obj_path, 'w') as f:
        f.write(f"# {prompt} - {complexity} complexity\\n")
        f.write("# Vertices\\n")
        
        # Write some sample vertices
        for i in range(10):
            f.write(f"v {random.uniform(-1, 1)} {random.uniform(-1, 1)} {random.uniform(-1, 1)}\\n")
        
        f.write("# Faces\\n")
        f.write("f 1 2 3\\n")
        f.write("f 1 3 4\\n")
    
    # Create thumbnail
    thumb_path = os.path.join(output_dir, "thumbnail.png")
    img = Image.open(output_path)
    img.thumbnail((400, 400))
    img.save(thumb_path)
    
    plt.close()
    
    return obj_path, output_path, thumb_path

def main():
    # Parse command line arguments
    if len(sys.argv) < 3:
        print("Usage: python generate_3d_model.py <prompt> <type> [format] [complexity] [output_dir]")
        sys.exit(1)
    
    prompt = sys.argv[1]
    model_type = sys.argv[2]
    model_format = sys.argv[3] if len(sys.argv) > 3 else "obj"
    complexity = sys.argv[4] if len(sys.argv) > 4 else "medium"
    output_dir = sys.argv[5] if len(sys.argv) > 5 else "."
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    result = {
        "prompt": prompt,
        "type": model_type,
        "format": model_format,
        "complexity": complexity
    }
    
    # Create based on type and complexity
    if model_type == "simple" or complexity == "low":
        model_path, render_path, thumbnail_path = create_simple_model(prompt, output_dir)
    else:  # detailed, animation, product, scene or higher complexity
        model_path, render_path, thumbnail_path = create_complex_model(prompt, complexity, output_dir)
    
    result["filePath"] = model_path
    result["renderPath"] = render_path
    result["thumbnailPath"] = thumbnail_path
    
    # Output result as JSON
    print(json.dumps(result))

if __name__ == "__main__":
    main()
`;

  // Записываем скрипт в файл
  fs.writeFileSync(scriptPath, scriptContent);
  console.log(`Created 3D model script at: ${scriptPath}`);
  
  return scriptPath;
}

/**
 * Создает презентацию по текстовому описанию
 * @param request Параметры запроса
 * @returns Результат создания презентации
 */
async function generatePresentation(request: PresentationRequest): Promise<PresentationResult> {
  const id = uuidv4();
  const outputDir = path.join(PRESENTATIONS_DIR, id);
  
  // Создаем директорию для хранения файлов презентации
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  try {
    // Создаем скрипт, если его нет
    const scriptPath = createPresentationScript();
    
    // Формируем аргументы для скрипта
    const args = [
      request.prompt,
      request.type,
      String(request.slides || 5),
      String(request.audioEnabled || false),
      request.language || 'ru',
      request.theme || 'modern',
      outputDir
    ];
    
    // Запускаем скрипт
    const output = await executePythonScript(scriptPath, args);
    
    // Разбираем результат
    const result = JSON.parse(output);
    
    // Формируем относительные пути к файлам (для веб-доступа)
    const webPath = `/presentations/${id}`;
    
    const presentationResult: PresentationResult = {
      id,
      prompt: request.prompt,
      type: request.type,
      slidesCount: request.slides || 5,
      createdAt: new Date()
    };
    
    // Добавляем пути к файлам, если они есть
    if (result.pptxPath) {
      presentationResult.pptxPath = `${webPath}/presentation.pptx`;
    }
    
    if (result.mockupPath) {
      presentationResult.pptxPath = `${webPath}/mockup.png`;
    }
    
    if (result.thumbnailPath) {
      presentationResult.thumbnailPath = `${webPath}/thumbnail.png`;
    }
    
    if (result.audioPath) {
      presentationResult.audioPath = `${webPath}/narration.mp3`;
    }
    
    return presentationResult;
  } catch (error) {
    console.error('Error generating presentation:', error);
    throw new Error(`Failed to generate presentation: ${error.message}`);
  }
}

/**
 * Создает чертеж по текстовому описанию
 * @param request Параметры запроса
 * @returns Результат создания чертежа
 */
async function generateBlueprint(request: BlueprintRequest): Promise<BlueprintResult> {
  const id = uuidv4();
  const outputDir = path.join(BLUEPRINTS_DIR, id);
  
  // Создаем директорию для хранения файлов чертежа
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  try {
    // Создаем скрипт, если его нет
    const scriptPath = createBlueprintScript();
    
    // Формируем аргументы для скрипта
    const args = [
      request.prompt,
      request.type,
      request.details || request.dimensions || '10m x 8m',
      request.format || 'svg',
      outputDir
    ];
    
    // Запускаем скрипт
    const output = await executePythonScript(scriptPath, args);
    
    // Разбираем результат
    const result = JSON.parse(output);
    
    // Формируем относительные пути к файлам (для веб-доступа)
    const webPath = `/blueprints/${id}`;
    
    const blueprintResult: BlueprintResult = {
      id,
      prompt: request.prompt,
      type: request.type,
      filePath: `${webPath}/${request.type}.${request.format || 'svg'}`,
      dimensions: request.dimensions,
      createdAt: new Date()
    };
    
    if (result.thumbnailPath) {
      blueprintResult.thumbnailPath = `${webPath}/thumbnail.png`;
    }
    
    return blueprintResult;
  } catch (error) {
    console.error('Error generating blueprint:', error);
    throw new Error(`Failed to generate blueprint: ${error.message}`);
  }
}

/**
 * Создает 3D модель по текстовому описанию
 * @param request Параметры запроса
 * @returns Результат создания 3D модели
 */
async function generate3DModel(request: ModelRequest): Promise<ModelResult> {
  const id = uuidv4();
  const outputDir = path.join(MODELS_DIR, id);
  
  // Создаем директорию для хранения файлов модели
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  try {
    // Создаем скрипт, если его нет
    const scriptPath = create3DModelScript();
    
    // Формируем аргументы для скрипта
    const args = [
      request.prompt,
      request.type,
      request.format || 'obj',
      request.complexity || 'medium',
      outputDir
    ];
    
    // Запускаем скрипт
    const output = await executePythonScript(scriptPath, args);
    
    // Разбираем результат
    const result = JSON.parse(output);
    
    // Формируем относительные пути к файлам (для веб-доступа)
    const webPath = `/models/${id}`;
    
    const modelResult: ModelResult = {
      id,
      prompt: request.prompt,
      type: request.type,
      filePath: `${webPath}/model.${request.format || 'obj'}`,
      format: request.format || 'obj',
      createdAt: new Date()
    };
    
    if (result.thumbnailPath) {
      modelResult.thumbnailPath = `${webPath}/thumbnail.png`;
    }
    
    return modelResult;
  } catch (error) {
    console.error('Error generating 3D model:', error);
    throw new Error(`Failed to generate 3D model: ${error.message}`);
  }
}

/**
 * Настраивает маршруты API для презентаций, чертежей и 3D моделей
 * @param app Express приложение
 */
export function setupPresentationRoutes(app: Express) {
  // Инициализируем директории
  initializeDirectories();
  
  // Маршрут для создания презентации
  app.post('/api/presentations', async (req: Request, res: Response) => {
    try {
      const request = req.body as PresentationRequest;
      
      if (!request.prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }
      
      const result = await generatePresentation(request);
      res.json(result);
    } catch (error) {
      console.error('Error in /api/presentations:', error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Маршрут для создания чертежа
  app.post('/api/blueprints', async (req: Request, res: Response) => {
    try {
      const request = req.body as BlueprintRequest;
      
      if (!request.prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }
      
      const result = await generateBlueprint(request);
      res.json(result);
    } catch (error) {
      console.error('Error in /api/blueprints:', error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Маршрут для создания 3D модели
  app.post('/api/models', async (req: Request, res: Response) => {
    try {
      const request = req.body as ModelRequest;
      
      if (!request.prompt) {
        return res.status(400).json({ error: 'Prompt is required' });
      }
      
      const result = await generate3DModel(request);
      res.json(result);
    } catch (error) {
      console.error('Error in /api/models:', error);
      res.status(500).json({ error: error.message });
    }
  });
}