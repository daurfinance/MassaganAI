import OpenAI from "openai";
import { 
  analyzeCode,
  generateImprovedCode,
  generateFrontendFromBackend as perplexityGenerateFrontend,
  generateProject as perplexityGenerateProject
} from './perplexity-service';

// Создаем клиент OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY, // Используем ключ из переменной окружения
});

// Тип для результата эмуляции
export interface EmulationResult {
  htmlCode: string;
  cssCode: string;
  jsCode: string;
  description: string;
  features: string[];
}

/**
 * Анализирует HTML, CSS и JavaScript код и создает интерактивный интерфейс
 * на основе полученного кода.
 */
export async function analyzeCodeAndGenerateUI(
  htmlCode: string, 
  cssCode: string, 
  jsCode: string, 
  backendCode?: string, 
  language?: string, 
  device?: string, 
  system?: string
): Promise<EmulationResult> {
  try {
    // Определяем фичи на основе предоставленного кода
    const features: string[] = [];
    
    if (htmlCode.trim()) features.push("HTML");
    if (cssCode.trim()) features.push("CSS");
    if (jsCode.trim()) features.push("JavaScript");
    
    // Добавляем язык бэкенда если он указан
    if (backendCode && language) {
      features.push(language.charAt(0).toUpperCase() + language.slice(1));
    }
    
    // Добавляем информацию об устройстве и системе
    if (device) {
      features.push(`${device.charAt(0).toUpperCase() + device.slice(1)} UI`);
    }
    
    if (system) {
      features.push(`${system.charAt(0).toUpperCase() + system.slice(1)} Compatible`);
    }
    
    // Объединяем код для анализа
    const fullCode = `
HTML:
\`\`\`html
${htmlCode}
\`\`\`

CSS:
\`\`\`css
${cssCode}
\`\`\`

JavaScript:
\`\`\`javascript
${jsCode}
\`\`\`
`;

    // Формируем запрос к OpenAI для анализа кода
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // новейшая мультимодальная модель
      messages: [
        {
          role: "system",
          content: `Ты эксперт по веб-разработке. Проанализируй HTML, CSS и JavaScript код и выполни следующие задачи:
          
1. Проанализируй структуру кода и его функциональность
2. Создай улучшенную версию интерфейса с современным дизайном на основе анализа, улучшая существующий HTML/CSS, но сохраняя функциональность JavaScript
3. Ответ должен содержать:
   - Краткий анализ кода (несколько предложений)
   - Улучшенный HTML код (полностью рабочий)
   - Улучшенный CSS код (с современным дизайном)
   - Оригинальный JS код с минимальными изменениями для совместимости
   - Список выявленных функций/особенностей кода (до 5 пунктов)
4. Формат ответа должен быть в JSON:
   {
     "description": "Краткий анализ кода",
     "htmlCode": "Улучшенный HTML код",
     "cssCode": "Улучшенный CSS код",
     "jsCode": "Оригинальный или улучшенный JS код",
     "features": ["Особенность 1", "Особенность 2", "..."]
   }
          
Важно: Ответ должен содержать только валидный JSON без дополнительного текста.`
        },
        {
          role: "user",
          content: fullCode
        }
      ],
      response_format: { type: "json_object" }, // запрашиваем ответ в JSON формате
    });

    // Получаем и парсим результат
    const content = response.choices[0].message.content || '{"description":"Не удалось проанализировать код","htmlCode":"","cssCode":"","jsCode":"","features":[]}';
    const result = JSON.parse(content);
    
    // Обработка и преобразование разных возможных форматов ответа
    const emulationResult: EmulationResult = {
      htmlCode: result.htmlCode || result.html || htmlCode,
      cssCode: result.cssCode || result.css || cssCode,
      jsCode: result.jsCode || result.js || jsCode,
      description: result.description || result.analysis || "Анализ успешно выполнен",
      features: result.features || []
    };
    
    // Если поле features отсутствует, создаем его из анализа
    if (!emulationResult.features || emulationResult.features.length === 0) {
      // Извлекаем ключевые особенности из анализа, если они есть
      if (result.analysis) {
        emulationResult.features = [
          "Проанализированный код",
          "Улучшенный интерфейс",
          "Современный дизайн"
        ];
      }
    }
    
    return emulationResult;
    
  } catch (error) {
    console.error("Ошибка при анализе кода:", error);
    // Возвращаем базовый результат с исходным кодом в случае ошибки
    return {
      htmlCode: htmlCode || "",
      cssCode: cssCode || "",
      jsCode: jsCode || "",
      description: "Произошла ошибка при анализе кода. Возвращаем исходную версию.",
      features: ["Исходный код без изменений"]
    };
  }
}

/**
 * Генерирует превью интерфейса на основе HTML, CSS и JavaScript кода
 */
export async function generateUIPreview(htmlCode: string, cssCode: string, jsCode: string) {
  try {
    // Создаем HTML страницу для визуализации
    const htmlPage = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
${cssCode}
  </style>
</head>
<body>
${htmlCode}
<script>
${jsCode}
</script>
</body>
</html>
`;

    // Запрашиваем OpenAI для визуализации UI
    // В будущем можно заменить на реальный рендеринг, если потребуется
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `Опиши, как выглядит веб-интерфейс, основанный на приведенном HTML, CSS и JavaScript. 
          Предоставь детальное описание, фокусируясь на:
          1. Основном макете и структуре страницы
          2. Цветовой схеме и визуальном стиле
          3. Интерактивных элементах и их функциональности
          
          Опиши все это на русском языке в пределах 200 слов.`
        },
        {
          role: "user", 
          content: htmlPage
        }
      ]
    });

    return {
      description: response.choices[0].message.content || "Описание недоступно",
      preview: htmlPage
    };
  } catch (error) {
    console.error("Ошибка при генерации превью:", error);
    throw new Error(
      `Ошибка при генерации превью: ${error instanceof Error ? error.message : "Неизвестная ошибка"}`
    );
  }
}

/**
 * Генерирует фронтенд на основе бэкенд кода
 * @returns EmulationResult для совместимости с форматом эмулятора
 */
export async function generateFrontendFromBackend(backendCode: string): Promise<EmulationResult> {
  try {
    // Используем Perplexity API для генерации фронтенда
    const result = await perplexityGenerateFrontend(backendCode);
    
    // Преобразуем компоненты и страницы в единый HTML и CSS код
    let htmlCode = '';
    let cssCode = '';
    let jsCode = '';
    
    // Собираем HTML-код из компонентов и страниц
    if (result.components && Array.isArray(result.components)) {
      const componentHtml = result.components
        .map(comp => `<!-- Component: ${comp.name} -->\n${comp.code}`)
        .join('\n\n');
      htmlCode += componentHtml;
    }
    
    if (result.pages && Array.isArray(result.pages)) {
      const pagesHtml = result.pages
        .map(page => `<!-- Page: ${page.name} -->\n${page.code}`)
        .join('\n\n');
      htmlCode += '\n\n' + pagesHtml;
    }
    
    // Извлекаем CSS из компонентов (если есть)
    const styles = (result as any).styles;
    if (styles) {
      cssCode = styles;
    } else {
      // Попробуем извлечь CSS из HTML-кода
      const cssRegex = /<style[^>]*>([\s\S]*?)<\/style>/g;
      let match;
      while ((match = cssRegex.exec(htmlCode)) !== null) {
        cssCode += match[1] + '\n';
      }
      
      // Удаляем теги style из HTML
      htmlCode = htmlCode.replace(/<style[^>]*>[\s\S]*?<\/style>/g, '');
    }
    
    // Извлекаем JavaScript из HTML-кода
    const jsRegex = /<script[^>]*>([\s\S]*?)<\/script>/g;
    let jsMatch;
    while ((jsMatch = jsRegex.exec(htmlCode)) !== null) {
      jsCode += jsMatch[1] + '\n';
    }
    
    // Удаляем теги script из HTML
    htmlCode = htmlCode.replace(/<script[^>]*>[\s\S]*?<\/script>/g, '');
    
    // Получаем или создаем описание
    const description = result.analysis || 
      `Фронтенд сгенерирован на основе бэкенд-кода. Создано ${result.components?.length || 0} компонентов и ${result.pages?.length || 0} страниц.`;
    
    // Получаем или создаем список функций
    const features = [
      "Сгенерированный пользовательский интерфейс",
      "Автоматическое создание компонентов",
      "Интеграция с бэкенд API"
    ];
    
    // Собираем результат в формате, совместимом с EmulationResult
    return {
      htmlCode,
      cssCode,
      jsCode,
      description,
      features
    };
  } catch (error) {
    console.error("Ошибка при генерации фронтенда:", error);
    // Возвращаем базовый резульат в случае ошибки
    return {
      htmlCode: `<div>
        <h1>Ошибка генерации фронтенда</h1>
        <p>Не удалось сгенерировать фронтенд из предоставленного бэкенд-кода.</p>
        <pre>${backendCode.substring(0, 100)}...</pre>
      </div>`,
      cssCode: `
        body { font-family: system-ui, sans-serif; padding: 2rem; }
        h1 { color: #e11d48; }
        pre { background: #f1f5f9; padding: 1rem; border-radius: 0.5rem; }
      `,
      jsCode: '',
      description: "Произошла ошибка при генерации фронтенда из бэкенд-кода.",
      features: ["Ошибка генерации"]
    };
  }
}

/**
 * Генерирует полноценный веб-проект на основе описания
 */
export async function generateFullProject(description: string) {
  try {
    // Используем Perplexity API для генерации проекта
    const result = await perplexityGenerateProject(description);
    
    return {
      analysis: result.analysis,
      backend: result.backend || { routes: [], models: [], server: null },
      frontend: result.frontend || { components: [], pages: [], styles: null }
    };
  } catch (error) {
    console.error("Ошибка при генерации проекта:", error);
    throw new Error(
      `Ошибка при генерации проекта: ${error instanceof Error ? error.message : "Неизвестная ошибка"}`
    );
  }
}