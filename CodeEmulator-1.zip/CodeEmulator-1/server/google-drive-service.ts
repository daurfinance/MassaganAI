/**
 * MassaganAI: Сервис для работы с Google Drive
 * Обрабатывает загрузку файлов, их получение и эмуляцию кода
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import { Express, Request, Response } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import os from "os";
import AdmZip from "adm-zip";
import { analyzeCodeAndGenerateUI } from "./ai-service";
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { google } from 'googleapis';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Локальное хранилище для случаев, когда Google Drive недоступен
const LOCAL_STORAGE_DIR = path.join(__dirname, '..', 'temp', 'storage');
if (!fs.existsSync(LOCAL_STORAGE_DIR)) {
  fs.mkdirSync(LOCAL_STORAGE_DIR, { recursive: true });
}

// Настройка для Google Drive API
let drive: any = null;
let projectsFolderId: string = 'massaganai-projects'; // ID папки в Google Drive для проектов

/**
 * Создает папку для проектов в Google Drive, если её нет
 */
async function createProjectsFolder() {
  try {
    // Проверяем, существует ли папка
    const response = await drive.files.list({
      q: "name='massaganai-projects' and mimeType='application/vnd.google-apps.folder'",
      fields: 'files(id, name)',
      spaces: 'drive'
    });
    
    if (response.data.files && response.data.files.length > 0) {
      // Папка уже существует, сохраняем её ID
      projectsFolderId = response.data.files[0].id;
      console.log(`Найдена папка для проектов с ID: ${projectsFolderId}`);
      return;
    }
    
    // Создаем новую папку
    const folderMetadata = {
      name: 'massaganai-projects',
      mimeType: 'application/vnd.google-apps.folder'
    };
    
    const folder = await drive.files.create({
      resource: folderMetadata,
      fields: 'id'
    });
    
    projectsFolderId = folder.data.id;
    
    // Устанавливаем публичный доступ на чтение
    await drive.permissions.create({
      fileId: projectsFolderId,
      requestBody: {
        role: 'reader',
        type: 'anyone'
      }
    });
    
    console.log(`Создана папка для проектов с ID: ${projectsFolderId}`);
  } catch (error) {
    console.error('Ошибка при создании папки для проектов:', error);
  }
}

// Пытаемся инициализировать Google Drive API
try {
  // Загружаем учетные данные из файла
  const serviceAccountPath = path.join(process.cwd(), 'service-account.json');
  
  if (!fs.existsSync(serviceAccountPath)) {
    console.log('Отсутствует файл учетных данных Google Drive. Используем локальное хранилище.');
  } else {
    // Инициализируем аутентификацию с использованием файла сервисного аккаунта
    const auth = new google.auth.GoogleAuth({
      keyFile: serviceAccountPath,
      scopes: ['https://www.googleapis.com/auth/drive']
    });
    
    // Создаем экземпляр Drive API
    drive = google.drive({ version: 'v3', auth });
    
    console.log('Google Drive API успешно инициализирован с использованием сервисного аккаунта');
    
    // Создаем основную папку для проектов MassaganAI, если её нет
    createProjectsFolder();
  }
} catch (error) {
  console.error('Ошибка при инициализации Google Drive API:', error);
  console.log('Используем локальное хранилище в качестве запасного варианта');
}

// Настройка multer для временного хранения загружаемых файлов
const storage = multer.diskStorage({
  destination: function (req: Request, file: Express.Multer.File, cb: (error: Error | null, destination: string) => void) {
    const tempDir = path.join(os.tmpdir(), 'massagan-uploads');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    cb(null, tempDir);
  },
  filename: function (req: Request, file: Express.Multer.File, cb: (error: Error | null, filename: string) => void) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

export const upload = multer({ storage: storage });

/**
 * Загружает файл в Google Drive или локальное хранилище
 * @param filePath Локальный путь к файлу
 * @param destination Путь назначения (используется в качестве имени файла)
 * @returns Публичный URL файла
 */
export async function uploadFile(filePath: string, destination: string): Promise<string> {
  try {
    if (drive) {
      // Используем Google Drive
      const fileName = path.basename(destination);
      const fileMetadata = {
        name: fileName,
        parents: [projectsFolderId] // ID папки в Google Drive
      };
      
      const media = {
        mimeType: getMimeType(fileName),
        body: fs.createReadStream(filePath)
      };
      
      const response = await drive.files.create({
        resource: fileMetadata,
        media: media,
        fields: 'id,webViewLink'
      });
      
      // Устанавливаем доступ к файлу для всех (публичный доступ на чтение)
      await drive.permissions.create({
        fileId: response.data.id,
        requestBody: {
          role: 'reader',
          type: 'anyone'
        }
      });
      
      // Удаляем временный файл
      fs.unlinkSync(filePath);
      
      return response.data.webViewLink;
    } else {
      // Используем локальное хранилище
      const dest = path.join(LOCAL_STORAGE_DIR, destination);
      const destDir = path.dirname(dest);
      
      if (!fs.existsSync(destDir)) {
        fs.mkdirSync(destDir, { recursive: true });
      }
      
      fs.copyFileSync(filePath, dest);
      fs.unlinkSync(filePath);
      
      return `file://${dest}`;
    }
  } catch (error) {
    console.error('Ошибка при загрузке файла:', error);
    throw error;
  }
}

/**
 * Получает MIME-тип на основе расширения файла
 */
function getMimeType(fileName: string): string {
  const extension = path.extname(fileName).toLowerCase();
  
  switch (extension) {
    case '.html':
      return 'text/html';
    case '.css':
      return 'text/css';
    case '.js':
      return 'application/javascript';
    case '.py':
      return 'text/x-python';
    case '.php':
      return 'application/x-php';
    case '.java':
      return 'text/x-java-source';
    case '.txt':
      return 'text/plain';
    case '.json':
      return 'application/json';
    case '.zip':
      return 'application/zip';
    default:
      return 'application/octet-stream';
  }
}

/**
 * Получает содержимое файла из Google Drive или локального хранилища
 * @param fileId ID файла в Google Drive или путь к файлу в локальном хранилище
 * @returns Содержимое файла
 */
export async function getFileContent(fileId: string): Promise<Buffer> {
  try {
    if (drive && !fileId.startsWith('file://')) {
      // Получаем файл из Google Drive
      const response = await drive.files.get({
        fileId: fileId,
        alt: 'media'
      }, { 
        responseType: 'arraybuffer' 
      });
      
      return Buffer.from(response.data);
    } else {
      // Получаем файл из локального хранилища
      const filePath = fileId.startsWith('file://') ? fileId.substring(7) : fileId;
      return fs.readFileSync(filePath);
    }
  } catch (error) {
    console.error('Ошибка при получении содержимого файла:', error);
    throw error;
  }
}

/**
 * Удаляет файл из Google Drive или локального хранилища
 * @param fileId ID файла в Google Drive или путь к файлу в локальном хранилище
 */
export async function deleteFile(fileId: string): Promise<void> {
  try {
    if (drive && !fileId.startsWith('file://')) {
      // Удаляем файл из Google Drive
      await drive.files.delete({
        fileId: fileId
      });
    } else {
      // Удаляем файл из локального хранилища
      const filePath = fileId.startsWith('file://') ? fileId.substring(7) : fileId;
      
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }
  } catch (error) {
    console.error('Ошибка при удалении файла:', error);
    throw error;
  }
}

/**
 * Обрабатывает загрузку ZIP-файла
 * @param req Express Request
 * @param res Express Response
 */
export async function handleZipFileUpload(req: Request, res: Response) {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "Файл не был загружен" });
    }

    const zipFilePath = req.file.path;
    const projectId = new Date().getTime().toString();
    const projectDir = `projects/${projectId}`;
    
    // Распаковываем ZIP-файл
    const zip = new AdmZip(zipFilePath);
    const tempExtractDir = path.join(os.tmpdir(), 'massagan-extracted', projectId);
    
    if (!fs.existsSync(tempExtractDir)) {
      fs.mkdirSync(tempExtractDir, { recursive: true });
    }
    
    zip.extractAllTo(tempExtractDir, true);
    
    // Ищем файлы HTML, CSS, JS
    let htmlFile = '';
    let cssFile = '';
    let jsFile = '';
    let backendFile = '';
    let language = '';
    
    const files = fs.readdirSync(tempExtractDir);
    
    for (const file of files) {
      if (file.endsWith('.html')) {
        htmlFile = path.join(tempExtractDir, file);
      } else if (file.endsWith('.css')) {
        cssFile = path.join(tempExtractDir, file);
      } else if (file.endsWith('.js')) {
        jsFile = path.join(tempExtractDir, file);
      } else if (file.endsWith('.py')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'python';
      } else if (file.endsWith('.php')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'php';
      } else if (file.endsWith('.rb')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'ruby';
      } else if (file.endsWith('.java')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'java';
      } else if (file.endsWith('.go')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'go';
      }
    }
    
    // Загружаем найденные файлы
    const uploadedFiles: Record<string, string> = {};
    
    if (htmlFile) {
      const htmlContent = fs.readFileSync(htmlFile, 'utf-8');
      const htmlDestination = `${projectDir}/index.html`;
      uploadedFiles.html = await uploadFile(htmlFile, htmlDestination);
    }
    
    if (cssFile) {
      const cssContent = fs.readFileSync(cssFile, 'utf-8');
      const cssDestination = `${projectDir}/styles.css`;
      uploadedFiles.css = await uploadFile(cssFile, cssDestination);
    }
    
    if (jsFile) {
      const jsContent = fs.readFileSync(jsFile, 'utf-8');
      const jsDestination = `${projectDir}/script.js`;
      uploadedFiles.js = await uploadFile(jsFile, jsDestination);
    }
    
    if (backendFile) {
      const backendContent = fs.readFileSync(backendFile, 'utf-8');
      const backendDestination = `${projectDir}/backend.${backendFile.split('.').pop()}`;
      uploadedFiles.backend = await uploadFile(backendFile, backendDestination);
    }
    
    // Анализируем и эмулируем код
    const htmlContent = htmlFile ? fs.readFileSync(htmlFile, 'utf-8') : '';
    const cssContent = cssFile ? fs.readFileSync(cssFile, 'utf-8') : '';
    const jsContent = jsFile ? fs.readFileSync(jsFile, 'utf-8') : '';
    const backendContent = backendFile ? fs.readFileSync(backendFile, 'utf-8') : '';
    
    // Получаем данные о устройстве и системе
    const device = req.body.device || null;
    const system = req.body.system || null;
    
    // Эмулируем код
    const emulationResult = await analyzeCodeAndGenerateUI(
      htmlContent,
      cssContent,
      jsContent,
      backendContent,
      language,
      device,
      system
    );
    
    // Удаляем временные файлы
    fs.unlinkSync(zipFilePath);
    fs.rmSync(tempExtractDir, { recursive: true, force: true });
    
    return res.json({
      projectId,
      files: uploadedFiles,
      emulation: emulationResult
    });
    
  } catch (error) {
    console.error('Ошибка при обработке ZIP-файла:', error);
    return res.status(500).json({ error: "Ошибка при обработке ZIP-файла" });
  }
}

/**
 * Обрабатывает код, введенный напрямую
 * @param req Express Request
 * @param res Express Response
 */
export async function handleDirectCode(req: Request, res: Response) {
  try {
    const { htmlCode, cssCode, jsCode, backendCode, language, device, system } = req.body;
    
    if (!htmlCode && !cssCode && !jsCode && !backendCode) {
      return res.status(400).json({ error: "Необходимо предоставить хотя бы один из HTML, CSS, JS или бэкенд код" });
    }
    
    const projectId = new Date().getTime().toString();
    const projectDir = `projects/${projectId}`;
    const tempDir = path.join(os.tmpdir(), 'massagan-code', projectId);
    
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    
    // Сохраняем код во временные файлы
    const uploadedFiles: Record<string, string> = {};
    
    if (htmlCode) {
      const htmlPath = path.join(tempDir, 'index.html');
      fs.writeFileSync(htmlPath, htmlCode);
      const htmlDestination = `${projectDir}/index.html`;
      uploadedFiles.html = await uploadFile(htmlPath, htmlDestination);
    }
    
    if (cssCode) {
      const cssPath = path.join(tempDir, 'styles.css');
      fs.writeFileSync(cssPath, cssCode);
      const cssDestination = `${projectDir}/styles.css`;
      uploadedFiles.css = await uploadFile(cssPath, cssDestination);
    }
    
    if (jsCode) {
      const jsPath = path.join(tempDir, 'script.js');
      fs.writeFileSync(jsPath, jsCode);
      const jsDestination = `${projectDir}/script.js`;
      uploadedFiles.js = await uploadFile(jsPath, jsDestination);
    }
    
    if (backendCode) {
      const extension = language ? `.${language}` : '.txt';
      const backendPath = path.join(tempDir, `backend${extension}`);
      fs.writeFileSync(backendPath, backendCode);
      const backendDestination = `${projectDir}/backend${extension}`;
      uploadedFiles.backend = await uploadFile(backendPath, backendDestination);
    }
    
    // Эмулируем код
    const emulationResult = await analyzeCodeAndGenerateUI(
      htmlCode || "",
      cssCode || "",
      jsCode || "",
      backendCode || "",
      language,
      device,
      system
    );
    
    // Удаляем временную директорию
    fs.rmSync(tempDir, { recursive: true, force: true });
    
    return res.json({
      projectId,
      files: uploadedFiles,
      emulation: emulationResult
    });
    
  } catch (error) {
    console.error('Ошибка при обработке кода:', error);
    return res.status(500).json({ error: "Ошибка при обработке кода" });
  }
}

/**
 * Обрабатывает импорт GitHub репозитория
 * @param req Express Request
 * @param res Express Response
 */
export async function handleGitHubImport(req: Request, res: Response) {
  // Пока заглушка, реализация будет добавлена позже
  return res.status(501).json({ error: "Импорт из GitHub в разработке" });
}

/**
 * Получает список проектов
 */
export async function getProjects(): Promise<any[]> {
  try {
    if (drive) {
      // Получаем список файлов из Google Drive, сгруппированных по проектам
      const response = await drive.files.list({
        q: "mimeType != 'application/vnd.google-apps.folder'",
        fields: 'files(id, name, webViewLink, createdTime)',
        spaces: 'drive'
      });
      
      const files = response.data.files;
      const projects = new Map<string, any>();
      
      for (const file of files) {
        // Имя файла может быть в формате "projects/TIMESTAMP/filename"
        const matches = file.name.match(/^projects\/(\d+)\//);
        
        if (matches && matches[1]) {
          const projectId = matches[1];
          
          if (!projects.has(projectId)) {
            projects.set(projectId, {
              id: projectId,
              files: [],
              createdAt: new Date(parseInt(projectId)).toISOString()
            });
          }
          
          const project = projects.get(projectId);
          project.files.push({
            id: file.id,
            name: file.name,
            type: file.name.split('.').pop() || 'unknown',
            url: file.webViewLink
          });
        }
      }
      
      return Array.from(projects.values());
    } else {
      // Получаем список проектов из локального хранилища
      const projectsDir = path.join(LOCAL_STORAGE_DIR, 'projects');
      
      if (!fs.existsSync(projectsDir)) {
        return [];
      }
      
      const projectDirs = fs.readdirSync(projectsDir);
      const projects = [];
      
      for (const projectId of projectDirs) {
        const projectPath = path.join(projectsDir, projectId);
        
        if (fs.statSync(projectPath).isDirectory()) {
          const files = fs.readdirSync(projectPath).map(file => {
            const filePath = path.join(projectPath, file);
            return {
              id: `file://${filePath}`,
              name: file,
              type: file.split('.').pop() || 'unknown',
              url: `file://${filePath}`
            };
          });
          
          projects.push({
            id: projectId,
            files,
            createdAt: new Date(parseInt(projectId)).toISOString()
          });
        }
      }
      
      return projects;
    }
  } catch (error) {
    console.error('Ошибка при получении списка проектов:', error);
    return [];
  }
}

/**
 * Получает данные конкретного проекта
 * @param projectId ID проекта
 */
export async function getProject(projectId: string): Promise<any> {
  try {
    if (drive) {
      // Получаем файлы проекта из Google Drive
      const response = await drive.files.list({
        q: `name contains 'projects/${projectId}/'`,
        fields: 'files(id, name, webViewLink)',
        spaces: 'drive'
      });
      
      const files = response.data.files;
      
      if (files.length === 0) {
        throw new Error('Проект не найден');
      }
      
      const projectFiles = files.map((file: any) => ({
        id: file.id,
        name: file.name,
        type: file.name.split('.').pop() || 'unknown',
        url: file.webViewLink
      }));
      
      // Получаем содержимое файлов для эмуляции
      let htmlContent = '';
      let cssContent = '';
      let jsContent = '';
      let backendContent = '';
      let language = '';
      
      for (const file of files) {
        if (file.name.endsWith('.html')) {
          const content = await getFileContent(file.id);
          htmlContent = content.toString('utf-8');
        } else if (file.name.endsWith('.css')) {
          const content = await getFileContent(file.id);
          cssContent = content.toString('utf-8');
        } else if (file.name.endsWith('.js') && !file.name.includes('backend')) {
          const content = await getFileContent(file.id);
          jsContent = content.toString('utf-8');
        } else if (file.name.includes('backend')) {
          const content = await getFileContent(file.id);
          backendContent = content.toString('utf-8');
          
          const extension = file.name.split('.').pop();
          if (extension === 'py') language = 'python';
          else if (extension === 'php') language = 'php';
          else if (extension === 'rb') language = 'ruby';
          else if (extension === 'java') language = 'java';
          else if (extension === 'go') language = 'go';
          else language = extension || '';
        }
      }
      
      // Эмулируем код
      const emulationResult = await analyzeCodeAndGenerateUI(
        htmlContent,
        cssContent,
        jsContent,
        backendContent,
        language,
        "",
        ""
      );
      
      return {
        id: projectId,
        files: projectFiles,
        emulation: emulationResult,
        createdAt: new Date(parseInt(projectId)).toISOString()
      };
    } else {
      // Получаем проект из локального хранилища
      const projectDir = path.join(LOCAL_STORAGE_DIR, 'projects', projectId);
      
      if (!fs.existsSync(projectDir)) {
        throw new Error('Проект не найден');
      }
      
      const fileNames = fs.readdirSync(projectDir);
      const files = fileNames.map(fileName => {
        const filePath = path.join(projectDir, fileName);
        return {
          id: `file://${filePath}`,
          name: fileName,
          type: fileName.split('.').pop() || 'unknown',
          url: `file://${filePath}`
        };
      });
      
      // Получаем содержимое файлов для эмуляции
      let htmlContent = '';
      let cssContent = '';
      let jsContent = '';
      let backendContent = '';
      let language = '';
      
      for (const fileName of fileNames) {
        const filePath = path.join(projectDir, fileName);
        
        if (fileName.endsWith('.html')) {
          htmlContent = fs.readFileSync(filePath, 'utf-8');
        } else if (fileName.endsWith('.css')) {
          cssContent = fs.readFileSync(filePath, 'utf-8');
        } else if (fileName.endsWith('.js') && !fileName.includes('backend')) {
          jsContent = fs.readFileSync(filePath, 'utf-8');
        } else if (fileName.includes('backend')) {
          backendContent = fs.readFileSync(filePath, 'utf-8');
          
          const extension = fileName.split('.').pop();
          if (extension === 'py') language = 'python';
          else if (extension === 'php') language = 'php';
          else if (extension === 'rb') language = 'ruby';
          else if (extension === 'java') language = 'java';
          else if (extension === 'go') language = 'go';
          else language = extension || '';
        }
      }
      
      // Эмулируем код
      const emulationResult = await analyzeCodeAndGenerateUI(
        htmlContent,
        cssContent,
        jsContent,
        backendContent,
        language,
        "",
        ""
      );
      
      return {
        id: projectId,
        files,
        emulation: emulationResult,
        createdAt: new Date(parseInt(projectId)).toISOString()
      };
    }
  } catch (error) {
    console.error('Ошибка при получении данных проекта:', error);
    throw error;
  }
}

/**
 * Удаляет проект и все его файлы
 * @param projectId ID проекта
 */
export async function deleteProject(projectId: string): Promise<void> {
  try {
    if (drive) {
      // Получаем файлы проекта из Google Drive
      const response = await drive.files.list({
        q: `name contains 'projects/${projectId}/'`,
        fields: 'files(id)',
        spaces: 'drive'
      });
      
      // Удаляем все файлы проекта
      for (const file of response.data.files) {
        await drive.files.delete({
          fileId: file.id
        });
      }
    } else {
      // Удаляем проект из локального хранилища
      const projectDir = path.join(LOCAL_STORAGE_DIR, 'projects', projectId);
      
      if (fs.existsSync(projectDir)) {
        fs.rmSync(projectDir, { recursive: true, force: true });
      }
    }
  } catch (error) {
    console.error('Ошибка при удалении проекта:', error);
    throw error;
  }
}

/**
 * Регистрирует маршруты для работы с файловым хранилищем
 * @param app Express приложение
 */
export function setupStorageRoutes(app: Express) {
  app.post('/api/storage/import/file', upload.single('file'), handleZipFileUpload);
  app.post('/api/storage/import/github', handleGitHubImport);
  app.post('/api/storage/import/direct-code', handleDirectCode);
  
  // Маршрут для получения списка проектов
  app.get('/api/storage/projects', async (req: Request, res: Response) => {
    try {
      const projects = await getProjects();
      return res.json(projects);
    } catch (error) {
      console.error('Ошибка при получении списка проектов:', error);
      return res.status(500).json({ error: "Ошибка при получении списка проектов" });
    }
  });
  
  // Маршрут для получения данных проекта
  app.get('/api/storage/projects/:id', async (req: Request, res: Response) => {
    try {
      const projectId = req.params.id;
      const project = await getProject(projectId);
      return res.json(project);
    } catch (error) {
      console.error('Ошибка при получении данных проекта:', error);
      return res.status(500).json({ error: "Ошибка при получении данных проекта" });
    }
  });
  
  // Маршрут для удаления проекта
  app.delete('/api/storage/projects/:id', async (req: Request, res: Response) => {
    try {
      const projectId = req.params.id;
      await deleteProject(projectId);
      return res.status(204).send();
    } catch (error) {
      console.error('Ошибка при удалении проекта:', error);
      return res.status(500).json({ error: "Ошибка при удалении проекта" });
    }
  });
}