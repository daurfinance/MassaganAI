/**
 * Сервис для взаимодействия с Perplexity API
 * Использует модель llama-3.1-sonar-small-128k-online для анализа кода и генерации интерфейсов
 */
import axios from 'axios';

// Базовый URL для Perplexity API
const PERPLEXITY_API_URL = 'https://api.perplexity.ai/chat/completions';

// Проверяем, что API ключ установлен
if (!process.env.PERPLEXITY_API_KEY) {
  console.warn("ПРЕДУПРЕЖДЕНИЕ: Переменная окружения PERPLEXITY_API_KEY не установлена. Функции ИИ-эмулятора будут недоступны.");
}

// Тип сообщения, отправляемого в API
interface PerplexityMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

// Параметры запроса к API
interface PerplexityRequest {
  model: string;
  messages: PerplexityMessage[];
  max_tokens?: number;
  temperature?: number;
  top_p?: number;
  search_domain_filter?: string[];
  return_images?: boolean;
  return_related_questions?: boolean;
  search_recency_filter?: string;
  top_k?: number;
  stream?: boolean;
  presence_penalty?: number;
  frequency_penalty?: number;
}

// Ответ от API
interface PerplexityResponse {
  id: string;
  model: string;
  object: string;
  created: number;
  citations: string[];
  choices: Array<{
    index: number;
    finish_reason: string;
    message: {
      role: string;
      content: string;
    };
    delta?: {
      role: string;
      content: string;
    };
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

/**
 * Отправляет запрос к Perplexity API
 * @param messages Массив сообщений для отправки
 * @param options Дополнительные параметры запроса
 * @returns Ответ от API
 */
async function sendPerplexityRequest(
  messages: PerplexityMessage[], 
  options: {
    model?: string;
    temperature?: number;
    max_tokens?: number;
  } = {}
): Promise<string> {
  try {
    // Проверка наличия API ключа
    if (!process.env.PERPLEXITY_API_KEY) {
      throw new Error("PERPLEXITY_API_KEY не установлен. Пожалуйста, добавьте API ключ в переменные окружения.");
    }

    // Формирование запроса
    const requestData: PerplexityRequest = {
      model: options.model || "llama-3.1-sonar-small-128k-online",
      messages,
      temperature: options.temperature || 0.2,
      top_p: 0.9,
      max_tokens: options.max_tokens || 4000,
      frequency_penalty: 1,
      presence_penalty: 0, 
      stream: false,
      return_images: false,
      return_related_questions: false
    };

    // Отправка запроса
    const response = await axios.post<PerplexityResponse>(
      PERPLEXITY_API_URL, 
      requestData,
      {
        headers: {
          'Authorization': `Bearer ${process.env.PERPLEXITY_API_KEY}`,
          'Content-Type': 'application/json'
        },
      }
    );

    // Извлечение ответа
    const content = response.data.choices[0]?.message?.content || '';
    return content;
  } catch (error) {
    console.error('Ошибка при запросе к Perplexity API:', error);
    if (axios.isAxiosError(error)) {
      console.error('Детали ошибки:', error.response?.data);
    }
    throw new Error(`Ошибка при взаимодействии с Perplexity API: ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Анализирует HTML, CSS и JavaScript код
 * @param htmlCode HTML код
 * @param cssCode CSS код
 * @param jsCode JavaScript код
 * @param backendCode Backend код (опционально)
 * @param language Язык программирования бэкенда (опционально)
 * @returns Анализ кода и рекомендации по улучшению
 */
export async function analyzeCode(
  htmlCode: string, 
  cssCode: string, 
  jsCode: string, 
  backendCode?: string, 
  language?: string
): Promise<string> {
  // Подготовка промпта с учетом дополнительных параметров
  let prompt = `Проанализируй следующий веб-код:`;
  
  if (htmlCode.trim()) {
    prompt += `\n\nHTML:\n\`\`\`html\n${htmlCode}\n\`\`\``;
  }
  
  if (cssCode.trim()) {
    prompt += `\n\nCSS:\n\`\`\`css\n${cssCode}\n\`\`\``;
  }
  
  if (jsCode.trim()) {
    prompt += `\n\nJavaScript:\n\`\`\`javascript\n${jsCode}\n\`\`\``;
  }
  
  // Добавляем бэкенд код, если он предоставлен
  if (backendCode && backendCode.trim()) {
    prompt += `\n\nBackend (${language || 'Unknown'}):\n\`\`\`${language || ''}\n${backendCode}\n\`\`\``;
  }
  
  prompt += `\n\nПроведи детальный анализ этого кода по следующим параметрам:
1. Оцени структуру HTML${backendCode ? ' и взаимодействие с бэкендом' : ''}
2. Проанализируй стилизацию CSS
3. Оцени функциональность JavaScript
${backendCode ? '4. Проанализируй бэкенд код и его интеграцию с фронтендом' : '4. Выяви потенциальные проблемы и баги'}
5. Предложи конкретные улучшения для каждого аспекта

Дай подробный анализ с конкретными примерами и рекомендациями.
`;

  const messages: PerplexityMessage[] = [
    { role: "system", content: "Ты опытный веб-разработчик, специализирующийся на анализе и улучшении кода. Ты предоставляешь подробный, глубокий анализ и конкретные практические рекомендации по улучшению веб-кода." },
    { role: "user", content: prompt }
  ];

  return await sendPerplexityRequest(messages, { 
    model: "llama-3.1-sonar-small-128k-online", 
    temperature: 0.1,
    max_tokens: 4000
  });
}

/**
 * Генерирует улучшенный HTML, CSS и JavaScript код
 * @param htmlCode Исходный HTML код
 * @param cssCode Исходный CSS код
 * @param jsCode Исходный JavaScript код
 * @returns Улучшенный код и объяснение изменений
 */
export async function generateImprovedCode(htmlCode: string, cssCode: string, jsCode: string): Promise<{
  html: string;
  css: string;
  js: string;
  explanation: string;
}> {
  const prompt = `
Улучши следующий веб-код, сохраняя его основную функциональность, но делая его более качественным, современным и поддерживаемым:

HTML:
\`\`\`html
${htmlCode}
\`\`\`

CSS:
\`\`\`css
${cssCode}
\`\`\`

JavaScript:
\`\`\`javascript
${jsCode}
\`\`\`

Пожалуйста, представь улучшенную версию этого кода с следующими улучшениями:
1. Более семантическая и доступная HTML структура
2. Оптимизированные CSS стили с использованием современных практик
3. Улучшенный JavaScript с лучшей структурой, обработкой ошибок и современными методами
4. Исправление любых потенциальных проблем безопасности или производительности

Верни только улучшенный код в следующем формате:

IMPROVED_HTML:
[улучшенный HTML код]

IMPROVED_CSS:
[улучшенный CSS код]

IMPROVED_JS:
[улучшенный JavaScript код]

EXPLANATION:
[краткое объяснение изменений, которые ты сделал и почему]
`;

  const messages: PerplexityMessage[] = [
    { role: "system", content: "Ты опытный веб-разработчик, специализирующийся на рефакторинге и улучшении веб-кода. Ты создаешь чистый, модульный код, следуя лучшим практикам веб-разработки." },
    { role: "user", content: prompt }
  ];

  const response = await sendPerplexityRequest(messages, { 
    model: "llama-3.1-sonar-small-128k-online", 
    temperature: 0.2,
    max_tokens: 5000
  });

  // Парсинг ответа
  const htmlMatch = response.match(/IMPROVED_HTML:\s*([\s\S]*?)(?=IMPROVED_CSS:|$)/);
  const cssMatch = response.match(/IMPROVED_CSS:\s*([\s\S]*?)(?=IMPROVED_JS:|$)/);
  const jsMatch = response.match(/IMPROVED_JS:\s*([\s\S]*?)(?=EXPLANATION:|$)/);
  const explanationMatch = response.match(/EXPLANATION:\s*([\s\S]*)/);

  return {
    html: htmlMatch ? htmlMatch[1].trim() : htmlCode,
    css: cssMatch ? cssMatch[1].trim() : cssCode,
    js: jsMatch ? jsMatch[1].trim() : jsCode,
    explanation: explanationMatch ? explanationMatch[1].trim() : "Улучшения выполнены без дополнительных пояснений."
  };
}

/**
 * Генерирует фронтенд на основе кода бэкенда
 * @param backendCode Код бэкенда
 * @returns Сгенерированный фронтенд и анализ
 */
export async function generateFrontendFromBackend(backendCode: string): Promise<{
  analysis: string;
  components: Array<{name: string, path: string, code: string}>;
  pages: Array<{name: string, path: string, code: string}>;
}> {
  const prompt = `
Проанализируй следующий код бэкенда и создай соответствующий фронтенд для него:

\`\`\`javascript
${backendCode}
\`\`\`

Изучи API эндпоинты, модели данных и бизнес-логику в этом коде. Затем создай полноценный фронтенд на React, который будет взаимодействовать с этим бэкендом.

Вот что требуется для генерации:

1. Подробный анализ бэкенда, его структуры API и моделей данных
2. Набор React компонентов для работы с данными и интерфейсом
3. Страницы для разных разделов приложения

Твой ответ должен быть в формате:

ANALYSIS:
[подробный анализ бэкенда, его API и структуры данных]

COMPONENTS:
[Массив компонентов в формате JSON, где каждый компонент имеет поля 'name' (имя компонента), 'path' (путь к файлу относительно src/components) и 'code' (код компонента)]

PAGES:
[Массив страниц в формате JSON, где каждая страница имеет поля 'name' (имя страницы), 'path' (путь к файлу относительно src/pages) и 'code' (код страницы)]
`;

  const messages: PerplexityMessage[] = [
    { role: "system", content: "Ты опытный полностековый разработчик, специализирующийся на создании фронтенд решений для существующих бэкендов. Ты эксперт в React, JavaScript, и REST API." },
    { role: "user", content: prompt }
  ];

  const response = await sendPerplexityRequest(messages, { 
    model: "llama-3.1-sonar-small-128k-online", 
    temperature: 0.2,
    max_tokens: 6000
  });

  try {
    // Извлечение анализа
    const analysisMatch = response.match(/ANALYSIS:\s*([\s\S]*?)(?=COMPONENTS:|$)/);
    const analysis = analysisMatch ? analysisMatch[1].trim() : "Анализ не предоставлен.";

    // Извлечение компонентов
    const componentsMatch = response.match(/COMPONENTS:\s*([\s\S]*?)(?=PAGES:|$)/);
    let components: Array<{name: string, path: string, code: string}> = [];

    if (componentsMatch && componentsMatch[1]) {
      try {
        const componentsStr = componentsMatch[1].trim();
        // Проверяем, начинается ли строка с [, что указывает на JSON массив
        if (componentsStr.startsWith('[')) {
          components = JSON.parse(componentsStr);
        } else {
          // Если не удалось распарсить как JSON, пытаемся извлечь данные через регулярные выражения
          const componentRegex = /name: ['"](.+?)['"],\s*path: ['"](.+?)['"],\s*code: ['"](.+?)['"]/g;
          let match;
          while ((match = componentRegex.exec(componentsStr)) !== null) {
            components.push({
              name: match[1],
              path: match[2],
              code: match[3].replace(/\\n/g, '\n').replace(/\\"/g, '"')
            });
          }
        }
      } catch (error) {
        console.error('Ошибка при разборе компонентов:', error);
      }
    }

    // Извлечение страниц
    const pagesMatch = response.match(/PAGES:\s*([\s\S]*)/);
    let pages: Array<{name: string, path: string, code: string}> = [];

    if (pagesMatch && pagesMatch[1]) {
      try {
        const pagesStr = pagesMatch[1].trim();
        // Проверяем, начинается ли строка с [, что указывает на JSON массив
        if (pagesStr.startsWith('[')) {
          pages = JSON.parse(pagesStr);
        } else {
          // Если не удалось распарсить как JSON, пытаемся извлечь данные через регулярные выражения
          const pageRegex = /name: ['"](.+?)['"],\s*path: ['"](.+?)['"],\s*code: ['"](.+?)['"]/g;
          let match;
          while ((match = pageRegex.exec(pagesStr)) !== null) {
            pages.push({
              name: match[1],
              path: match[2],
              code: match[3].replace(/\\n/g, '\n').replace(/\\"/g, '"')
            });
          }
        }
      } catch (error) {
        console.error('Ошибка при разборе страниц:', error);
      }
    }

    return {
      analysis,
      components,
      pages
    };
  } catch (error) {
    console.error('Ошибка при разборе ответа:', error);
    throw new Error(`Ошибка при генерации фронтенда: ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Генерирует полный проект на основе описания
 * @param description Описание проекта
 * @returns Сгенерированный проект и анализ
 */
export async function generateProject(description: string): Promise<{
  analysis: string;
  backend: {
    server?: {name: string, path: string, code: string};
    routes: Array<{name: string, path: string, code: string}>;
    models: Array<{name: string, path: string, code: string}>;
  };
  frontend: {
    components: Array<{name: string, path: string, code: string}>;
    pages: Array<{name: string, path: string, code: string}>;
    styles?: {name: string, path: string, code: string};
  };
}> {
  const prompt = `
Создай полноценный веб-проект на основе следующего описания:

${description}

Проект должен включать в себя как бэкенд, так и фронтенд части. Используй современные технологии и архитектурные подходы.

Бэкенд должен быть реализован на Node.js с Express, а фронтенд на React с использованием современных практик.

Твой ответ должен быть в следующем формате:

ANALYSIS:
[подробный анализ проекта, его архитектуры, требований и технических решений]

BACKEND_SERVER:
{
  "name": "index.ts",
  "path": "server/index.ts",
  "code": [код основного файла сервера]
}

BACKEND_ROUTES:
[массив файлов маршрутов в формате JSON, где каждый маршрут имеет поля 'name', 'path' (относительно корня) и 'code']

BACKEND_MODELS:
[массив файлов моделей в формате JSON, где каждая модель имеет поля 'name', 'path' (относительно корня) и 'code']

FRONTEND_COMPONENTS:
[массив компонентов в формате JSON, где каждый компонент имеет поля 'name', 'path' (относительно src/components) и 'code']

FRONTEND_PAGES:
[массив страниц в формате JSON, где каждая страница имеет поля 'name', 'path' (относительно src/pages) и 'code']

FRONTEND_STYLES:
{
  "name": "index.css",
  "path": "src/index.css",
  "code": [CSS код для стилей]
}
`;

  const messages: PerplexityMessage[] = [
    { role: "system", content: "Ты опытный полностековый разработчик, специализирующийся на создании полноценных веб-приложений. Ты эксперт в разработке бэкенда на Node.js/Express и фронтенда на React." },
    { role: "user", content: prompt }
  ];

  const response = await sendPerplexityRequest(messages, { 
    model: "llama-3.1-sonar-small-128k-online", 
    temperature: 0.2,
    max_tokens: 8000
  });

  try {
    // Извлечение анализа
    const analysisMatch = response.match(/ANALYSIS:\s*([\s\S]*?)(?=BACKEND_SERVER:|$)/);
    const analysis = analysisMatch ? analysisMatch[1].trim() : "Анализ не предоставлен.";

    // Структура для хранения результатов
    const result = {
      analysis,
      backend: {
        server: undefined as {name: string, path: string, code: string} | undefined,
        routes: [] as Array<{name: string, path: string, code: string}>,
        models: [] as Array<{name: string, path: string, code: string}>
      },
      frontend: {
        components: [] as Array<{name: string, path: string, code: string}>,
        pages: [] as Array<{name: string, path: string, code: string}>,
        styles: undefined as {name: string, path: string, code: string} | undefined
      }
    };

    // Извлечение сервера бэкенда
    const serverMatch = response.match(/BACKEND_SERVER:\s*([\s\S]*?)(?=BACKEND_ROUTES:|$)/);
    if (serverMatch && serverMatch[1]) {
      try {
        const serverJson = serverMatch[1].trim();
        result.backend.server = JSON.parse(serverJson);
      } catch (error) {
        console.error('Ошибка при разборе сервера бэкенда:', error);
      }
    }

    // Извлечение маршрутов бэкенда
    const routesMatch = response.match(/BACKEND_ROUTES:\s*([\s\S]*?)(?=BACKEND_MODELS:|$)/);
    if (routesMatch && routesMatch[1]) {
      try {
        const routesJson = routesMatch[1].trim();
        result.backend.routes = JSON.parse(routesJson);
      } catch (error) {
        console.error('Ошибка при разборе маршрутов бэкенда:', error);
      }
    }

    // Извлечение моделей бэкенда
    const modelsMatch = response.match(/BACKEND_MODELS:\s*([\s\S]*?)(?=FRONTEND_COMPONENTS:|$)/);
    if (modelsMatch && modelsMatch[1]) {
      try {
        const modelsJson = modelsMatch[1].trim();
        result.backend.models = JSON.parse(modelsJson);
      } catch (error) {
        console.error('Ошибка при разборе моделей бэкенда:', error);
      }
    }

    // Извлечение компонентов фронтенда
    const componentsMatch = response.match(/FRONTEND_COMPONENTS:\s*([\s\S]*?)(?=FRONTEND_PAGES:|$)/);
    if (componentsMatch && componentsMatch[1]) {
      try {
        const componentsJson = componentsMatch[1].trim();
        result.frontend.components = JSON.parse(componentsJson);
      } catch (error) {
        console.error('Ошибка при разборе компонентов фронтенда:', error);
      }
    }

    // Извлечение страниц фронтенда
    const pagesMatch = response.match(/FRONTEND_PAGES:\s*([\s\S]*?)(?=FRONTEND_STYLES:|$)/);
    if (pagesMatch && pagesMatch[1]) {
      try {
        const pagesJson = pagesMatch[1].trim();
        result.frontend.pages = JSON.parse(pagesJson);
      } catch (error) {
        console.error('Ошибка при разборе страниц фронтенда:', error);
      }
    }

    // Извлечение стилей фронтенда
    const stylesMatch = response.match(/FRONTEND_STYLES:\s*([\s\S]*)/);
    if (stylesMatch && stylesMatch[1]) {
      try {
        const stylesJson = stylesMatch[1].trim();
        result.frontend.styles = JSON.parse(stylesJson);
      } catch (error) {
        console.error('Ошибка при разборе стилей фронтенда:', error);
      }
    }

    return result;
  } catch (error) {
    console.error('Ошибка при разборе ответа:', error);
    throw new Error(`Ошибка при генерации проекта: ${error instanceof Error ? error.message : String(error)}`);
  }
}