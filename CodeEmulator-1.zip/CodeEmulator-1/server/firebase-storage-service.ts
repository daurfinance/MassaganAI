/**
 * MassaganAI: Сервис для работы с локальным хранилищем файлов
 * Обрабатывает загрузку файлов, их получение и эмуляцию кода
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import { Express, Request, Response } from "express";
import multer from "multer";
import fs from "fs";
import path from "path";
import os from "os";
import AdmZip from "adm-zip";
import { analyzeCodeAndGenerateUI } from "./ai-service";
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Инициализация Firebase Admin SDK
console.log('Создаем локальную заглушку для Firebase Storage');

// Создаем директорию для локального хранения
const LOCAL_STORAGE_DIR = path.join(__dirname, '..', 'temp', 'storage');
if (!fs.existsSync(LOCAL_STORAGE_DIR)) {
  fs.mkdirSync(LOCAL_STORAGE_DIR, { recursive: true });
}

// Создаем заглушку для Firebase Storage bucket
const bucket = {
  upload: async (filePath: string, options: any) => {
    const dest = path.join(LOCAL_STORAGE_DIR, options.destination);
    const destDir = path.dirname(dest);
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }
    fs.copyFileSync(filePath, dest);
    return [{ name: options.destination }];
  },
  file: (fileName: string) => ({
    makePublic: async () => {},
    download: async () => {
      const filePath = path.join(LOCAL_STORAGE_DIR, fileName);
      return [fs.readFileSync(filePath)];
    },
    delete: async () => {
      const filePath = path.join(LOCAL_STORAGE_DIR, fileName);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }
  }),
  getFiles: async (options: any) => {
    const prefix = options.prefix || '';
    const prefixPath = path.join(LOCAL_STORAGE_DIR, prefix);
    
    if (!fs.existsSync(prefixPath)) {
      return [[]];
    }
    
    const getAllFiles = (dirPath: string, arrayOfFiles: any[] = []) => {
      const files = fs.readdirSync(dirPath);
      
      for (const file of files) {
        const filePath = path.join(dirPath, file);
        const relativePath = path.relative(LOCAL_STORAGE_DIR, filePath).replace(/\\/g, '/');
        
        if (fs.statSync(filePath).isDirectory()) {
          getAllFiles(filePath, arrayOfFiles);
        } else {
          arrayOfFiles.push({
            name: relativePath,
            download: async () => [fs.readFileSync(filePath)],
            delete: async () => fs.unlinkSync(filePath)
          });
        }
      }
      
      return arrayOfFiles;
    };
    
    try {
      const allFiles = fs.existsSync(prefixPath) ? getAllFiles(prefixPath) : [];
      return [allFiles.filter(file => file.name.startsWith(prefix))];
    } catch (error) {
      console.error('Ошибка при получении списка файлов:', error);
      return [[]];
    }
  },
  name: 'local-storage'
};

// Настройка multer для временного хранения загружаемых файлов
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const tempDir = path.join(os.tmpdir(), 'massagan-uploads');
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    cb(null, tempDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + '-' + file.originalname);
  }
});

export const upload = multer({ storage: storage });

/**
 * Загружает файл в Firebase Storage
 * @param filePath Локальный путь к файлу
 * @param destination Путь в Firebase Storage
 * @returns Публичный URL файла
 */
export async function uploadFileToStorage(filePath: string, destination: string): Promise<string> {
  try {
    await bucket.upload(filePath, {
      destination: destination,
      metadata: {
        cacheControl: 'public, max-age=31536000',
      },
    });

    // Создаем публичную ссылку на файл
    await bucket.file(destination).makePublic();
    const publicUrl = `https://storage.googleapis.com/${bucket.name}/${destination}`;
    
    // Удаляем временный файл
    fs.unlinkSync(filePath);
    
    return publicUrl;
  } catch (error) {
    console.error('Ошибка при загрузке файла в Firebase Storage:', error);
    throw error;
  }
}

/**
 * Обрабатывает загрузку ZIP-файла
 * @param req Express Request
 * @param res Express Response
 */
export async function handleZipFileUpload(req: Request, res: Response) {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "Файл не был загружен" });
    }

    const zipFilePath = req.file.path;
    const projectId = new Date().getTime().toString();
    const projectDir = `projects/${projectId}`;
    
    // Распаковываем ZIP-файл
    const zip = new AdmZip(zipFilePath);
    const tempExtractDir = path.join(os.tmpdir(), 'massagan-extracted', projectId);
    
    if (!fs.existsSync(tempExtractDir)) {
      fs.mkdirSync(tempExtractDir, { recursive: true });
    }
    
    zip.extractAllTo(tempExtractDir, true);
    
    // Ищем файлы HTML, CSS, JS
    let htmlFile = '';
    let cssFile = '';
    let jsFile = '';
    let backendFile = '';
    let language = '';
    
    const files = fs.readdirSync(tempExtractDir);
    
    for (const file of files) {
      if (file.endsWith('.html')) {
        htmlFile = path.join(tempExtractDir, file);
      } else if (file.endsWith('.css')) {
        cssFile = path.join(tempExtractDir, file);
      } else if (file.endsWith('.js')) {
        jsFile = path.join(tempExtractDir, file);
      } else if (file.endsWith('.py')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'python';
      } else if (file.endsWith('.php')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'php';
      } else if (file.endsWith('.rb')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'ruby';
      } else if (file.endsWith('.java')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'java';
      } else if (file.endsWith('.go')) {
        backendFile = path.join(tempExtractDir, file);
        language = 'go';
      }
    }
    
    // Загружаем найденные файлы в Firebase Storage
    const uploadedFiles: Record<string, string> = {};
    
    if (htmlFile) {
      const htmlContent = fs.readFileSync(htmlFile, 'utf-8');
      const htmlDestination = `${projectDir}/index.html`;
      uploadedFiles.html = await uploadFileToStorage(htmlFile, htmlDestination);
    }
    
    if (cssFile) {
      const cssContent = fs.readFileSync(cssFile, 'utf-8');
      const cssDestination = `${projectDir}/styles.css`;
      uploadedFiles.css = await uploadFileToStorage(cssFile, cssDestination);
    }
    
    if (jsFile) {
      const jsContent = fs.readFileSync(jsFile, 'utf-8');
      const jsDestination = `${projectDir}/script.js`;
      uploadedFiles.js = await uploadFileToStorage(jsFile, jsDestination);
    }
    
    if (backendFile) {
      const backendContent = fs.readFileSync(backendFile, 'utf-8');
      const backendDestination = `${projectDir}/backend.${backendFile.split('.').pop()}`;
      uploadedFiles.backend = await uploadFileToStorage(backendFile, backendDestination);
    }
    
    // Анализируем и эмулируем код
    const htmlContent = htmlFile ? fs.readFileSync(htmlFile, 'utf-8') : '';
    const cssContent = cssFile ? fs.readFileSync(cssFile, 'utf-8') : '';
    const jsContent = jsFile ? fs.readFileSync(jsFile, 'utf-8') : '';
    const backendContent = backendFile ? fs.readFileSync(backendFile, 'utf-8') : '';
    
    // Получаем данные о устройстве и системе
    const device = req.body.device || null;
    const system = req.body.system || null;
    
    // Эмулируем код
    const emulationResult = await analyzeCodeAndGenerateUI(
      htmlContent,
      cssContent,
      jsContent,
      backendContent,
      language,
      device,
      system
    );
    
    // Удаляем временные файлы
    fs.unlinkSync(zipFilePath);
    fs.rmSync(tempExtractDir, { recursive: true, force: true });
    
    return res.json({
      projectId,
      files: uploadedFiles,
      emulation: emulationResult
    });
    
  } catch (error) {
    console.error('Ошибка при обработке ZIP-файла:', error);
    return res.status(500).json({ error: "Ошибка при обработке ZIP-файла" });
  }
}

/**
 * Обрабатывает код, введенный напрямую
 * @param req Express Request
 * @param res Express Response
 */
export async function handleDirectCode(req: Request, res: Response) {
  try {
    const { htmlCode, cssCode, jsCode, backendCode, language, device, system } = req.body;
    
    if (!htmlCode && !cssCode && !jsCode && !backendCode) {
      return res.status(400).json({ error: "Необходимо предоставить хотя бы один из HTML, CSS, JS или бэкенд код" });
    }
    
    const projectId = new Date().getTime().toString();
    const projectDir = `projects/${projectId}`;
    const tempDir = path.join(os.tmpdir(), 'massagan-code', projectId);
    
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }
    
    // Сохраняем код во временные файлы
    const uploadedFiles: Record<string, string> = {};
    
    if (htmlCode) {
      const htmlPath = path.join(tempDir, 'index.html');
      fs.writeFileSync(htmlPath, htmlCode);
      const htmlDestination = `${projectDir}/index.html`;
      uploadedFiles.html = await uploadFileToStorage(htmlPath, htmlDestination);
    }
    
    if (cssCode) {
      const cssPath = path.join(tempDir, 'styles.css');
      fs.writeFileSync(cssPath, cssCode);
      const cssDestination = `${projectDir}/styles.css`;
      uploadedFiles.css = await uploadFileToStorage(cssPath, cssDestination);
    }
    
    if (jsCode) {
      const jsPath = path.join(tempDir, 'script.js');
      fs.writeFileSync(jsPath, jsCode);
      const jsDestination = `${projectDir}/script.js`;
      uploadedFiles.js = await uploadFileToStorage(jsPath, jsDestination);
    }
    
    if (backendCode) {
      const extension = language ? `.${language}` : '.txt';
      const backendPath = path.join(tempDir, `backend${extension}`);
      fs.writeFileSync(backendPath, backendCode);
      const backendDestination = `${projectDir}/backend${extension}`;
      uploadedFiles.backend = await uploadFileToStorage(backendPath, backendDestination);
    }
    
    // Эмулируем код
    const emulationResult = await analyzeCodeAndGenerateUI(
      htmlCode || "",
      cssCode || "",
      jsCode || "",
      backendCode,
      language,
      device,
      system
    );
    
    // Удаляем временную директорию
    fs.rmSync(tempDir, { recursive: true, force: true });
    
    return res.json({
      projectId,
      files: uploadedFiles,
      emulation: emulationResult
    });
    
  } catch (error) {
    console.error('Ошибка при обработке кода:', error);
    return res.status(500).json({ error: "Ошибка при обработке кода" });
  }
}

/**
 * Обрабатывает импорт GitHub репозитория
 * @param req Express Request
 * @param res Express Response
 */
export async function handleGitHubImport(req: Request, res: Response) {
  // Пока заглушка, реализация будет добавлена позже
  return res.status(501).json({ error: "Импорт из GitHub в разработке" });
}

/**
 * Регистрирует маршруты для работы с Firebase Storage
 * @param app Express приложение
 */
export function setupFirebaseStorageRoutes(app: Express) {
  app.post('/api/storage/import/file', upload.single('file'), handleZipFileUpload);
  app.post('/api/storage/import/github', handleGitHubImport);
  app.post('/api/storage/import/direct-code', handleDirectCode);
  
  // Маршрут для получения списка проектов
  app.get('/api/storage/projects', async (req: Request, res: Response) => {
    try {
      const [files] = await bucket.getFiles({ prefix: 'projects/' });
      
      // Группируем файлы по проектам
      const projects = new Map<string, any>();
      
      for (const file of files) {
        const pathParts = file.name.split('/');
        
        if (pathParts.length >= 2) {
          const projectId = pathParts[1];
          
          if (!projects.has(projectId)) {
            projects.set(projectId, {
              id: projectId,
              files: [],
              createdAt: new Date(parseInt(projectId)).toISOString()
            });
          }
          
          const project = projects.get(projectId);
          if (project) {
            project.files.push({
              name: file.name,
              type: file.name.split('.').pop() || 'unknown',
              url: `https://storage.googleapis.com/${bucket.name}/${file.name}`
            });
          }
        }
      }
      
      return res.json(Array.from(projects.values()));
      
    } catch (error) {
      console.error('Ошибка при получении списка проектов:', error);
      return res.status(500).json({ error: "Ошибка при получении списка проектов" });
    }
  });
  
  // Маршрут для получения данных проекта
  app.get('/api/storage/projects/:id', async (req: Request, res: Response) => {
    try {
      const projectId = req.params.id;
      const [files] = await bucket.getFiles({ prefix: `projects/${projectId}/` });
      
      if (files.length === 0) {
        return res.status(404).json({ error: "Проект не найден" });
      }
      
      const projectFiles = files.map(file => ({
        name: file.name,
        type: file.name.split('.').pop(),
        url: `https://storage.googleapis.com/${bucket.name}/${file.name}`
      }));
      
      // Получаем содержимое файлов для эмуляции
      let htmlContent = '';
      let cssContent = '';
      let jsContent = '';
      let backendContent = '';
      let language = '';
      
      for (const file of files) {
        if (file.name.endsWith('.html')) {
          const [data] = await file.download();
          htmlContent = data.toString('utf-8');
        } else if (file.name.endsWith('.css')) {
          const [data] = await file.download();
          cssContent = data.toString('utf-8');
        } else if (file.name.endsWith('.js') && !file.name.includes('backend')) {
          const [data] = await file.download();
          jsContent = data.toString('utf-8');
        } else if (file.name.includes('backend')) {
          const [data] = await file.download();
          backendContent = data.toString('utf-8');
          
          const extension = file.name.split('.').pop();
          if (extension === 'py') language = 'python';
          else if (extension === 'php') language = 'php';
          else if (extension === 'rb') language = 'ruby';
          else if (extension === 'java') language = 'java';
          else if (extension === 'go') language = 'go';
          else language = extension || '';
        }
      }
      
      // Эмулируем код
      const emulationResult = await analyzeCodeAndGenerateUI(
        htmlContent,
        cssContent,
        jsContent,
        backendContent,
        language,
        "",
        ""
      );
      
      return res.json({
        id: projectId,
        files: projectFiles,
        emulation: emulationResult,
        createdAt: new Date(parseInt(projectId)).toISOString()
      });
      
    } catch (error) {
      console.error('Ошибка при получении данных проекта:', error);
      return res.status(500).json({ error: "Ошибка при получении данных проекта" });
    }
  });
  
  // Маршрут для удаления проекта
  app.delete('/api/storage/projects/:id', async (req: Request, res: Response) => {
    try {
      const projectId = req.params.id;
      const [files] = await bucket.getFiles({ prefix: `projects/${projectId}/` });
      
      if (files.length === 0) {
        return res.status(404).json({ error: "Проект не найден" });
      }
      
      // Удаляем все файлы проекта
      await Promise.all(files.map(file => file.delete()));
      
      return res.status(204).send();
      
    } catch (error) {
      console.error('Ошибка при удалении проекта:', error);
      return res.status(500).json({ error: "Ошибка при удалении проекта" });
    }
  });
}