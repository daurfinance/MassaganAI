/**
 * MassaganAI: Схема базы данных
 * Все права принадлежат Dauirzhan Abdulmazhit, 2025
 */

import { pgTable, text, serial, integer, boolean, jsonb, timestamp, pgEnum, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Перечисления 
export const subscriptionStatusEnum = pgEnum('subscription_status', [
  'trialing',
  'active',
  'canceled',
  'incomplete',
  'incomplete_expired',
  'past_due',
  'unpaid'
]);

export const planTypeEnum = pgEnum('plan_type', ['premium', 'business']);

// Типы криптовалют
export const cryptoCurrencyEnum = pgEnum('crypto_currency', [
  'BTC',  // Bitcoin
  'ETH',  // Ethereum
  'BNB',  // Binance Coin
  'USDT', // Tether
  'USDC', // USD Coin
  'XRP',  // Ripple
  'ADA',  // Cardano
  'SOL',  // Solana
  'DOT',  // Polkadot
  'KZT',  // Казахстанский токен (добавлен для локальных операций)
]);

// Типы транзакций
export const transactionTypeEnum = pgEnum('transaction_type', [
  'deposit',        // Пополнение
  'withdrawal',     // Вывод
  'payment',        // Оплата услуг
  'ai_usage',       // Использование ИИ
  'ad_spending',    // Расходы на рекламу
  'refund',         // Возврат
  'transfer',       // Перевод
  'airdrop',        // Раздача/бонус
]);

// Таблица пользователей с дополнительными полями для Stripe
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  displayName: text("display_name"),
  stripeCustomerId: text("stripe_customer_id"),
  walletId: integer("wallet_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Таблица проектов
export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  htmlCode: text("html_code").notNull(),
  cssCode: text("css_code").notNull(),
  jsCode: text("js_code").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Таблица подписок
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  stripeSubscriptionId: text("stripe_subscription_id").notNull(),
  status: subscriptionStatusEnum("status").notNull().default('incomplete'),
  planType: planTypeEnum("plan_type").notNull(),
  currentPeriodEnd: timestamp("current_period_end").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Таблица криптокошельков
export const wallets = pgTable("wallets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  walletAddress: text("wallet_address"), // Адрес кошелька (опционально)
  privateKey: text("private_key"),       // Приватный ключ (хранится зашифрованным)
  balance: decimal("balance", { precision: 18, scale: 8 }).notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Таблица балансов криптовалют
export const cryptoBalances = pgTable("crypto_balances", {
  id: serial("id").primaryKey(),
  walletId: integer("wallet_id").notNull().references(() => wallets.id),
  currency: cryptoCurrencyEnum("currency").notNull(),
  amount: decimal("amount", { precision: 18, scale: 8 }).notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Таблица транзакций
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  walletId: integer("wallet_id").notNull().references(() => wallets.id),
  transactionType: transactionTypeEnum("transaction_type").notNull(),
  amount: decimal("amount", { precision: 18, scale: 8 }).notNull(),
  currency: cryptoCurrencyEnum("currency").notNull(),
  description: text("description"),
  status: text("status").notNull().default("pending"), // pending, completed, failed
  txHash: text("tx_hash"), // Хеш транзакции в блокчейне (если применимо)
  metadata: jsonb("metadata"), // Дополнительная информация
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Определение отношений между таблицами
export const usersRelations = relations(users, ({ many, one }) => ({
  subscriptions: many(subscriptions),
  projects: many(projects),
  wallet: one(wallets, {
    fields: [users.walletId],
    references: [wallets.id]
  }),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, {
    fields: [subscriptions.userId],
    references: [users.id],
  }),
}));

export const projectsRelations = relations(projects, ({ one }) => ({
  user: one(users, {
    fields: [projects.userId],
    references: [users.id],
  }),
}));

// Отношения кошельков
export const walletsRelations = relations(wallets, ({ one, many }) => ({
  user: one(users, {
    fields: [wallets.userId],
    references: [users.id],
  }),
  balances: many(cryptoBalances),
  transactions: many(transactions),
}));

// Отношения балансов криптовалют
export const cryptoBalancesRelations = relations(cryptoBalances, ({ one }) => ({
  wallet: one(wallets, {
    fields: [cryptoBalances.walletId],
    references: [wallets.id],
  }),
}));

// Отношения транзакций
export const transactionsRelations = relations(transactions, ({ one }) => ({
  wallet: one(wallets, {
    fields: [transactions.walletId],
    references: [wallets.id],
  }),
}));

// Схемы для создания проектов
export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Схемы для создания пользователей
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  displayName: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Схемы для подписок
export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

// Схемы для криптокошельков
export const insertWalletSchema = createInsertSchema(wallets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  balance: true,
});

export type InsertWallet = z.infer<typeof insertWalletSchema>;
export type Wallet = typeof wallets.$inferSelect;

// Схемы для балансов криптовалют
export const insertCryptoBalanceSchema = createInsertSchema(cryptoBalances).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  amount: true,
});

export type InsertCryptoBalance = z.infer<typeof insertCryptoBalanceSchema>;
export type CryptoBalance = typeof cryptoBalances.$inferSelect;

// Схемы для транзакций
export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  completedAt: true,
  status: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
